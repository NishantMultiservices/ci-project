document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('#buy-now-btn, #buy-course-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var itemType = this.dataset.item;
            var itemId = this.dataset.id;
            var btnEl = this;
            btnEl.disabled = true;
            btnEl.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';

            var csrfInput = document.querySelector('input[name="csrf_test_name"], input[name="csrf_token"], input[name="ci_csrf_token"]');
            var csrfName = csrfInput ? csrfInput.name : 'csrf_test_name';
            var csrfValue = csrfInput ? csrfInput.value : '';

            var body = 'item_type=' + encodeURIComponent(itemType) + '&item_id=' + encodeURIComponent(itemId) + '&' + encodeURIComponent(csrfName) + '=' + encodeURIComponent(csrfValue);

            var base = typeof baseUrl !== 'undefined' ? baseUrl.replace(/\/+$/, '') : '';
            fetch(base + '/payment/initiate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': csrfValue
                },
                body: body
            })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.redirect) {
                    window.location.href = data.redirect.indexOf('://') > 0 ? data.redirect : base + data.redirect;
                } else {
                    alert(data.error || 'Payment initiation failed.');
                    btnEl.disabled = false;
                    btnEl.innerHTML = '<i class="fas fa-shopping-cart"></i> Buy Now';
                }
            })
            .catch(function() {
                alert('Network error. Please try again.');
                btnEl.disabled = false;
                btnEl.innerHTML = '<i class="fas fa-shopping-cart"></i> Buy Now';
            });
        });
    });
});
