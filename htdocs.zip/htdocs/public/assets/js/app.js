/**
 * RojgarSandhi - Main Application Script
 * Modern JavaScript with smooth interactions
 */

(function() {
    'use strict';

    // DOM Ready
    document.addEventListener('DOMContentLoaded', function() {
        initTheme();
        initMobileMenu();
        initStickyNav();
        initSmoothScroll();
        initSearchSuggestions();
        initBookmarkToggle();
        initCounterAnimation();
        initTestimonialCarousel();
        initFadeInAnimations();
        initNotificationBadge();
        initPasswordToggle();
    });

    // Theme Toggle
    function initTheme() {
        const themeToggle = document.getElementById('theme-toggle');
        const html = document.documentElement;
        
        // Load saved theme
        const savedTheme = localStorage.getItem('rojgar-theme') || 'light';
        html.setAttribute('data-theme', savedTheme);
        updateThemeIcon(savedTheme);

        if (themeToggle) {
            themeToggle.addEventListener('click', function() {
                const currentTheme = html.getAttribute('data-theme');
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                html.setAttribute('data-theme', newTheme);
                localStorage.setItem('rojgar-theme', newTheme);
                updateThemeIcon(newTheme);
            });
        }
    }

    function updateThemeIcon(theme) {
        const icon = document.querySelector('#theme-toggle i');
        if (icon) {
            icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    }

    // Mobile Menu
    function initMobileMenu() {
        const menuBtn = document.getElementById('mobile-menu-btn');
        const navLinks = document.getElementById('nav-links');

        if (menuBtn && navLinks) {
            menuBtn.addEventListener('click', function() {
                navLinks.classList.toggle('active');
                menuBtn.classList.toggle('active');
            });

            // Close mobile menu when clicking a link
            navLinks.querySelectorAll('a').forEach(function(link) {
                link.addEventListener('click', function() {
                    navLinks.classList.remove('active');
                    menuBtn.classList.remove('active');
                });
            });
        }

        // Dropdown toggle for touch devices
        document.querySelectorAll('.nav-item-dropdown > .dropdown-trigger').forEach(function(trigger) {
            trigger.addEventListener('click', function(e) {
                e.preventDefault();
                var parent = this.parentElement;
                var menu = parent.querySelector('.dropdown-menu');
                if (menu) {
                    menu.classList.toggle('show');
                    var chevron = this.querySelector('.fa-chevron-down');
                    if (chevron) chevron.style.transform = menu.classList.contains('show') ? 'rotate(180deg)' : '';
                }
            });
        });

        // Close dropdowns when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.nav-item-dropdown')) {
                document.querySelectorAll('.dropdown-menu.show').forEach(function(menu) {
                    menu.classList.remove('show');
                    var chevron = menu.closest('.nav-item-dropdown')?.querySelector('.fa-chevron-down');
                    if (chevron) chevron.style.transform = '';
                });
            }
        });
    }

    // Sticky Navigation
    function initStickyNav() {
        const navbar = document.getElementById('navbar');
        if (!navbar) return;

        let lastScroll = 0;
        window.addEventListener('scroll', function() {
            const currentScroll = window.pageYOffset;
            
            if (currentScroll > 100) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }

            lastScroll = currentScroll;
        }, { passive: true });
    }

    // Smooth Scroll
    function initSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
        });
    }

    // Live Search Suggestions
    function initSearchSuggestions() {
        const searchInput = document.getElementById('search-input');
        const suggestionsBox = document.getElementById('search-suggestions');

        if (!searchInput) return;

        let debounceTimer;
        searchInput.addEventListener('input', function() {
            clearTimeout(debounceTimer);
            const query = this.value.trim();

            if (query.length < 2) {
                if (suggestionsBox) suggestionsBox.classList.add('hidden');
                return;
            }

            debounceTimer = setTimeout(function() {
                fetchSuggestions(query);
            }, 300);
        });

        document.addEventListener('click', function(e) {
            if (!e.target.closest('#search-container')) {
                if (suggestionsBox) suggestionsBox.classList.add('hidden');
            }
        });
    }

    function fetchSuggestions(query) {
        const suggestionsBox = document.getElementById('search-suggestions');
        if (!suggestionsBox) return;

        var base = typeof baseUrl !== 'undefined' ? baseUrl.replace(/\/+$/, '') : '';
        fetch(base + '/search/suggestions?q=' + encodeURIComponent(query))
            .then(response => response.json())
            .then(data => {
                if (data.length === 0) {
                    suggestionsBox.classList.add('hidden');
                    return;
                }

                let html = '';
                data.forEach(item => {
                    html += '<a href="/jobs/' + item.id + '" class="suggestion-item">' +
                        '<div class="suggestion-text">' +
                            '<span class="suggestion-title">' + escapeHtml(item.title) + '</span>' +
                            '<span class="suggestion-company">' + escapeHtml(item.company_name) + ' - ' + escapeHtml(item.location) + '</span>' +
                        '</div>' +
                    '</a>';
                });
                suggestionsBox.innerHTML = html;
                suggestionsBox.classList.remove('hidden');
            })
            .catch(() => {});
    }

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text || '';
        return div.innerHTML;
    }

    // Bookmark Toggle
    function initBookmarkToggle() {
        document.querySelectorAll('.bookmark-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const itemId = this.dataset.id;
                const type = this.dataset.type;
                toggleBookmark(this, itemId, type);
            });
        });
    }

    function toggleBookmark(element, itemId, type) {
        var csrfInput = document.querySelector('input[name="csrf_test_name"], input[name="csrf_token"], input[name="ci_csrf_token"]');
        var csrfName = csrfInput ? csrfInput.name : 'csrf_test_name';
        var csrfValue = csrfInput ? csrfInput.value : '';
        var base = typeof baseUrl !== 'undefined' ? baseUrl.replace(/\/+$/, '') : '';
        fetch(base + '/dashboard/bookmark/toggle', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: 'item_id=' + itemId + '&type=' + type + '&' + encodeURIComponent(csrfName) + '=' + encodeURIComponent(csrfValue)
        })
        .then(response => response.json())
        .then(data => {
            const icon = element.querySelector('i');
            const textSpan = element.querySelector('span');
            if (data.bookmarked) {
                element.classList.add('bookmarked');
                if (icon) icon.className = 'fas fa-heart';
                if (textSpan) textSpan.textContent = 'Remove from Wishlist';
                showToast('Added to wishlist!', 'success');
            } else {
                element.classList.remove('bookmarked');
                if (icon) icon.className = 'far fa-heart';
                if (textSpan) textSpan.textContent = 'Add to Wishlist';
                showToast('Removed from wishlist.', 'info');
                var card = element.closest('.glass-card');
                if (card) {
                    card.style.transition = 'opacity 0.3s, transform 0.3s';
                    card.style.opacity = '0';
                    card.style.transform = 'translateY(-10px)';
                    setTimeout(function() { card.remove(); }, 300);
                }
            }
        })
        .catch(() => showToast('Failed to update bookmark.', 'error'));
    }

    // Counter Animation
    function initCounterAnimation() {
        const counters = document.querySelectorAll('.stat-counter');
        if (counters.length === 0) return;

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const counter = entry.target;
                    const target = parseInt(counter.dataset.target);
                    animateCounter(counter, target);
                    observer.unobserve(counter);
                }
            });
        }, { threshold: 0.5 });

        counters.forEach(counter => observer.observe(counter));
    }

    function animateCounter(element, target) {
        const duration = 2000;
        const steps = 60;
        const increment = target / steps;
        let current = 0;
        let step = 0;

        const timer = setInterval(() => {
            step++;
            current += increment;
            if (current >= target) {
                current = target;
                clearInterval(timer);
            }
            element.textContent = formatNumber(Math.floor(current));
        }, duration / steps);
    }

    function formatNumber(num) {
        if (num >= 10000000) return (num / 10000000).toFixed(1) + 'Cr+';
        if (num >= 100000) return (num / 100000).toFixed(1) + 'L+';
        if (num >= 1000) return (num / 1000).toFixed(1) + 'K+';
        return num.toString();
    }

    // Testimonial Carousel
    function initTestimonialCarousel() {
        const carousel = document.getElementById('testimonial-carousel');
        if (!carousel) return;

        let currentSlide = 0;
        const slides = carousel.querySelectorAll('.testimonial-slide');
        if (slides.length === 0) return;

        function showSlide(index) {
            slides.forEach((slide, i) => {
                slide.style.display = i === index ? 'block' : 'none';
            });
        }

        showSlide(0);

        setInterval(() => {
            currentSlide = (currentSlide + 1) % slides.length;
            showSlide(currentSlide);
        }, 5000);
    }

    // Fade-in Animations on Scroll
    function initFadeInAnimations() {
        const elements = document.querySelectorAll('.animate-on-scroll');
        if (elements.length === 0) return;

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-fade-up');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });

        elements.forEach(el => observer.observe(el));
    }

    // Notification Badge
    function initNotificationBadge() {
        const badge = document.getElementById('notification-badge');
        if (!badge) return;

        fetch('/api/notifications/unread-count')
            .then(response => response.json())
            .then(data => {
                if (data.count > 0) {
                    badge.textContent = data.count;
                    badge.classList.remove('hidden');
                }
            })
            .catch(() => {});
    }

    // Password Toggle Visibility
    function initPasswordToggle() {
        document.querySelectorAll('.password-toggle').forEach(btn => {
            btn.addEventListener('click', function() {
                const input = this.parentElement.querySelector('input');
                const icon = this.querySelector('i');
                
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.className = 'fas fa-eye-slash';
                } else {
                    input.type = 'password';
                    icon.className = 'fas fa-eye';
                }
            });
        });
    }

    // Toast Notification System
    function showToast(message, type = 'info') {
        const container = document.getElementById('toast-container');
        if (!container) return;

        const toast = document.createElement('div');
        toast.className = 'toast toast-' + type;
        toast.innerHTML = message;
        
        container.appendChild(toast);

        setTimeout(() => {
            toast.classList.add('toast-hide');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    // Add Toast Container
    const toastContainer = document.createElement('div');
    toastContainer.id = 'toast-container';
    toastContainer.className = 'toast-container';
    document.body.appendChild(toastContainer);

    // Add CSS for toast
    const toastStyle = document.createElement('style');
    toastStyle.textContent = `
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .toast {
            padding: 14px 20px;
            border-radius: 12px;
            font-size: 0.875rem;
            font-weight: 500;
            box-shadow: 0 8px 32px rgba(0,0,0,0.12);
            animation: slideInRight 0.3s ease;
            max-width: 360px;
        }
        .toast-success { background: #10b981; color: white; }
        .toast-error { background: #ef4444; color: white; }
        .toast-info { background: #3b82f6; color: white; }
        .toast-warning { background: #f59e0b; color: white; }
        .toast-hide {
            animation: fadeOut 0.3s ease forwards;
        }
        @keyframes fadeOut {
            to { opacity: 0; transform: translateX(100px); }
        }
    `;
    document.head.appendChild(toastStyle);

})();
