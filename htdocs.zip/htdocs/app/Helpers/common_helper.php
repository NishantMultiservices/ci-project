<?php

if (!function_exists('time_ago')) {
    function time_ago(string $datetime): string
    {
        $timestamp = strtotime($datetime);
        $diff = time() - $timestamp;
        
        if ($diff < 60) return 'Just now';
        if ($diff < 3600) return floor($diff / 60) . ' minutes ago';
        if ($diff < 86400) return floor($diff / 3600) . ' hours ago';
        if ($diff < 604800) return floor($diff / 86400) . ' days ago';
        if ($diff < 2592000) return floor($diff / 604800) . ' weeks ago';
        return date('d M Y', $timestamp);
    }
}

if (!function_exists('format_salary')) {
    function format_salary($min, $max = null, $text = null): string
    {
        if ($text) return $text;
        if (!$min) return 'Negotiable';
        $result = '₹ ' . number_format($min);
        if ($max) $result .= ' - ₹ ' . number_format($max);
        return $result . '/month';
    }
}

if (!function_exists('truncate_text')) {
    function truncate_text(string $text, int $limit = 100): string
    {
        if (mb_strlen($text) <= $limit) return $text;
        return mb_substr($text, 0, $limit) . '...';
    }
}

if (!function_exists('generate_slug')) {
    function generate_slug(string $string): string
    {
        $string = preg_replace('/[^a-zA-Z0-9\s-]/', '', $string);
        $string = preg_replace('/[\s-]+/', '-', $string);
        $string = trim($string, '-');
        return strtolower($string);
    }
}

if (!function_exists('get_status_badge')) {
    function get_status_badge(string $status): string
    {
        $badges = [
            'pending' => 'warning',
            'shortlisted' => 'info',
            'accepted' => 'success',
            'rejected' => 'danger',
            'active' => 'success',
            'inactive' => 'secondary',
        ];
        $class = $badges[$status] ?? 'secondary';
        return '<span class="badge badge-' . $class . '">' . ucfirst($status) . '</span>';
    }
}

if (!function_exists('format_date')) {
    function format_date(string $date, string $format = 'd M, Y'): string
    {
        if (!$date || $date === '0000-00-00') return 'N/A';
        return date($format, strtotime($date));
    }
}

if (!function_exists('days_remaining')) {
    function days_remaining(?string $date): string
    {
        if (!$date) return 'No deadline';
        $remaining = ceil((strtotime($date) - time()) / 86400);
        if ($remaining < 0) return 'Expired';
        if ($remaining === 0) return 'Today';
        return $remaining . ' days remaining';
    }
}

if (!function_exists('get_gravatar')) {
    function get_gravatar(string $email, int $size = 80): string
    {
        $hash = md5(strtolower(trim($email)));
        return 'https://www.gravatar.com/avatar/' . $hash . '?s=' . $size . '&d=mp';
    }
}
