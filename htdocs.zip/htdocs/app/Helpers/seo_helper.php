<?php

if (!function_exists('meta_title')) {
    function meta_title(string $title = ''): string
    {
        $settings = \Config\Services::settings();
        $siteName = $settings['site_name'] ?? 'RojgarSandhi';
        $metaTitle = $settings['meta_title'] ?? $siteName . ' - Your Gateway to Jobs, Skills & Career Success';

        if (empty($title)) {
            return $metaTitle;
        }
        return $title . ' | ' . $siteName;
    }
}

if (!function_exists('meta_description')) {
    function meta_description(string $description = ''): string
    {
        $settings = \Config\Services::settings();
        $defaultDesc = $settings['meta_description'] ?? 'India\'s premier career platform connecting millions of job seekers with government jobs, private jobs, internships, and skill development courses.';

        if (empty($description)) {
            return $defaultDesc;
        }
        return $description;
    }
}

if (!function_exists('og_tags')) {
    function og_tags(array $data = []): string
    {
        $defaults = [
            'title' => meta_title(),
            'description' => meta_description(),
            'image' => base_url('assets/images/og-image.jpg'),
            'url' => current_url(),
            'type' => 'website',
        ];
        $data = array_merge($defaults, $data);
        
        $tags = '';
        $tags .= '<meta property="og:title" content="' . esc($data['title']) . '">' . "\n";
        $tags .= '<meta property="og:description" content="' . esc($data['description']) . '">' . "\n";
        $tags .= '<meta property="og:image" content="' . $data['image'] . '">' . "\n";
        $tags .= '<meta property="og:url" content="' . $data['url'] . '">' . "\n";
        $tags .= '<meta property="og:type" content="' . $data['type'] . '">' . "\n";
        $tags .= '<meta name="twitter:card" content="summary_large_image">' . "\n";
        $tags .= '<meta name="twitter:title" content="' . esc($data['title']) . '">' . "\n";
        $tags .= '<meta name="twitter:description" content="' . esc($data['description']) . '">' . "\n";
        $tags .= '<meta name="twitter:image" content="' . $data['image'] . '">' . "\n";
        return $tags;
    }
}

if (!function_exists('json_ld')) {
    function json_ld(array $data = []): string
    {
        $settings = \Config\Services::settings();
        $siteName = $settings['site_name'] ?? 'RojgarSandhi';

        $defaults = [
            '@context' => 'https://schema.org',
            '@type' => 'WebSite',
            'name' => $siteName,
            'url' => base_url(),
            'description' => meta_description(),
        ];
        $data = array_merge($defaults, $data);
        return '<script type="application/ld+json">' . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . '</script>';
    }
}

if (!function_exists('breadcrumb_schema')) {
    function breadcrumb_schema(array $items = []): string
    {
        if (empty($items)) return '';
        
        $schema = [
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => []
        ];
        
        foreach ($items as $index => $item) {
            $schema['itemListElement'][] = [
                '@type' => 'ListItem',
                'position' => $index + 1,
                'name' => $item['name'],
                'item' => $item['url'] ?? base_url()
            ];
        }
        
        return '<script type="application/ld+json">' . json_encode($schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . '</script>';
    }
}
