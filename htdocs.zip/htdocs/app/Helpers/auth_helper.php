<?php

if (!function_exists('is_logged_in')) {
    function is_logged_in(): bool
    {
        return session()->has('user_id');
    }
}

if (!function_exists('current_user')) {
    function current_user(): ?array
    {
        return session()->get('user_data');
    }
}

if (!function_exists('is_admin')) {
    function is_admin(): bool
    {
        return session()->get('user_role') === 'admin';
    }
}

if (!function_exists('user_id')) {
    function user_id(): ?int
    {
        return session()->get('user_id');
    }
}

if (!function_exists('require_login')) {
    function require_login()
    {
        if (!is_logged_in()) {
            return redirect()->to('/login')->with('error', 'Please login to continue.');
        }
    }
}

if (!function_exists('require_admin')) {
    function require_admin()
    {
        if (!is_admin()) {
            return redirect()->to('/')->with('error', 'Access denied.');
        }
    }
}
