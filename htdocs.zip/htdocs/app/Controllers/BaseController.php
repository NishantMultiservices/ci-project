<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

class BaseController extends Controller
{
    protected $helpers = ['auth', 'seo', 'common', 'form', 'html', 'text', 'url'];

    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);
    }

    protected function render(string $view, array $data = []): string
    {
        $data = array_merge([
            'title' => meta_title(),
            'description' => meta_description(),
            'og_tags' => og_tags(),
            'json_ld' => json_ld(),
            'is_logged_in' => is_logged_in(),
            'current_user' => current_user(),
            'is_admin' => is_admin(),
            'settings' => $this->getSettings(),
        ], $data);

        return view('layouts/header', $data)
            . view($view, $data)
            . view('layouts/footer', $data);
    }

    protected function renderAdmin(string $view, array $data = []): string
    {
        $data = array_merge([
            'title' => meta_title('Admin Panel'),
            'is_logged_in' => is_logged_in(),
            'current_user' => current_user(),
        ], $data);

        return view('admin/partials/header', $data)
            . view('admin/partials/sidebar', $data)
            . view($view, $data)
            . view('admin/partials/footer', $data);
    }

    protected function renderDashboard(string $view, array $data = []): string
    {
        $data = array_merge([
            'title' => meta_title('Dashboard'),
            'is_logged_in' => is_logged_in(),
            'current_user' => current_user(),
        ], $data);

        return view('dashboard/partials/header', $data)
            . view('dashboard/partials/sidebar', $data)
            . view($view, $data)
            . view('dashboard/partials/footer', $data);
    }

    private function getSettings(): array
    {
        $settingModel = model('App\Models\SettingModel');
        return $settingModel->getGroup('general')
            + $settingModel->getGroup('social')
            + $settingModel->getGroup('seo');
    }

    protected function jsonResponse(array $data, int $statusCode = 200): void
    {
        $this->response->setStatusCode($statusCode);
        $this->response->setContentType('application/json');
        $this->response->setBody(json_encode($data));
        $this->response->send();
        exit;
    }
}
