<?php

namespace App\Controllers;

class AnswerKeys extends BaseController
{
    public function index()
    {
        $answerKeyModel = model('App\Models\AnswerKeyModel');
        $data = [
            'title' => meta_title('Answer Keys'),
            'description' => 'Download answer keys for recent exams.',
            'answer_keys' => $answerKeyModel->getLatest(20),
        ];
        return $this->render('answer_keys/index', $data);
    }

    public function detail($id)
    {
        $answerKeyModel = model('App\Models\AnswerKeyModel');
        $answerKey = $answerKeyModel->find($id);

        if (!$answerKey || !$answerKey['is_active']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $answerKeyModel->incrementViews($id);

        $data = [
            'title' => meta_title($answerKey['title'] . ' - Answer Key'),
            'answer_key' => $answerKey,
        ];
        return $this->render('answer_keys/detail', $data);
    }
}
