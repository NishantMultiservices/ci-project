<?php

namespace App\Controllers;

class InterviewPrep extends BaseController
{
    public function index()
    {
        $interviewModel = model('App\Models\InterviewTopicModel');
        $category = $this->request->getGet('category');
        $examCategory = $this->request->getGet('exam');

        if ($category) {
            $topics = $interviewModel->getByCategory($category);
        } elseif ($examCategory) {
            $topics = $interviewModel->getByExamCategory($examCategory);
        } else {
            $topics = $interviewModel->getActive(30);
        }

        $data = [
            'title' => meta_title('Interview Preparation'),
            'description' => 'Prepare for interviews with HR questions, technical questions, and mock tests.',
            'topics' => $topics,
            'categories' => ['hr', 'technical', 'aptitude', 'reasoning', 'english', 'mock'],
            'exam_categories' => ['banking', 'railway', 'ssc', 'upsc', 'technical', 'it'],
        ];
        return $this->render('interview_prep/index', $data);
    }

    public function topic($slug)
    {
        $interviewModel = model('App\Models\InterviewTopicModel');
        $topic = $interviewModel->where('slug', $slug)->where('is_active', 1)->first();

        if (!$topic) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $data = [
            'title' => meta_title($topic['title'] . ' - Interview Preparation'),
            'topic' => $topic,
        ];
        return $this->render('interview_prep/detail', $data);
    }
}
