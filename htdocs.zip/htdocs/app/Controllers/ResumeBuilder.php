<?php

namespace App\Controllers;

class ResumeBuilder extends BaseController
{
    public function index()
    {
        if (!is_logged_in()) {
            return redirect()->to('/login')->with('error', 'Please login to build your resume.');
        }

        $resumeModel = model('App\Models\ResumeModel');
        $resumes = $resumeModel->getUserResumes(user_id());

        $data = [
            'title' => meta_title('Resume Builder'),
            'description' => 'Create professional resumes with multiple templates.',
            'resumes' => $resumes,
        ];
        return $this->render('resume_builder/index', $data);
    }

    public function save()
    {
        if (!is_logged_in()) {
            return $this->jsonResponse(['error' => 'Unauthorized'], 401);
        }

        $resumeModel = model('App\Models\ResumeModel');
        $data = $this->request->getJSON(true);
        $data['user_id'] = user_id();

        $id = $this->request->getPost('id');
        if ($id) {
            $resumeModel->update($id, $data);
        } else {
            $id = $resumeModel->insert($data);
        }

        return $this->jsonResponse(['success' => true, 'id' => $id]);
    }

    public function preview($id)
    {
        $resumeModel = model('App\Models\ResumeModel');
        $resume = $resumeModel->find($id);

        if (!$resume || $resume['user_id'] !== user_id()) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $data = [
            'title' => meta_title('Resume Preview'),
            'resume' => $resume,
        ];
        return $this->render('resume_builder/preview', $data);
    }

    public function download($id)
    {
        $resumeModel = model('App\Models\ResumeModel');
        $resume = $resumeModel->find($id);

        if (!$resume || $resume['user_id'] !== user_id()) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        return $this->response->download('resume_' . $resume['id'] . '.pdf', null);
    }
}
