<?php

namespace App\Controllers;

class Courses extends BaseController
{
    public function index()
    {
        $courseModel = model('App\Models\CourseModel');
        $catModel = model('App\Models\CategoryModel');

        $data = [
            'title' => meta_title('Skill Development Courses'),
            'description' => 'Browse skill development courses in programming, AI, data science, and more.',
            'courses' => $courseModel->getLatest(20),
            'categories' => $catModel->getCourseCategories(),
        ];
        return $this->render('courses/index', $data);
    }

    public function detail($id)
    {
        $courseModel = model('App\Models\CourseModel');
        $course = $courseModel->find($id);

        if (!$course || !$course['is_active']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $courseModel->incrementViews($id);

        $bookmarked = false;
        $enrolled = false;
        $hasPaidCourse = false;
        if (is_logged_in()) {
            $bookmarked = model('App\Models\BookmarkModel')->isBookmarked(user_id(), $id, 'course');
            $enrolled = model('App\Models\EnrollmentModel')->isEnrolled(user_id(), $id);
            if (!$course['is_free']) {
                $hasPaidCourse = model('App\Models\PaymentModel')->hasPaid(user_id(), 'course', $id);
            }
        }

        $data = [
            'title' => meta_title($course['title']),
            'description' => $course['short_description'],
            'course' => $course,
            'isBookmarked' => $bookmarked,
            'isEnrolled' => $enrolled,
            'hasPaidCourse' => $hasPaidCourse,
        ];
        return $this->render('courses/detail', $data);
    }

    public function enroll($id)
    {
        if (!is_logged_in()) {
            return redirect()->to('/login')->with('error', 'Please login to enroll.');
        }

        $courseModel = model('App\Models\CourseModel');
        $course = $courseModel->find($id);
        if (!$course || !$course['is_active']) {
            return redirect()->back()->with('error', 'Course not found.');
        }

        if (!$course['is_free'] && !model('App\Models\PaymentModel')->hasPaid(user_id(), 'course', $id)) {
            return redirect()->to('/courses/' . $id)->with('error', 'Please purchase this course to access it.');
        }

        $enrollmentModel = model('App\Models\EnrollmentModel');
        if ($enrollmentModel->isEnrolled(user_id(), $id)) {
            return redirect()->back()->with('info', 'You are already enrolled in this course.');
        }

        $enrollmentModel->enroll(user_id(), $id);
        $courseModel->set('total_enrolled', 'total_enrolled + 1', false)->where('id', $id)->update();

        return redirect()->to('/courses/' . $id)->with('success', 'Successfully enrolled in the course!');
    }

    public function unenroll($id)
    {
        if (!is_logged_in()) {
            return redirect()->to('/login')->with('error', 'Please login.');
        }

        $enrollmentModel = model('App\Models\EnrollmentModel');
        $enrollment = $enrollmentModel->where('user_id', user_id())->where('course_id', $id)->first();
        if ($enrollment) {
            $enrollmentModel->delete($enrollment['id']);
        }

        return redirect()->to('/courses/' . $id)->with('info', 'Unenrolled from the course.');
    }

    public function learn($id)
    {
        if (!is_logged_in()) {
            return redirect()->to('/login')->with('error', 'Please login to access course content.');
        }

        $courseModel = model('App\Models\CourseModel');
        $course = $courseModel->find($id);
        if (!$course || !$course['is_active']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $enrollmentModel = model('App\Models\EnrollmentModel');
        if (!$enrollmentModel->isEnrolled(user_id(), $id)) {
            return redirect()->to('/courses/' . $id)->with('error', 'Please enroll first to access course content.');
        }

        $lessons = model('App\Models\CourseLessonModel')->getCourseLessons($id);

        $lessonId = $this->request->getGet('lesson');
        $currentLesson = null;
        if ($lessonId) {
            foreach ($lessons as $l) {
                if ($l['id'] == $lessonId) { $currentLesson = $l; break; }
            }
        }
        if (!$currentLesson && !empty($lessons)) {
            $currentLesson = $lessons[0];
        }

        $completedLessonIds = model('App\Models\LessonCompletionModel')->getCompletedLessonIds(user_id(), $id);
        $allCompleted = !empty($lessons) && count($completedLessonIds) >= count($lessons);
        $hasCertificate = model('App\Models\CertificateModel')->hasCertificate(user_id(), $id);

        $quizQuestions = [];
        $quizAttempt = null;
        $quizAnswers = [];
        if ($currentLesson && $currentLesson['content_type'] === 'quiz') {
            $quizQuestions = model('App\Models\LessonQuizQuestionModel')->getLessonQuestions($currentLesson['id']);
            $quizAttempt = model('App\Models\LessonQuizAttemptModel')->getAttempt(user_id(), $currentLesson['id']);
            if ($quizAttempt) {
                $quizAnswers = model('App\Models\LessonQuizAnswerModel')->where('attempt_id', $quizAttempt['id'])->findAll();
            }
        }

        $data = [
            'title' => meta_title($course['title'] . ' - Learn'),
            'course' => $course,
            'lessons' => $lessons,
            'currentLesson' => $currentLesson,
            'completedLessonIds' => $completedLessonIds,
            'allCompleted' => $allCompleted,
            'hasCertificate' => $hasCertificate,
            'quizQuestions' => $quizQuestions,
            'quizAttempt' => $quizAttempt,
            'quizAnswers' => $quizAnswers,
        ];
        return $this->render('courses/learn', $data);
    }

    public function submitQuiz()
    {
        if (!is_logged_in()) {
            return $this->jsonResponse(['error' => 'Unauthorized'], 401);
        }

        $lessonId = $this->request->getPost('lesson_id');
        $lesson = model('App\Models\CourseLessonModel')->find($lessonId);
        if (!$lesson || $lesson['content_type'] !== 'quiz') {
            return $this->jsonResponse(['error' => 'Invalid lesson'], 404);
        }

        $attemptModel = model('App\Models\LessonQuizAttemptModel');
        if ($attemptModel->hasAttempted(user_id(), $lessonId)) {
            return $this->jsonResponse(['error' => 'Quiz already attempted']);
        }

        $questions = model('App\Models\LessonQuizQuestionModel')->getLessonQuestions($lessonId);
        if (empty($questions)) {
            return $this->jsonResponse(['error' => 'No questions in this quiz']);
        }

        $totalMarks = 0;
        $obtainedMarks = 0;
        $correctCount = 0;
        $answers = [];

        foreach ($questions as $q) {
            $selected = $this->request->getPost('q_' . $q['id']);
            $totalMarks += $q['marks'];
            $isCorrect = ($selected === $q['correct_option']);
            if ($isCorrect) {
                $obtainedMarks += $q['marks'];
                $correctCount++;
            }
            $answers[] = [
                'question_id' => $q['id'],
                'selected_option' => $selected,
                'is_correct' => $isCorrect ? 1 : 0,
                'marks_obtained' => $isCorrect ? $q['marks'] : 0,
            ];
        }

        $passingMarks = $totalMarks * 0.33;
        $passed = ($obtainedMarks >= $passingMarks) ? 1 : 0;

        $attemptId = $attemptModel->insert([
            'user_id' => user_id(),
            'lesson_id' => $lessonId,
            'course_id' => $lesson['course_id'],
            'total_marks' => $totalMarks,
            'obtained_marks' => $obtainedMarks,
            'total_questions' => count($questions),
            'correct_answers' => $correctCount,
            'passed' => $passed,
        ]);

        if ($attemptId) {
            $answerModel = model('App\Models\LessonQuizAnswerModel');
            foreach ($answers as &$a) {
                $a['attempt_id'] = $attemptId;
                $answerModel->insert($a);
            }

            model('App\Models\LessonCompletionModel')->markComplete(user_id(), $lessonId, $lesson['course_id']);
        }

        return $this->jsonResponse([
            'success' => true,
            'total_marks' => $totalMarks,
            'obtained_marks' => $obtainedMarks,
            'total_questions' => count($questions),
            'correct_answers' => $correctCount,
            'passed' => $passed,
        ]);
    }

    public function markLesson()
    {
        if (!is_logged_in()) {
            return $this->jsonResponse(['error' => 'Unauthorized'], 401);
        }

        $id = $this->request->getPost('lesson_id');
        $lesson = model('App\Models\CourseLessonModel')->find($id);
        if (!$lesson) {
            return $this->jsonResponse(['error' => 'Lesson not found'], 404);
        }

        model('App\Models\LessonCompletionModel')->markComplete(user_id(), $id, $lesson['course_id']);

        $totalLessons = count(model('App\Models\CourseLessonModel')->getCourseLessons($lesson['course_id']));
        $completedCount = count(model('App\Models\LessonCompletionModel')->getCompletedLessonIds(user_id(), $lesson['course_id']));
        $allDone = $completedCount >= $totalLessons;

        return $this->jsonResponse([
            'completed' => true,
            'completedCount' => $completedCount,
            'totalLessons' => $totalLessons,
            'allCompleted' => $allDone,
        ]);
    }

    public function complete($id)
    {
        if (!is_logged_in()) {
            return redirect()->to('/login')->with('error', 'Please login.');
        }

        $course = model('App\Models\CourseModel')->find($id);
        if (!$course || !$course['is_active']) {
            return redirect()->back()->with('error', 'Course not found.');
        }

        $enrollmentModel = model('App\Models\EnrollmentModel');
        if (!$enrollmentModel->isEnrolled(user_id(), $id)) {
            return redirect()->back()->with('error', 'You are not enrolled in this course.');
        }

        $lessons = model('App\Models\CourseLessonModel')->getCourseLessons($id);
        $completedIds = model('App\Models\LessonCompletionModel')->getCompletedLessonIds(user_id(), $id);
        if (count($completedIds) < count($lessons)) {
            return redirect()->to('/courses/learn/' . $id)->with('error', 'Complete all lessons before earning your certificate.');
        }

        $cert = model('App\Models\CertificateModel')->generate(user_id(), $id);
        if ($cert) {
            $enrollmentModel->where('user_id', user_id())->where('course_id', $id)->set(['status' => 'completed'])->update();
            return redirect()->to('/certificates/view/' . $id)->with('success', 'Congratulations! Certificate earned.');
        }

        return redirect()->to('/courses/learn/' . $id)->with('error', 'Failed to generate certificate.');
    }
}
