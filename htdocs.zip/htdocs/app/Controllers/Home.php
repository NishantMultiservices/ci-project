<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        $jobModel = model('App\Models\JobModel');
        $internshipModel = model('App\Models\InternshipModel');
        $courseModel = model('App\Models\CourseModel');
        $scholarshipModel = model('App\Models\ScholarshipModel');
        $blogModel = model('App\Models\BlogModel');
        $testimonialModel = model('App\Models\TestimonialModel');
        $catModel = model('App\Models\CategoryModel');

        $data = [
            'featured_jobs' => $jobModel->getGovernment(6),
            'latest_jobs' => $jobModel->getLatest(12),
            'trending_jobs' => $jobModel->getTrending(4),
            'government_jobs' => $jobModel->getGovernment(6),
            'private_jobs' => $jobModel->getPrivate(6),
            'internships' => $internshipModel->getLatest(6),
            'featured_courses' => $courseModel->getFeatured(6),
            'scholarships' => $scholarshipModel->getLatest(4),
            'blogs' => $blogModel->getPublished(3),
            'testimonials' => $testimonialModel->getApproved(5),
            'categories' => $catModel->getJobCategories(),
            'stats' => [
                'jobs' => $jobModel->getTotalJobs(),
                'students' => (new \App\Models\UserModel())->getTotalUsers(),
                'courses' => $courseModel->getTotalCourses(),
                'companies' => 500,
            ],
            'admit_cards' => model('App\Models\AdmitCardModel')->getLatest(5),
            'answer_keys' => model('App\Models\AnswerKeyModel')->getLatest(5),
            'latest_results' => model('App\Models\ResultModel')->getLatest(5),
        ];

        return $this->render('home/index', $data);
    }

    public function subscribe()
    {
        $email = $this->request->getPost('email');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return redirect()->back()->with('error', 'Invalid email address.');
        }

        $newsletterModel = model('App\Models\NewsletterModel');
        $newsletterModel->subscribe($email);

        return redirect()->back()->with('success', 'Successfully subscribed to newsletter!');
    }
}
