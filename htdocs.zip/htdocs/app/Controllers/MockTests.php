<?php

namespace App\Controllers;

class MockTests extends BaseController
{
    public function index()
    {
        $data = [
            'title' => meta_title('Mock Tests'),
            'description' => 'Practice with free mock tests for competitive exams. Timed tests with instant results and detailed analysis.',
            'mockTests' => model('App\Models\MockTestModel')->getActive(20),
        ];
        return $this->render('mock_tests/index', $data);
    }

    public function detail($slug)
    {
        $test = model('App\Models\MockTestModel')->getBySlug($slug);
        if (!$test) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $questions = model('App\Models\MockTestQuestionModel')->getByMockTestId($test['id']);

        $hasPaid = false;
        if (is_logged_in() && !$test['is_free']) {
            $hasPaid = model('App\Models\PaymentModel')->hasPaid(user_id(), 'mock_test', $test['id']);
        }

        $data = [
            'title' => meta_title($test['title']),
            'description' => truncate_text($test['description'] ?? 'Take the ' . $test['title'] . ' mock test.'),
            'test' => $test,
            'questions' => $questions,
            'hasPaid' => $hasPaid,
        ];
        return $this->render('mock_tests/detail', $data);
    }

    public function attempt($slug)
    {
        if (!is_logged_in()) {
            return redirect()->to('/login')->with('error', 'Please login to take mock tests.');
        }

        $test = model('App\Models\MockTestModel')->getBySlug($slug);
        if (!$test) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        if (!$test['is_free'] && !model('App\Models\PaymentModel')->hasPaid(user_id(), 'mock_test', $test['id'])) {
            return redirect()->to('/mock-tests/' . $test['slug'])->with('error', 'Please purchase this test to access it.');
        }

        $attemptModel = model('App\Models\MockTestAttemptModel');
        $existing = $attemptModel->getIncompleteAttempt(user_id(), $test['id']);
        if ($existing) {
            $attemptId = $existing['id'];
        } else {
            $attemptId = $attemptModel->insert([
                'mock_test_id' => $test['id'],
                'user_id' => user_id(),
                'status' => 'in_progress',
            ]);
        }

        $questions = model('App\Models\MockTestQuestionModel')->getByMockTestId($test['id']);

        $data = [
            'title' => meta_title($test['title'] . ' - Attempt'),
            'test' => $test,
            'questions' => $questions,
            'attemptId' => $attemptId,
        ];
        return $this->render('mock_tests/attempt', $data);
    }

    public function submit()
    {
        if (!is_logged_in()) {
            return redirect()->to('/login')->with('error', 'Please login to submit mock tests.');
        }

        $attemptId = $this->request->getPost('attempt_id');
        $answers = $this->request->getPost('answers');

        $attemptModel = model('App\Models\MockTestAttemptModel');
        $attempt = $attemptModel->find($attemptId);
        if (!$attempt || $attempt['user_id'] != user_id()) {
            return redirect()->to('/mock-tests')->with('error', 'Invalid attempt.');
        }

        $questionModel = model('App\Models\MockTestQuestionModel');
        $answerModel = model('App\Models\MockTestAnswerModel');

        $questions = $questionModel->getByMockTestId($attempt['mock_test_id']);
        $score = 0;
        $correctCount = 0;
        $incorrectCount = 0;
        $unansweredCount = 0;
        $totalMarks = 0;

        foreach ($questions as $q) {
            $totalMarks += $q['marks'];
            $selected = $answers[$q['id']] ?? null;

            if (empty($selected)) {
                $unansweredCount++;
                $answerModel->insert([
                    'attempt_id' => $attemptId,
                    'question_id' => $q['id'],
                    'selected_answer' => null,
                    'is_correct' => 0,
                    'marks_obtained' => 0,
                ]);
                continue;
            }

            $isCorrect = ($selected === $q['correct_answer']);
            $marksObtained = $isCorrect ? $q['marks'] : -$q['negative_marks'];

            if ($isCorrect) {
                $correctCount++;
                $score += $q['marks'];
            } else {
                $incorrectCount++;
                $score -= $q['negative_marks'];
            }

            $answerModel->insert([
                'attempt_id' => $attemptId,
                'question_id' => $q['id'],
                'selected_answer' => $selected,
                'is_correct' => $isCorrect ? 1 : 0,
                'marks_obtained' => $marksObtained,
            ]);
        }

        if ($score < 0) $score = 0;

        $attemptModel->update($attemptId, [
            'completed_at' => date('Y-m-d H:i:s'),
            'score' => $score,
            'total_marks' => $totalMarks,
            'correct_count' => $correctCount,
            'incorrect_count' => $incorrectCount,
            'unanswered_count' => $unansweredCount,
            'status' => 'completed',
        ]);

        model('App\Models\MockTestModel')->incrementAttempts($attempt['mock_test_id']);

        return redirect()->to('/mock-tests/result/' . $attemptId)->with('success', 'Test submitted successfully!');
    }

    public function result($attemptId)
    {
        if (!is_logged_in()) {
            return redirect()->to('/login')->with('error', 'Please login to view results.');
        }

        $attemptModel = model('App\Models\MockTestAttemptModel');
        $attempt = $attemptModel->getWithTest($attemptId);
        if (!$attempt || $attempt['user_id'] != user_id()) {
            return redirect()->to('/mock-tests')->with('error', 'Result not found.');
        }

        $answers = model('App\Models\MockTestAnswerModel')->getWithQuestions($attemptId);

        $data = [
            'title' => meta_title('Test Result'),
            'attempt' => $attempt,
            'answers' => $answers,
        ];
        return $this->render('mock_tests/result', $data);
    }
}
