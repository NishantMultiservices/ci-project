<?php

namespace App\Controllers;

class Blog extends BaseController
{
    public function index()
    {
        $blogModel = model('App\Models\BlogModel');
        $catModel = model('App\Models\CategoryModel');

        $data = [
            'title' => meta_title('Blog'),
            'description' => 'Read articles on careers, exam preparation, and skill development.',
            'blogs' => $blogModel->getPublished(12),
            'categories' => $catModel->getByType('blog'),
        ];
        return $this->render('blog/index', $data);
    }

    public function detail($slug)
    {
        $blogModel = model('App\Models\BlogModel');
        $blog = $blogModel->getBySlug($slug);

        if (!$blog) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $blogModel->incrementViews($blog['id']);

        $data = [
            'title' => meta_title($blog['title']),
            'description' => $blog['excerpt'] ?? truncate_text(strip_tags($blog['content']), 160),
            'blog' => $blog,
            'related_blogs' => $blogModel->getRelated($blog['id'], $blog['category_id'], 3),
            'og_tags' => og_tags([
                'title' => $blog['title'] . ' - RojgarSandhi Blog',
                'description' => truncate_text(strip_tags($blog['content'] ?? ''), 160),
                'image' => $blog['featured_image'] ? base_url($blog['featured_image']) : base_url('assets/images/og-image.jpg'),
                'type' => 'article',
            ]),
        ];
        return $this->render('blog/detail', $data);
    }
}
