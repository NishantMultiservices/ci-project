<?php

namespace App\Controllers;

class Apprenticeships extends BaseController
{
    public function index()
    {
        $apprenticeshipModel = model('App\Models\ApprenticeshipModel');
        $type = $this->request->getGet('type');

        $data = [
            'title' => meta_title('Apprenticeships'),
            'description' => 'Find NAPS, NATS, and company apprenticeships.',
            'apprenticeships' => $type ? $apprenticeshipModel->getByType($type, 20) : $apprenticeshipModel->getLatest(20),
        ];
        return $this->render('apprenticeships/index', $data);
    }

    public function detail($id)
    {
        $apprenticeshipModel = model('App\Models\ApprenticeshipModel');
        $apprenticeship = $apprenticeshipModel->find($id);

        if (!$apprenticeship || !$apprenticeship['is_active']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $apprenticeshipModel->incrementViews($id);

        $data = [
            'title' => meta_title($apprenticeship['title'] . ' - Apprenticeship'),
            'apprenticeship' => $apprenticeship,
        ];
        return $this->render('apprenticeships/detail', $data);
    }
}
