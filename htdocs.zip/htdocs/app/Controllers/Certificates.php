<?php

namespace App\Controllers;

class Certificates extends BaseController
{
    public function view($courseId)
    {
        if (!is_logged_in()) {
            return redirect()->to('/login')->with('error', 'Please login.');
        }

        $cert = model('App\Models\CertificateModel')
            ->where('user_id', user_id())
            ->where('course_id', $courseId)
            ->first();

        if (!$cert) {
            return redirect()->to('/dashboard/my-courses')->with('error', 'Certificate not found.');
        }

        $course = model('App\Models\CourseModel')->find($courseId);
        $user = model('App\Models\UserModel')->find(user_id());

        $data = [
            'title' => 'Certificate - ' . $course['title'],
            'cert' => $cert,
            'course' => $course,
            'user' => $user,
        ];
        return view('certificates/view', $data);
    }
}
