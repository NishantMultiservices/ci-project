<?php

namespace App\Controllers;

class Internships extends BaseController
{
    public function index()
    {
        $internshipModel = model('App\Models\InternshipModel');
        $type = $this->request->getGet('type');

        $data = [
            'title' => meta_title('Internships'),
            'description' => 'Find paid, remote, campus, and summer internships.',
            'internships' => $type ? $internshipModel->getByType($type, 20) : $internshipModel->getLatest(20),
            'types' => ['paid', 'remote', 'campus', 'summer'],
        ];
        return $this->render('internships/index', $data);
    }

    public function detail($id)
    {
        $internshipModel = model('App\Models\InternshipModel');
        $internship = $internshipModel->find($id);

        if (!$internship || !$internship['is_active']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $internshipModel->incrementViews($id);

        $data = [
            'title' => meta_title($internship['title'] . ' Internship'),
            'internship' => $internship,
        ];
        return $this->render('internships/detail', $data);
    }
}
