<?php

namespace App\Controllers;

class Results extends BaseController
{
    public function index()
    {
        $resultModel = model('App\Models\ResultModel');
        $data = [
            'title' => meta_title('Exam Results'),
            'description' => 'Check latest exam results.',
            'results' => $resultModel->getLatest(20),
        ];
        return $this->render('results/index', $data);
    }

    public function detail($id)
    {
        $resultModel = model('App\Models\ResultModel');
        $result = $resultModel->find($id);

        if (!$result || !$result['is_active']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $resultModel->incrementViews($id);

        $data = [
            'title' => meta_title($result['title'] . ' - Result'),
            'result' => $result,
        ];
        return $this->render('results/detail', $data);
    }
}
