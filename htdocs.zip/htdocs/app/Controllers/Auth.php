<?php

namespace App\Controllers;

class Auth extends BaseController
{
    public function login()
    {
        if (is_logged_in()) {
            return redirect()->to('/dashboard');
        }

        $data = [
            'title' => meta_title('Login'),
            'description' => 'Login to your RojgarSandhi account.',
        ];

        return $this->render('auth/login', $data);
    }

    public function attemptLogin()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        $remember = $this->request->getPost('remember');

        $userModel = model('App\Models\UserModel');
        $user = $userModel->getByEmail($email);

        if (!$user || !$userModel->verifyPassword($password, $user['password'])) {
            return redirect()->to('/login')->withInput()->with('error', 'Invalid email or password.');
        }

        if (!$user['is_active']) {
            return redirect()->to('/login')->withInput()->with('error', 'Your account has been deactivated.');
        }

        $this->setUserSession($user);

        if ($remember) {
            $this->setRememberToken($user['id']);
        }

        $userModel->updateLastLogin($user['id']);

        $redirect = session()->getFlashdata('redirect') ?? ($user['role'] === 'admin' ? '/admin' : '/dashboard');
        return redirect()->to($redirect)->with('success', 'Welcome back, ' . $user['name'] . '!');
    }

    public function register()
    {
        if (is_logged_in()) {
            return redirect()->to('/dashboard');
        }

        $data = [
            'title' => meta_title('Register'),
            'description' => 'Create your RojgarSandhi account.',
        ];

        return $this->render('auth/register', $data);
    }

    public function attemptRegister()
    {
        $rules = [
            'name' => 'required|min_length[3]|max_length[100]',
            'email' => 'required|valid_email|is_unique[users.email]',
            'phone' => 'required|numeric|exact_length[10]',
            'password' => 'required|min_length[6]',
            'pass_confirm' => 'required|matches[password]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $userModel = model('App\Models\UserModel');
        $userData = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'phone' => $this->request->getPost('phone'),
            'password' => $this->request->getPost('password'),
        ];

        $userId = $userModel->insert($userData);
        $user = $userModel->find($userId);

        $this->setUserSession($user);

        return redirect()->to('/dashboard')->with('success', 'Welcome to RojgarSandhi! Your account has been created.');
    }

    public function forgotPassword()
    {
        $data = [
            'title' => meta_title('Forgot Password'),
        ];

        return $this->render('auth/forgot_password', $data);
    }

    public function sendResetLink()
    {
        $email = $this->request->getPost('email');
        $userModel = model('App\Models\UserModel');
        $user = $userModel->getByEmail($email);

        if (!$user) {
            return redirect()->back()->with('error', 'No account found with this email.');
        }

        $token = bin2hex(random_bytes(32));
        $userModel->update($user['id'], [
            'reset_token' => $token,
            'reset_token_expires_at' => date('Y-m-d H:i:s', strtotime('+1 hour')),
        ]);

        $resetLink = base_url('/reset-password/' . $token);

        // In production: send email
        // For now, redirect with the token
        return redirect()->to('/reset-password/' . $token)->with('success', 'Use the link to reset your password.');
    }

    public function resetPassword($token = null)
    {
        if (!$token) {
            return redirect()->to('/login')->with('error', 'Invalid reset link.');
        }

        $userModel = model('App\Models\UserModel');
        $user = $userModel->where('reset_token', $token)
            ->where('reset_token_expires_at >=', date('Y-m-d H:i:s'))
            ->first();

        if (!$user) {
            return redirect()->to('/login')->with('error', 'Invalid or expired reset link.');
        }

        $data = [
            'title' => meta_title('Reset Password'),
            'token' => $token,
        ];

        return $this->render('auth/reset_password', $data);
    }

    public function processResetPassword()
    {
        $token = $this->request->getPost('token');
        $password = $this->request->getPost('password');

        $userModel = model('App\Models\UserModel');
        $user = $userModel->where('reset_token', $token)
            ->where('reset_token_expires_at >=', date('Y-m-d H:i:s'))
            ->first();

        if (!$user) {
            return redirect()->to('/login')->with('error', 'Invalid or expired reset link.');
        }

        $userModel->update($user['id'], [
            'password' => $password,
            'reset_token' => null,
            'reset_token_expires_at' => null,
        ]);

        return redirect()->to('/login')->with('success', 'Password reset successful. Please login.');
    }

    public function otpVerify()
    {
        $data = ['title' => meta_title('OTP Verification')];
        return $this->render('auth/otp_verify', $data);
    }

    public function verifyOtp()
    {
        $otp = $this->request->getPost('otp');
        $userId = session()->get('otp_user_id');

        if (!$userId) {
            return redirect()->to('/login')->with('error', 'Session expired.');
        }

        $userModel = model('App\Models\UserModel');
        $user = $userModel->find($userId);

        if (!$user || $user['otp'] !== $otp || strtotime($user['otp_expires_at']) < time()) {
            return redirect()->back()->with('error', 'Invalid or expired OTP.');
        }

        $userModel->update($userId, [
            'otp' => null,
            'otp_expires_at' => null,
            'email_verified_at' => date('Y-m-d H:i:s'),
        ]);

        session()->remove('otp_user_id');

        return redirect()->to('/dashboard')->with('success', 'Email verified successfully!');
    }

    public function googleLogin()
    {
        // Google OAuth redirect - implement with Google Client Library
        return redirect()->to('/login')->with('info', 'Google login coming soon.');
    }

    public function googleCallback()
    {
        return redirect()->to('/login')->with('info', 'Google login coming soon.');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login')->with('success', 'You have been logged out.');
    }

    private function setUserSession(array $user): void
    {
        session()->set([
            'user_id' => $user['id'],
            'user_role' => $user['role'],
            'user_data' => [
                'id' => $user['id'],
                'name' => $user['name'],
                'email' => $user['email'],
                'phone' => $user['phone'],
                'avatar' => $user['avatar'],
                'role' => $user['role'],
            ],
        ]);
    }

    private function setRememberToken(int $userId): void
    {
        $token = bin2hex(random_bytes(32));
        model('App\Models\UserModel')->update($userId, ['remember_token' => $token]);

        $cookie = [
            'name' => 'remember_token',
            'value' => $token,
            'expire' => 86400 * 30,
        ];
        $this->response->setCookie($cookie);
    }
}
