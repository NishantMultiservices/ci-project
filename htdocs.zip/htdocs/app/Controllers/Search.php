<?php

namespace App\Controllers;

class Search extends BaseController
{
    public function index()
    {
        $query = $this->request->getGet('q');
        $type = $this->request->getGet('type') ?? 'all';

        $results = [];

        if (!empty($query)) {
            $jobModel = model('App\Models\JobModel');

            if ($type === 'all' || $type === 'jobs') {
                $results['jobs'] = $jobModel->search(['keyword' => $query], 6);
            }
        }

        $data = [
            'title' => meta_title('Search: ' . esc($query)),
            'description' => 'Search results for: ' . esc($query),
            'query' => $query,
            'results' => $results,
        ];
        return $this->render('search/index', $data);
    }

    public function suggestions()
    {
        $query = $this->request->getGet('q');
        if (strlen($query) < 2) {
            return $this->jsonResponse([]);
        }

        $jobModel = model('App\Models\JobModel');
        $suggestions = $jobModel->select('title, slug, company_name, location')
            ->like('title', $query)
            ->orLike('company_name', $query)
            ->orLike('location', $query)
            ->where('is_active', 1)
            ->limit(8)
            ->find();

        return $this->jsonResponse($suggestions);
    }
}
