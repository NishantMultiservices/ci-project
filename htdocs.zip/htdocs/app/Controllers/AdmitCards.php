<?php

namespace App\Controllers;

class AdmitCards extends BaseController
{
    public function index()
    {
        $admitCardModel = model('App\Models\AdmitCardModel');
        $data = [
            'title' => meta_title('Admit Cards'),
            'description' => 'Download admit cards for upcoming exams.',
            'admit_cards' => $admitCardModel->getLatest(20),
        ];
        return $this->render('admit_cards/index', $data);
    }

    public function detail($id)
    {
        $admitCardModel = model('App\Models\AdmitCardModel');
        $admitCard = $admitCardModel->find($id);

        if (!$admitCard || !$admitCard['is_active']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $admitCardModel->incrementViews($id);

        $data = [
            'title' => meta_title($admitCard['title'] . ' - Admit Card'),
            'admit_card' => $admitCard,
        ];
        return $this->render('admit_cards/detail', $data);
    }
}
