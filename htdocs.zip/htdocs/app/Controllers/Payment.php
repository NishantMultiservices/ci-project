<?php

namespace App\Controllers;

class Payment extends BaseController
{
    public function initiate()
    {
        if (!is_logged_in()) {
            return $this->jsonResponse(['error' => 'Unauthorized'], 401);
        }

        $itemType = $this->request->getPost('item_type');
        $itemId = (int) $this->request->getPost('item_id');

        if (!in_array($itemType, ['course', 'mock_test'])) {
            return $this->jsonResponse(['error' => 'Invalid item type'], 400);
        }

        $model = $itemType === 'course'
            ? model('App\Models\CourseModel')
            : model('App\Models\MockTestModel');
        $item = $model->find($itemId);
        if (!$item || $item['is_free']) {
            return $this->jsonResponse(['error' => 'Item not found or is free'], 404);
        }

        $amount = (float) $item['price'];
        if ($amount <= 0) {
            return $this->jsonResponse(['error' => 'Invalid price'], 400);
        }

        $paymentModel = model('App\Models\PaymentModel');
        if ($paymentModel->hasPaid(user_id(), $itemType, $itemId)) {
            return $this->jsonResponse(['redirect' => $this->getSuccessRedirect($itemType, $itemId)]);
        }

        $merchantTransactionId = 'TXN' . time() . rand(100, 999);

        $paymentModel->insert([
            'user_id' => user_id(),
            'item_type' => $itemType,
            'item_id' => $itemId,
            'amount' => $amount,
            'currency' => 'INR',
            'payment_status' => 'pending',
            'merchant_transaction_id' => $merchantTransactionId,
        ]);

        $config = config('PhonePay');

        // Simulated payment mode for local development
        if ($config->simulate) {
            return $this->handleSimulatedPayment($config, $paymentModel, $merchantTransactionId, $itemType, $itemId);
        }

        // V2 OAuth flow (preferred)
        if ($config->isV2()) {
            return $this->initiateV2($config, $paymentModel, $merchantTransactionId, $itemType, $itemId, $amount);
        }

        // V1 fallback (deprecated)
        return $this->initiateV1($config, $paymentModel, $merchantTransactionId, $itemType, $itemId, $amount);
    }

    private function handleSimulatedPayment($config, $paymentModel, $merchantTransactionId, $itemType, $itemId)
    {
        $paymentRecord = $paymentModel->where('merchant_transaction_id', $merchantTransactionId)->first();
        if ($paymentRecord) {
            $paymentModel->update($paymentRecord['id'], [
                'payment_status' => 'completed',
                'transaction_id' => 'SIM_' . $merchantTransactionId,
                'paid_at' => date('Y-m-d H:i:s'),
            ]);
        }

        if ($itemType === 'course') {
            $enrollmentModel = model('App\Models\EnrollmentModel');
            if (!$enrollmentModel->isEnrolled(user_id(), $itemId)) {
                try {
                    $enrollmentModel->insert([
                        'user_id' => user_id(),
                        'course_id' => $itemId,
                        'status' => 'active',
                    ]);
                } catch (\Exception $e) {
                    log_message('error', 'Enrollment insert failed (likely duplicate): ' . $e->getMessage());
                }
            }
        }

        return $this->jsonResponse(['redirect' => $this->getSuccessRedirect($itemType, $itemId)]);
    }

    private function initiateV2($config, $paymentModel, $merchantTransactionId, $itemType, $itemId, float $amount)
    {
        $accessToken = $config->getAuthToken();
        if (!$accessToken) {
            $paymentModel->where('merchant_transaction_id', $merchantTransactionId)
                ->set(['payment_status' => 'failed'])->update();
            return $this->jsonResponse(['error' => 'Payment gateway auth failed. Please try again later.'], 500);
        }

        $amountPaise = (int) round($amount * 100);

        $payload = [
            'merchantOrderId' => $merchantTransactionId,
            'amount' => $amountPaise,
            'expireAfter' => 1200,
            'paymentFlow' => [
                'type' => 'PG_CHECKOUT',
                'merchantUrls' => [
                    'redirectUrl' => base_url('payment/callback'),
                ],
            ],
            'metaInfo' => [
                'udf1' => $itemType,
                'udf2' => (string) $itemId,
            ],
        ];

        $ch = curl_init($config->getPayUrl());
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: O-Bearer ' . $accessToken,
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);
        $response = curl_exec($ch);
        $curlError = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false || $response === '') {
            $paymentModel->where('merchant_transaction_id', $merchantTransactionId)
                ->set(['payment_status' => 'failed'])->update();
            log_message('error', 'PhonePe V2 pay cURL failed: ' . $curlError);
            return $this->jsonResponse(['error' => 'Payment gateway unreachable. Please try again later.'], 500);
        }

        $result = json_decode($response, true);

        if ($httpCode === 200 && isset($result['state']) && $result['state'] === 'PENDING') {
            $redirectUrl = $result['redirectUrl'] ?? null;
            if ($redirectUrl) {
                $paymentModel->where('merchant_transaction_id', $merchantTransactionId)
                    ->set(['phonepe_transaction_id' => $result['orderId'] ?? ''])->update();
                return $this->jsonResponse(['redirect' => $redirectUrl]);
            }
        }

        $paymentModel->where('merchant_transaction_id', $merchantTransactionId)
            ->set(['payment_status' => 'failed'])->update();

        $msg = $result['message'] ?? ($result['code'] ?? 'unknown');
        log_message('error', 'PhonePe V2 initiate failed (HTTP ' . $httpCode . '): ' . $msg);
        return $this->jsonResponse(['error' => 'Payment initiation failed. Please try again.'], 500);
    }

    private function initiateV1($config, $paymentModel, $merchantTransactionId, $itemType, $itemId, float $amount)
    {
        $amountPaise = (int) round($amount * 100);

        $payload = [
            'merchantId' => $config->merchantId,
            'merchantTransactionId' => $merchantTransactionId,
            'merchantUserId' => 'U' . user_id(),
            'amount' => $amountPaise,
            'redirectUrl' => base_url('payment/callback'),
            'redirectMode' => 'POST',
            'callbackUrl' => base_url('payment/callback'),
            'mobileNumber' => '',
            'paymentInstrument' => ['type' => 'PAY_PAGE'],
        ];

        $jsonPayload = json_encode($payload);
        $base64Payload = base64_encode($jsonPayload);
        $endpoint = '/pg/v1/pay';
        $xVerify = hash('sha256', $base64Payload . $endpoint . $config->saltKey) . '###' . $config->saltIndex;

        $ch = curl_init($config->getBaseUrl() . $endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode(['request' => $base64Payload]),
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'X-VERIFY: ' . $xVerify],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);
        $response = curl_exec($ch);
        $curlError = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false || $response === '') {
            $paymentModel->where('merchant_transaction_id', $merchantTransactionId)
                ->set(['payment_status' => 'failed'])->update();
            log_message('error', 'PhonePe V1 cURL failed: ' . $curlError);
            return $this->jsonResponse(['error' => 'Payment gateway unreachable. Please try again later.'], 500);
        }

        $result = json_decode($response, true);
        if ($httpCode === 200 && isset($result['success']) && $result['success']) {
            $redirectUrl = $result['data']['instrumentResponse']['redirectInfo']['url'] ?? null;
            if ($redirectUrl) {
                return $this->jsonResponse(['redirect' => $redirectUrl]);
            }
        }

        $paymentModel->where('merchant_transaction_id', $merchantTransactionId)
            ->set(['payment_status' => 'failed'])->update();

        log_message('error', 'PhonePe V1 initiate failed: ' . ($result['message'] ?? ($result['code'] ?? $response)));
        return $this->jsonResponse(['error' => 'Payment initiation failed. Please try again.'], 500);
    }

    public function callback()
    {
        $config = config('PhonePay');

        // Try to get response from POST, GET, or raw body
        $response = $this->request->getPost('response');
        if (!$response) {
            $response = $this->request->getGet('response');
        }
        if (!$response) {
            $raw = file_get_contents('php://input');
            $data = json_decode($raw, true);
            $response = $data['response'] ?? ($raw ?: '');
        }
        if (!$response) {
            return redirect()->to('/payment/failure')->with('error', 'Invalid payment response.');
        }

        $decoded = json_decode(base64_decode($response), true);

        if (!$decoded || !isset($decoded['data'])) {
            return redirect()->to('/payment/failure')->with('error', 'Failed to decode payment response.');
        }

        $data = $decoded['data'];
        $merchantTransactionId = $data['merchantTransactionId'] ?? '';
        $transactionId = $data['transactionId'] ?? '';
        $state = $data['state'] ?? '';
        $code = $data['responseCode'] ?? '';

        $paymentModel = model('App\Models\PaymentModel');
        $payment = $paymentModel->getPending($merchantTransactionId);

        if (!$payment) {
            return redirect()->to('/payment/failure')->with('error', 'Transaction not found.');
        }

        if ($state === 'COMPLETED' && $code === 'PAYMENT_SUCCESS') {
            $paymentModel->update($payment['id'], [
                'payment_status' => 'completed',
                'phonepe_transaction_id' => $transactionId,
                'transaction_id' => $transactionId,
                'payment_method' => $data['paymentInstrument'] ?? ($data['paymentInstrumentResponse']['type'] ?? 'PAY_PAGE'),
                'paid_at' => date('Y-m-d H:i:s'),
            ]);

            if ($payment['item_type'] === 'course') {
                $enrollmentModel = model('App\Models\EnrollmentModel');
                if (!$enrollmentModel->isEnrolled($payment['user_id'], $payment['item_id'])) {
                    try {
                        $enrollmentModel->insert([
                            'user_id' => $payment['user_id'],
                            'course_id' => $payment['item_id'],
                            'status' => 'active',
                        ]);
                    } catch (\Exception $e) {
                        log_message('error', 'Callback enrollment insert failed: ' . $e->getMessage());
                    }
                }
            }

            return redirect()->to($this->getSuccessRedirect($payment['item_type'], $payment['item_id']))
                ->with('success', 'Payment successful! You now have access.');
        }

        $paymentModel->update($payment['id'], ['payment_status' => 'failed']);
        return redirect()->to('/payment/failure')->with('error', 'Payment was not successful. Please try again.');
    }

    public function status($merchantTransactionId)
    {
        if (!is_logged_in()) {
            return $this->jsonResponse(['error' => 'Unauthorized'], 401);
        }

        $payment = model('App\Models\PaymentModel')
            ->where('merchant_transaction_id', $merchantTransactionId)
            ->where('user_id', user_id())
            ->first();

        if (!$payment) {
            return $this->jsonResponse(['error' => 'Transaction not found'], 404);
        }

        if ($payment['payment_status'] === 'completed') {
            return $this->jsonResponse([
                'status' => 'completed',
                'redirect' => $this->getSuccessRedirect($payment['item_type'], $payment['item_id']),
            ]);
        }

        // Check status via API for pending payments
        if ($payment['payment_status'] === 'pending') {
            $config = config('PhonePay');
            $liveStatus = $this->checkLiveStatus($config, $merchantTransactionId);
            if ($liveStatus === 'completed') {
                $paymentModel = model('App\Models\PaymentModel');
                $paymentModel->update($payment['id'], ['payment_status' => 'completed', 'paid_at' => date('Y-m-d H:i:s')]);
                return $this->jsonResponse([
                    'status' => 'completed',
                    'redirect' => $this->getSuccessRedirect($payment['item_type'], $payment['item_id']),
                ]);
            }
        }

        return $this->jsonResponse(['status' => $payment['payment_status']]);
    }

    private function checkLiveStatus($config, string $merchantTransactionId): string
    {
        if ($config->isV2()) {
            $accessToken = $config->getAuthToken();
            if (!$accessToken) {
                return 'unknown';
            }

            $ch = curl_init($config->getStatusUrl($merchantTransactionId));
            curl_setopt_array($ch, [
                CURLOPT_HTTPGET => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Authorization: O-Bearer ' . $accessToken,
                ],
                CURLOPT_TIMEOUT => 15,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
            ]);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode === 200 && $response) {
                $result = json_decode($response, true);
                if (isset($result['state']) && $result['state'] === 'COMPLETED') {
                    return 'completed';
                }
            }
        }

        return 'unknown';
    }

    private function getSuccessRedirect(string $itemType, int $itemId): string
    {
        if ($itemType === 'course') {
            return '/courses/learn/' . $itemId;
        }
        $mockTest = model('App\Models\MockTestModel')->find($itemId);
        if ($mockTest) {
            return '/mock-tests/' . $mockTest['slug'] . '/attempt';
        }
        return '/mock-tests';
    }

    public function success()
    {
        return $this->render('payment/success', ['title' => 'Payment Successful']);
    }

    public function failure()
    {
        return $this->render('payment/failure', ['title' => 'Payment Failed']);
    }
}
