<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Dashboard extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Admin Dashboard',
            'total_jobs' => model('App\Models\JobModel')->getTotalJobs(),
            'total_users' => model('App\Models\UserModel')->getTotalUsers(),
            'total_courses' => model('App\Models\CourseModel')->getTotalCourses(),
            'total_applications' => model('App\Models\ApplicationModel')->getTotalApplications(),
            'total_messages' => model('App\Models\ContactModel')->getUnreadCount(),
            'total_blogs' => model('App\Models\BlogModel')->getTotalBlogs(),
            'recent_users' => model('App\Models\UserModel')->getRecentUsers(5),
            'recent_jobs' => model('App\Models\JobModel')->getLatest(5),
        ];
        return $this->renderAdmin('admin/dashboard', $data);
    }

    public function analytics()
    {
        $data = ['title' => 'Analytics'];
        return $this->renderAdmin('admin/analytics', $data);
    }
}
