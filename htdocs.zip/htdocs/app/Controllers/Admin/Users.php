<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Users extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Manage Users',
            'users' => model('App\Models\UserModel')->orderBy('created_at', 'DESC')->paginate(20),
            'pager' => model('App\Models\UserModel')->pager,
        ];
        return $this->renderAdmin('admin/users/index', $data);
    }

    public function detail($id)
    {
        $user = model('App\Models\UserModel')->find($id);
        if (!$user) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        $data = [
            'title' => 'User Detail',
            'user' => $user,
            'applications' => model('App\Models\ApplicationModel')->getUserApplications($id),
        ];
        return $this->renderAdmin('admin/users/detail', $data);
    }

    public function resetPassword($id)
    {
        $userModel = model('App\Models\UserModel');
        $user = $userModel->find($id);
        if (!$user) {
            return redirect()->back()->with('error', 'User not found.');
        }

        $tempPassword = bin2hex(random_bytes(4));
        $userModel->update($id, ['password' => $tempPassword]);

        return redirect()->back()->with('success', "Password reset successful. Temporary password: <strong>$tempPassword</strong>");
    }

    public function delete($id)
    {
        model('App\Models\UserModel')->delete($id);
        return redirect()->to('/admin/users')->with('success', 'User deleted successfully.');
    }
}
