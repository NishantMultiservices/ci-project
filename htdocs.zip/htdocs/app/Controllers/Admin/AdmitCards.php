<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class AdmitCards extends BaseController
{
    public function index()
    {
        $model = model('App\Models\AdmitCardModel');
        $data = [
            'title' => 'Manage Admit Cards',
            'admit_cards' => $model->orderBy('created_at', 'DESC')->paginate(20),
            'pager' => $model->pager,
        ];
        return $this->renderAdmin('admin/admit_cards/index', $data);
    }

    public function create()
    {
        return $this->renderAdmin('admin/admit_cards/form', ['title' => 'Add Admit Card']);
    }

    public function store()
    {
        $model = model('App\Models\AdmitCardModel');
        $data = $this->request->getPost();
        $data['slug'] = generate_slug($data['title']) . '-' . time();
        if ($model->insert($data)) {
            return redirect()->to('/admin/admit-cards')->with('success', 'Admit card created.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to create admit card.');
    }

    public function edit($id)
    {
        $item = model('App\Models\AdmitCardModel')->find($id);
        if (!$item) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        return $this->renderAdmin('admin/admit_cards/form', ['title' => 'Edit Admit Card', 'admit_card' => $item]);
    }

    public function update($id)
    {
        if (model('App\Models\AdmitCardModel')->update($id, $this->request->getPost())) {
            return redirect()->to('/admin/admit-cards')->with('success', 'Admit card updated.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to update.');
    }

    public function delete($id)
    {
        model('App\Models\AdmitCardModel')->delete($id);
        return redirect()->to('/admin/admit-cards')->with('success', 'Admit card deleted.');
    }
}
