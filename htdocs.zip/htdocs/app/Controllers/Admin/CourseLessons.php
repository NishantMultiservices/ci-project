<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class CourseLessons extends BaseController
{
    public function index($courseId)
    {
        $course = model('App\Models\CourseModel')->find($courseId);
        if (!$course) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();

        $data = [
            'title' => 'Lessons - ' . $course['title'],
            'course' => $course,
            'lessons' => model('App\Models\CourseLessonModel')->getCourseLessons($courseId),
        ];
        return $this->renderAdmin('admin/course_lessons/index', $data);
    }

    public function create($courseId)
    {
        $course = model('App\Models\CourseModel')->find($courseId);
        if (!$course) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();

        $data = [
            'title' => 'Add Lesson - ' . $course['title'],
            'course' => $course,
            'lesson' => null,
        ];
        return $this->renderAdmin('admin/course_lessons/form', $data);
    }

    public function store($courseId)
    {
        $model = model('App\Models\CourseLessonModel');
        $data = $this->request->getPost();
        $data['course_id'] = $courseId;
        $model->insert($data);
        return redirect()->to('/admin/course-lessons/' . $courseId)->with('success', 'Lesson created.');
    }

    public function edit($courseId, $lessonId)
    {
        $course = model('App\Models\CourseModel')->find($courseId);
        $lesson = model('App\Models\CourseLessonModel')->find($lessonId);
        if (!$course || !$lesson) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();

        $data = [
            'title' => 'Edit Lesson - ' . $course['title'],
            'course' => $course,
            'lesson' => $lesson,
        ];
        return $this->renderAdmin('admin/course_lessons/form', $data);
    }

    public function update($courseId, $lessonId)
    {
        $model = model('App\Models\CourseLessonModel');
        $model->update($lessonId, $this->request->getPost());
        return redirect()->to('/admin/course-lessons/' . $courseId)->with('success', 'Lesson updated.');
    }

    public function delete($courseId, $lessonId)
    {
        model('App\Models\CourseLessonModel')->delete($lessonId);
        return redirect()->to('/admin/course-lessons/' . $courseId)->with('success', 'Lesson deleted.');
    }

    public function reorder($courseId)
    {
        $order = $this->request->getPost('order');
        if (!empty($order) && is_array($order)) {
            $model = model('App\Models\CourseLessonModel');
            foreach ($order as $index => $lessonId) {
                $model->update($lessonId, ['sort_order' => $index + 1]);
            }
        }
        return redirect()->to('/admin/course-lessons/' . $courseId)->with('success', 'Order updated.');
    }
}
