<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Applications extends BaseController
{
    public function index()
    {
        $applicationModel = model('App\Models\ApplicationModel');
        $applications = $applicationModel
            ->select('applications.*, users.name as user_name, users.email as user_email, jobs.title as job_title')
            ->join('users', 'users.id = applications.user_id', 'left')
            ->join('jobs', 'jobs.id = applications.job_id', 'left')
            ->orderBy('applications.created_at', 'DESC')
            ->findAll();

        $data = [
            'title' => 'Applications',
            'applications' => $applications,
        ];
        return $this->renderAdmin('admin/applications/index', $data);
    }

    public function delete($id)
    {
        model('App\Models\ApplicationModel')->delete($id);
        return redirect()->to('/admin/applications')->with('success', 'Application deleted.');
    }
}
