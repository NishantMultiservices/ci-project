<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Categories extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Manage Categories',
            'categories' => model('App\Models\CategoryModel')->orderBy('type', 'ASC')->orderBy('sort_order', 'ASC')->findAll(),
            'types' => ['job', 'course', 'scholarship', 'internship', 'blog'],
        ];
        return $this->renderAdmin('admin/categories/index', $data);
    }

    public function store()
    {
        $data = $this->request->getPost();
        $data['slug'] = generate_slug($data['name']);
        if (model('App\Models\CategoryModel')->insert($data)) {
            return redirect()->to('/admin/categories')->with('success', 'Category created.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to create category.');
    }

    public function edit($id)
    {
        $item = model('App\Models\CategoryModel')->find($id);
        if (!$item) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        return $this->renderAdmin('admin/categories/form', [
            'title' => 'Edit Category',
            'category' => $item,
            'types' => ['job', 'course', 'scholarship', 'internship', 'blog'],
        ]);
    }

    public function update($id)
    {
        $data = $this->request->getPost();
        $data['slug'] = generate_slug($data['name']);
        if (model('App\Models\CategoryModel')->update($id, $data)) {
            return redirect()->to('/admin/categories')->with('success', 'Category updated.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to update.');
    }

    public function delete($id)
    {
        model('App\Models\CategoryModel')->delete($id);
        return redirect()->to('/admin/categories')->with('success', 'Category deleted.');
    }
}
