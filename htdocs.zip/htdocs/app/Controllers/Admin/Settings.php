<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Settings extends BaseController
{
    public function index()
    {
        $model = model('App\Models\SettingModel');

        $data = [
            'title' => 'Site Settings',
            'settings' => $model->findAll(),
            'groups' => [
                'general' => $model->getGroup('general'),
                'social' => $model->getGroup('social'),
                'seo' => $model->getGroup('seo'),
            ],
        ];
        return $this->renderAdmin('admin/settings/index', $data);
    }

    public function update()
    {
        $model = model('App\Models\SettingModel');
        $postSettings = $this->request->getPost('settings');

        if (is_array($postSettings)) {
            foreach ($postSettings as $key => $value) {
                $model->set($key, $value);
            }
        }

        $uploadedFile = $this->request->getFile('logo_favicon');
        if ($uploadedFile && $uploadedFile->isValid() && !$uploadedFile->hasMoved()) {
            if ($uploadedFile->getExtension() === 'ico') {
                $uploadedFile->move(FCPATH . 'assets/images/logo', 'favicon.ico', true);
            }
        }

        $uploadedFile = $this->request->getFile('logo_apple');
        if ($uploadedFile && $uploadedFile->isValid() && !$uploadedFile->hasMoved()) {
            $uploadedFile->move(FCPATH . 'assets/images/logo', 'apple-touch-icon.png', true);
        }

        return redirect()->to('/admin/settings')->with('success', 'Settings updated successfully.');
    }
}
