<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class LessonQuiz extends BaseController
{
    public function index($lessonId)
    {
        $lesson = model('App\Models\CourseLessonModel')->find($lessonId);
        if (!$lesson) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();

        $course = model('App\Models\CourseModel')->find($lesson['course_id']);

        $data = [
            'title' => 'Quiz Questions - ' . $lesson['title'],
            'lesson' => $lesson,
            'course' => $course,
            'questions' => model('App\Models\LessonQuizQuestionModel')->getLessonQuestions($lessonId),
        ];
        return $this->renderAdmin('admin/lesson_quiz/index', $data);
    }

    public function create($lessonId)
    {
        $lesson = model('App\Models\CourseLessonModel')->find($lessonId);
        if (!$lesson) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();

        $course = model('App\Models\CourseModel')->find($lesson['course_id']);

        $data = [
            'title' => 'Add Question - ' . $lesson['title'],
            'lesson' => $lesson,
            'course' => $course,
            'question' => null,
        ];
        return $this->renderAdmin('admin/lesson_quiz/form', $data);
    }

    public function store($lessonId)
    {
        $lesson = model('App\Models\CourseLessonModel')->find($lessonId);
        if (!$lesson) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();

        $model = model('App\Models\LessonQuizQuestionModel');
        $data = $this->request->getPost();
        $data['lesson_id'] = $lessonId;
        $data['course_id'] = $lesson['course_id'];
        $model->insert($data);

        return redirect()->to('/admin/lesson-quiz/' . $lessonId)->with('success', 'Question added.');
    }

    public function edit($lessonId, $questionId)
    {
        $lesson = model('App\Models\CourseLessonModel')->find($lessonId);
        if (!$lesson) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();

        $course = model('App\Models\CourseModel')->find($lesson['course_id']);
        $question = model('App\Models\LessonQuizQuestionModel')->find($questionId);
        if (!$question) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();

        $data = [
            'title' => 'Edit Question - ' . $lesson['title'],
            'lesson' => $lesson,
            'course' => $course,
            'question' => $question,
        ];
        return $this->renderAdmin('admin/lesson_quiz/form', $data);
    }

    public function update($lessonId, $questionId)
    {
        $model = model('App\Models\LessonQuizQuestionModel');
        $model->update($questionId, $this->request->getPost());

        return redirect()->to('/admin/lesson-quiz/' . $lessonId)->with('success', 'Question updated.');
    }

    public function delete($lessonId, $questionId)
    {
        model('App\Models\LessonQuizQuestionModel')->delete($questionId);
        return redirect()->to('/admin/lesson-quiz/' . $lessonId)->with('success', 'Question deleted.');
    }
}
