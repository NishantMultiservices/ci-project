<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class ContactMessages extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Contact Messages',
            'messages' => model('App\Models\ContactModel')->orderBy('created_at', 'DESC')->findAll(),
        ];
        return $this->renderAdmin('admin/contact_messages/index', $data);
    }

    public function delete($id)
    {
        model('App\Models\ContactModel')->delete($id);
        return redirect()->to('/admin/contact-messages')->with('success', 'Message deleted.');
    }
}
