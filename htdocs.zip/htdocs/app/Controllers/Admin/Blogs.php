<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Blogs extends BaseController
{
    public function index()
    {
        $model = model('App\Models\BlogModel');
        $data = [
            'title' => 'Manage Blogs',
            'blogs' => $model->orderBy('created_at', 'DESC')->paginate(20),
            'pager' => $model->pager,
        ];
        return $this->renderAdmin('admin/blogs/index', $data);
    }

    public function create()
    {
        return $this->renderAdmin('admin/blogs/form', [
            'title' => 'Add Blog Post',
            'categories' => model('App\Models\CategoryModel')->getByType('blog'),
        ]);
    }

    public function store()
    {
        $model = model('App\Models\BlogModel');
        $data = $this->request->getPost();
        $data['slug'] = generate_slug($data['title']) . '-' . time();
        $data['published_at'] = $data['is_published'] ? date('Y-m-d H:i:s') : null;
        if ($model->insert($data)) {
            return redirect()->to('/admin/blogs')->with('success', 'Blog post created.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to create blog.');
    }

    public function edit($id)
    {
        $blog = model('App\Models\BlogModel')->find($id);
        if (!$blog) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        return $this->renderAdmin('admin/blogs/form', [
            'title' => 'Edit Blog',
            'blog' => $blog,
            'categories' => model('App\Models\CategoryModel')->getByType('blog'),
        ]);
    }

    public function update($id)
    {
        $data = $this->request->getPost();
        $data['published_at'] = $data['is_published'] ? date('Y-m-d H:i:s') : null;
        if (model('App\Models\BlogModel')->update($id, $data)) {
            return redirect()->to('/admin/blogs')->with('success', 'Blog updated.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to update.');
    }

    public function delete($id)
    {
        model('App\Models\BlogModel')->delete($id);
        return redirect()->to('/admin/blogs')->with('success', 'Blog deleted.');
    }
}
