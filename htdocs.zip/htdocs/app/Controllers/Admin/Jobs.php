<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Jobs extends BaseController
{
    public function index()
    {
        $jobModel = model('App\Models\JobModel');
        $jobs = $jobModel->orderBy('created_at', 'DESC')->paginate(20);
        $postModel = model('App\Models\JobPostModel');

        $postCounts = [];
        foreach ($jobs as $j) {
            $postCounts[$j['id']] = $postModel->where('job_id', $j['id'])->countAllResults();
        }

        $data = [
            'title' => 'Manage Jobs',
            'jobs' => $jobs,
            'pager' => $jobModel->pager,
            'postCounts' => $postCounts,
        ];
        return $this->renderAdmin('admin/jobs/index', $data);
    }

    public function create()
    {
        $data = [
            'title' => 'Add Job',
            'categories' => model('App\Models\CategoryModel')->getJobCategories(),
        ];
        return $this->renderAdmin('admin/jobs/form', $data);
    }

    public function store()
    {
        $jobModel = model('App\Models\JobModel');
        $data = $this->request->getPost();
        $data['slug'] = generate_slug($data['title']) . '-' . time();

        $jobId = $jobModel->insert($data);
        if ($jobId) {
            $this->saveJobPosts($jobId);
            return redirect()->to('/admin/jobs')->with('success', 'Job created successfully.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to create job.');
    }

    public function edit($id)
    {
        $job = model('App\Models\JobModel')->find($id);
        if (!$job) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        $data = [
            'title' => 'Edit Job',
            'job' => $job,
            'categories' => model('App\Models\CategoryModel')->getJobCategories(),
            'jobPosts' => model('App\Models\JobPostModel')->getByJobId($id),
        ];
        return $this->renderAdmin('admin/jobs/form', $data);
    }

    public function update($id)
    {
        $jobModel = model('App\Models\JobModel');
        $data = $this->request->getPost();
        if ($jobModel->update($id, $data)) {
            $this->saveJobPosts($id);
            return redirect()->to('/admin/jobs')->with('success', 'Job updated successfully.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to update job.');
    }

    public function delete($id)
    {
        model('App\Models\JobModel')->delete($id);
        return redirect()->to('/admin/jobs')->with('success', 'Job deleted successfully.');
    }

    private function saveJobPosts(int $jobId): void
    {
        $postModel = model('App\Models\JobPostModel');
        $titles = $this->request->getPost('post_title');

        if (empty($titles) || !is_array($titles)) {
            return;
        }

        $postModel->deleteByJobId($jobId);

        $qualifications = $this->request->getPost('post_qualification');
        $vacancies = $this->request->getPost('post_vacancies');
        $expMin = $this->request->getPost('post_experience_min');
        $expMax = $this->request->getPost('post_experience_max');
        $salMin = $this->request->getPost('post_salary_min');
        $salMax = $this->request->getPost('post_salary_max');
        $departments = $this->request->getPost('post_department');

        foreach ($titles as $i => $title) {
            if (empty(trim($title))) {
                continue;
            }
            $postModel->insert([
                'job_id' => $jobId,
                'title' => $title,
                'qualification' => $qualifications[$i] ?? '',
                'vacancies' => !empty($vacancies[$i]) ? (int)$vacancies[$i] : null,
                'experience_min' => !empty($expMin[$i]) ? (int)$expMin[$i] : null,
                'experience_max' => !empty($expMax[$i]) ? (int)$expMax[$i] : null,
                'salary_min' => !empty($salMin[$i]) ? (float)$salMin[$i] : null,
                'salary_max' => !empty($salMax[$i]) ? (float)$salMax[$i] : null,
                'department' => $departments[$i] ?? '',
            ]);
        }
    }
}
