<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Apprenticeships extends BaseController
{
    public function index()
    {
        $model = model('App\Models\ApprenticeshipModel');
        $data = [
            'title' => 'Manage Apprenticeships',
            'apprenticeships' => $model->orderBy('created_at', 'DESC')->paginate(20),
            'pager' => $model->pager,
        ];
        return $this->renderAdmin('admin/apprenticeships/index', $data);
    }

    public function create()
    {
        return $this->renderAdmin('admin/apprenticeships/form', ['title' => 'Add Apprenticeship']);
    }

    public function store()
    {
        $model = model('App\Models\ApprenticeshipModel');
        $data = $this->request->getPost();
        $data['slug'] = generate_slug($data['title']) . '-' . time();
        if ($model->insert($data)) {
            return redirect()->to('/admin/apprenticeships')->with('success', 'Apprenticeship created.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to create apprenticeship.');
    }

    public function edit($id)
    {
        $item = model('App\Models\ApprenticeshipModel')->find($id);
        if (!$item) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        return $this->renderAdmin('admin/apprenticeships/form', ['title' => 'Edit Apprenticeship', 'apprenticeship' => $item]);
    }

    public function update($id)
    {
        if (model('App\Models\ApprenticeshipModel')->update($id, $this->request->getPost())) {
            return redirect()->to('/admin/apprenticeships')->with('success', 'Apprenticeship updated.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to update.');
    }

    public function delete($id)
    {
        model('App\Models\ApprenticeshipModel')->delete($id);
        return redirect()->to('/admin/apprenticeships')->with('success', 'Apprenticeship deleted.');
    }
}
