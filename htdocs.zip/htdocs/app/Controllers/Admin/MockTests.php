<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class MockTests extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Manage Mock Tests',
            'mockTests' => model('App\Models\MockTestModel')->orderBy('created_at', 'DESC')->findAll(),
        ];
        return $this->renderAdmin('admin/mock_tests/index', $data);
    }

    public function create()
    {
        $data = [
            'title' => 'Add Mock Test',
        ];
        return $this->renderAdmin('admin/mock_tests/form', $data);
    }

    public function store()
    {
        $model = model('App\Models\MockTestModel');
        $data = $this->request->getPost();
        $data['slug'] = generate_slug($data['title']) . '-' . time();
        $data['is_free'] = $this->request->getPost('is_free') ? 1 : 0;

        if ($model->insert($data)) {
            return redirect()->to('/admin/mock-tests')->with('success', 'Mock test created.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to create mock test.');
    }

    public function edit($id)
    {
        $test = model('App\Models\MockTestModel')->find($id);
        if (!$test) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        $data = [
            'title' => 'Edit Mock Test',
            'test' => $test,
        ];
        return $this->renderAdmin('admin/mock_tests/form', $data);
    }

    public function update($id)
    {
        $model = model('App\Models\MockTestModel');
        $data = $this->request->getPost();
        $data['is_free'] = $this->request->getPost('is_free') ? 1 : 0;
        if ($model->update($id, $data)) {
            return redirect()->to('/admin/mock-tests')->with('success', 'Mock test updated.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to update mock test.');
    }

    public function delete($id)
    {
        model('App\Models\MockTestModel')->delete($id);
        return redirect()->to('/admin/mock-tests')->with('success', 'Mock test deleted.');
    }

    public function questions($id)
    {
        $test = model('App\Models\MockTestModel')->find($id);
        if (!$test) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        $data = [
            'title' => 'Questions - ' . $test['title'],
            'test' => $test,
            'questions' => model('App\Models\MockTestQuestionModel')->getByMockTestId($id),
        ];
        return $this->renderAdmin('admin/mock_tests/questions', $data);
    }

    public function storeQuestions($id)
    {
        $test = model('App\Models\MockTestModel')->find($id);
        if (!$test) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $qModel = model('App\Models\MockTestQuestionModel');
        $questions = $this->request->getPost('questions');

        if (!empty($questions) && is_array($questions)) {
            $qModel->deleteByMockTestId($id);
            $totalMarks = 0;
            $count = 0;

            foreach ($questions as $q) {
                if (!isset($q['question']) || empty(trim($q['question']))) continue;
                $options = [];
                for ($i = 1; $i <= 4; $i++) {
                    $options['option_' . $i] = $q['option_' . $i] ?? '';
                }
                $marks = (float)($q['marks'] ?? 1);
                $totalMarks += $marks;
                $count++;

                $qModel->insert([
                    'mock_test_id' => $id,
                    'question' => $q['question'],
                    'options' => $options,
                    'correct_answer' => $q['correct_answer'] ?? 'option_1',
                    'marks' => $marks,
                    'negative_marks' => (float)($q['negative_marks'] ?? 0),
                    'sort_order' => $count,
                ]);
            }

            model('App\Models\MockTestModel')->update($id, [
                'total_questions' => $count,
                'total_marks' => $totalMarks,
                'passing_marks' => $totalMarks * 0.33,
            ]);
        }

        return redirect()->to('/admin/mock-tests/questions/' . $id)->with('success', 'Questions saved.');
    }
}
