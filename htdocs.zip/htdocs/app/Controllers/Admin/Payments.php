<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Payments extends BaseController
{
    public function index()
    {
        $paymentModel = model('App\Models\PaymentModel');
        $data = [
            'title' => 'Payment Transactions',
            'payments' => $paymentModel->orderBy('created_at', 'DESC')->paginate(30),
            'pager' => $paymentModel->pager,
        ];
        return $this->renderAdmin('admin/payments/index', $data);
    }
}
