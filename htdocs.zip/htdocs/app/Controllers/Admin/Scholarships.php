<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Scholarships extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Manage Scholarships',
            'scholarships' => model('App\Models\ScholarshipModel')->orderBy('created_at', 'DESC')->paginate(20),
        ];
        return $this->renderAdmin('admin/scholarships/index', $data);
    }

    public function create()
    {
        return $this->renderAdmin('admin/scholarships/form', ['title' => 'Add Scholarship']);
    }

    public function store()
    {
        $model = model('App\Models\ScholarshipModel');
        $data = $this->request->getPost();
        $data['slug'] = generate_slug($data['name']) . '-' . time();
        if ($model->insert($data)) {
            return redirect()->to('/admin/scholarships')->with('success', 'Scholarship created.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to create scholarship.');
    }

    public function edit($id)
    {
        $scholarship = model('App\Models\ScholarshipModel')->find($id);
        if (!$scholarship) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        return $this->renderAdmin('admin/scholarships/form', ['title' => 'Edit Scholarship', 'scholarship' => $scholarship]);
    }

    public function update($id)
    {
        if (model('App\Models\ScholarshipModel')->update($id, $this->request->getPost())) {
            return redirect()->to('/admin/scholarships')->with('success', 'Scholarship updated.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to update.');
    }

    public function delete($id)
    {
        model('App\Models\ScholarshipModel')->delete($id);
        return redirect()->to('/admin/scholarships')->with('success', 'Scholarship deleted.');
    }
}
