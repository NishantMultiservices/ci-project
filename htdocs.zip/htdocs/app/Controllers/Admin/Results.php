<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Results extends BaseController
{
    public function index()
    {
        $model = model('App\Models\ResultModel');
        $data = [
            'title' => 'Manage Results',
            'results' => $model->orderBy('created_at', 'DESC')->paginate(20),
            'pager' => $model->pager,
        ];
        return $this->renderAdmin('admin/results/index', $data);
    }

    public function create()
    {
        return $this->renderAdmin('admin/results/form', ['title' => 'Add Result']);
    }

    public function store()
    {
        $model = model('App\Models\ResultModel');
        $data = $this->request->getPost();
        $data['slug'] = generate_slug($data['title']) . '-' . time();
        if ($model->insert($data)) {
            return redirect()->to('/admin/results')->with('success', 'Result created.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to create result.');
    }

    public function edit($id)
    {
        $item = model('App\Models\ResultModel')->find($id);
        if (!$item) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        return $this->renderAdmin('admin/results/form', ['title' => 'Edit Result', 'result' => $item]);
    }

    public function update($id)
    {
        if (model('App\Models\ResultModel')->update($id, $this->request->getPost())) {
            return redirect()->to('/admin/results')->with('success', 'Result updated.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to update.');
    }

    public function delete($id)
    {
        model('App\Models\ResultModel')->delete($id);
        return redirect()->to('/admin/results')->with('success', 'Result deleted.');
    }
}
