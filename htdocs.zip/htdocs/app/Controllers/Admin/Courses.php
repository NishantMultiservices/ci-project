<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Courses extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Manage Courses',
            'courses' => model('App\Models\CourseModel')->orderBy('created_at', 'DESC')->paginate(20),
            'pager' => model('App\Models\CourseModel')->pager,
        ];
        return $this->renderAdmin('admin/courses/index', $data);
    }

    public function create()
    {
        $data = [
            'title' => 'Add Course',
            'categories' => model('App\Models\CategoryModel')->getCourseCategories(),
        ];
        return $this->renderAdmin('admin/courses/form', $data);
    }

    public function store()
    {
        $model = model('App\Models\CourseModel');
        $data = $this->request->getPost();
        $data['slug'] = generate_slug($data['title']) . '-' . time();
        $data['is_free'] = $this->request->getPost('is_free') ? 1 : 0;
        if ($model->insert($data)) {
            return redirect()->to('/admin/courses')->with('success', 'Course created successfully.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to create course.');
    }

    public function edit($id)
    {
        $course = model('App\Models\CourseModel')->find($id);
        if (!$course) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        $data = [
            'title' => 'Edit Course',
            'course' => $course,
            'categories' => model('App\Models\CategoryModel')->getCourseCategories(),
        ];
        return $this->renderAdmin('admin/courses/form', $data);
    }

    public function update($id)
    {
        $model = model('App\Models\CourseModel');
        $data = $this->request->getPost();
        $data['is_free'] = $this->request->getPost('is_free') ? 1 : 0;
        if ($model->update($id, $data)) {
            return redirect()->to('/admin/courses')->with('success', 'Course updated successfully.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to update course.');
    }

    public function delete($id)
    {
        model('App\Models\CourseModel')->delete($id);
        return redirect()->to('/admin/courses')->with('success', 'Course deleted.');
    }
}
