<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Internships extends BaseController
{
    public function index()
    {
        $model = model('App\Models\InternshipModel');
        $data = [
            'title' => 'Manage Internships',
            'internships' => $model->orderBy('created_at', 'DESC')->paginate(20),
            'pager' => $model->pager,
        ];
        return $this->renderAdmin('admin/internships/index', $data);
    }

    public function create()
    {
        $data = [
            'title' => 'Add Internship',
            'categories' => model('App\Models\CategoryModel')->getByType('internship'),
        ];
        return $this->renderAdmin('admin/internships/form', $data);
    }

    public function store()
    {
        $model = model('App\Models\InternshipModel');
        $data = $this->request->getPost();
        $data['slug'] = generate_slug($data['title']) . '-' . time();
        if ($model->insert($data)) {
            return redirect()->to('/admin/internships')->with('success', 'Internship created.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to create internship.');
    }

    public function edit($id)
    {
        $item = model('App\Models\InternshipModel')->find($id);
        if (!$item) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        $data = [
            'title' => 'Edit Internship',
            'internship' => $item,
            'categories' => model('App\Models\CategoryModel')->getByType('internship'),
        ];
        return $this->renderAdmin('admin/internships/form', $data);
    }

    public function update($id)
    {
        if (model('App\Models\InternshipModel')->update($id, $this->request->getPost())) {
            return redirect()->to('/admin/internships')->with('success', 'Internship updated.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to update.');
    }

    public function delete($id)
    {
        model('App\Models\InternshipModel')->delete($id);
        return redirect()->to('/admin/internships')->with('success', 'Internship deleted.');
    }
}
