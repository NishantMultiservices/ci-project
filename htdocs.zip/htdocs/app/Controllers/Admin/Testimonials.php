<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Testimonials extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Manage Testimonials',
            'testimonials' => model('App\Models\TestimonialModel')->orderBy('created_at', 'DESC')->findAll(),
        ];
        return $this->renderAdmin('admin/testimonials/index', $data);
    }

    public function store()
    {
        if (model('App\Models\TestimonialModel')->insert($this->request->getPost())) {
            return redirect()->to('/admin/testimonials')->with('success', 'Testimonial created.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to create testimonial.');
    }

    public function edit($id)
    {
        $item = model('App\Models\TestimonialModel')->find($id);
        if (!$item) throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        return $this->renderAdmin('admin/testimonials/form', ['title' => 'Edit Testimonial', 'testimonial' => $item]);
    }

    public function update($id)
    {
        if (model('App\Models\TestimonialModel')->update($id, $this->request->getPost())) {
            return redirect()->to('/admin/testimonials')->with('success', 'Testimonial updated.');
        }
        return redirect()->back()->withInput()->with('error', 'Failed to update.');
    }

    public function delete($id)
    {
        model('App\Models\TestimonialModel')->delete($id);
        return redirect()->to('/admin/testimonials')->with('success', 'Testimonial deleted.');
    }
}
