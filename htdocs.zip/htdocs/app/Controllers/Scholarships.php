<?php

namespace App\Controllers;

class Scholarships extends BaseController
{
    public function index()
    {
        $scholarshipModel = model('App\Models\ScholarshipModel');
        $type = $this->request->getGet('type');

        $data = [
            'title' => meta_title('Scholarships'),
            'description' => 'Find government, private, and minority scholarships.',
            'scholarships' => $type ? $scholarshipModel->getByType($type, 20) : $scholarshipModel->getLatest(20),
        ];
        return $this->render('scholarships/index', $data);
    }

    public function detail($id)
    {
        $scholarshipModel = model('App\Models\ScholarshipModel');
        $scholarship = $scholarshipModel->find($id);

        if (!$scholarship || !$scholarship['is_active']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $scholarshipModel->incrementViews($id);

        $data = [
            'title' => meta_title($scholarship['name'] . ' - Scholarship'),
            'scholarship' => $scholarship,
        ];
        return $this->render('scholarships/detail', $data);
    }
}
