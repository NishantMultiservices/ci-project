<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
    public function index()
    {
        if (!is_logged_in()) {
            return redirect()->to('/login');
        }

        $userId = user_id();
        $applicationModel = model('App\Models\ApplicationModel');
        $bookmarkModel = model('App\Models\BookmarkModel');
        $notificationModel = model('App\Models\NotificationModel');

        $data = [
            'title' => meta_title('Dashboard'),
            'applications_count' => count($applicationModel->getUserApplications($userId)),
            'saved_jobs_count' => count($bookmarkModel->getUserBookmarks($userId, 'job')),
            'enrolled_courses_count' => count(model('App\Models\EnrollmentModel')->getUserEnrollments($userId)),
            'notifications_count' => $notificationModel->getUnreadCount($userId),
            'recent_notifications' => $notificationModel->getUserNotifications($userId, 5),
            'recent_applications' => $applicationModel->getUserApplications($userId),
        ];
        return $this->renderDashboard('dashboard/index', $data);
    }

    public function profile()
    {
        $userId = user_id();
        $data = [
            'title' => meta_title('My Profile'),
            'profile' => model('App\Models\UserModel')->find($userId),
            'educations' => model('App\Models\UserEducationModel')->getUserEducations($userId),
            'experiences' => model('App\Models\UserExperienceModel')->getUserExperiences($userId),
        ];
        return $this->renderDashboard('dashboard/profile', $data);
    }

    public function updateProfile()
    {
        $userId = user_id();
        $userModel = model('App\Models\UserModel');

        $userModel->update($userId, [
            'name' => $this->request->getPost('name'),
            'phone' => $this->request->getPost('phone'),
        ]);

        $currentPassword = $this->request->getPost('current_password');
        $newPassword = $this->request->getPost('new_password');
        if (!empty($currentPassword) && !empty($newPassword)) {
            $user = $userModel->find($userId);
            if ($userModel->verifyPassword($currentPassword, $user['password'])) {
                $userModel->update($userId, ['password' => $newPassword]);
            } else {
                return redirect()->back()->with('error', 'Current password is incorrect.');
            }
        }

        $eduModel = model('App\Models\UserEducationModel');
        $eduModel->deleteByUserId($userId);
        $educations = $this->request->getPost('educations');
        if (!empty($educations) && is_array($educations)) {
            foreach ($educations as $e) {
                if (empty(trim($e['degree'] ?? ''))) continue;
                $eduModel->insert([
                    'user_id' => $userId,
                    'degree' => $e['degree'],
                    'institution' => $e['institution'] ?? '',
                    'board' => $e['board'] ?? '',
                    'year_from' => !empty($e['year_from']) ? $e['year_from'] : null,
                    'year_to' => !empty($e['year_to']) ? $e['year_to'] : null,
                    'percentage' => !empty($e['percentage']) ? $e['percentage'] : null,
                ]);
            }
        }

        $expModel = model('App\Models\UserExperienceModel');
        $expModel->deleteByUserId($userId);
        $experiences = $this->request->getPost('experiences');
        if (!empty($experiences) && is_array($experiences)) {
            foreach ($experiences as $e) {
                if (empty(trim($e['role'] ?? ''))) continue;
                $expModel->insert([
                    'user_id' => $userId,
                    'company' => $e['company'] ?? '',
                    'role' => $e['role'],
                    'location' => $e['location'] ?? '',
                    'from_date' => !empty($e['from_date']) ? $e['from_date'] : null,
                    'to_date' => !empty($e['to_date']) ? $e['to_date'] : null,
                    'is_current' => !empty($e['is_current']) ? 1 : 0,
                    'description' => $e['description'] ?? '',
                ]);
            }
        }

        return redirect()->to('/dashboard/profile')->with('success', 'Profile updated successfully.');
    }

    public function savedJobs()
    {
        $bookmarkModel = model('App\Models\BookmarkModel');
        $bookmarks = $bookmarkModel->getUserBookmarks(user_id(), 'job');

        $jobIds = array_column($bookmarks, 'item_id');
        $jobs = [];
        if (!empty($jobIds)) {
            $jobs = model('App\Models\JobModel')->whereIn('id', $jobIds)->findAll();
        }

        $data = [
            'title' => meta_title('Saved Jobs'),
            'jobs' => $jobs,
        ];
        return $this->renderDashboard('dashboard/saved_jobs', $data);
    }

    public function appliedJobs()
    {
        $applications = model('App\Models\ApplicationModel')->getUserApplications(user_id(), 'job');
        $jobIds = array_column($applications, 'job_id');

        $jobs = [];
        if (!empty($jobIds)) {
            $jobs = model('App\Models\JobModel')->whereIn('id', $jobIds)->findAll();
        }

        $data = [
            'title' => meta_title('Applied Jobs'),
            'applications' => $applications,
            'jobs' => $jobs,
        ];
        return $this->renderDashboard('dashboard/applied_jobs', $data);
    }

    public function resume()
    {
        $resumes = model('App\Models\ResumeModel')->getUserResumes(user_id());
        $data = [
            'title' => meta_title('My Resumes'),
            'resumes' => $resumes,
        ];
        return $this->renderDashboard('dashboard/resume', $data);
    }

    public function certificates()
    {
        $data = [
            'title' => meta_title('My Certificates'),
            'certificates' => model('App\Models\CertificateModel')->getUserCertificates(user_id()),
        ];
        return $this->renderDashboard('dashboard/certificates', $data);
    }

    public function mockTests()
    {
        $userId = user_id();
        $testModel = model('App\Models\MockTestModel');
        $attemptModel = model('App\Models\MockTestAttemptModel');
        $attempts = $attemptModel->getUserAttempts($userId);

        $testIds = array_unique(array_filter(array_column($attempts, 'mock_test_id')));
        $tests = [];
        if (!empty($testIds)) {
            foreach ($testModel->whereIn('id', $testIds)->findAll() as $t) {
                $tests[$t['id']] = $t['title'];
            }
        }

        $totalTests = count($attempts);
        $completedAttempts = array_filter($attempts, fn($a) => $a['status'] === 'completed');
        $avgScore = 0;
        $bestScore = 0;
        if (!empty($completedAttempts)) {
            $scores = array_column($completedAttempts, 'score');
            $avgScore = round(array_sum($scores) / count($scores), 1);
            $bestScore = max($scores);
        }

        $data = [
            'title' => meta_title('Mock Tests'),
            'mockTests' => $testModel->getActive(),
            'attempts' => $attempts,
            'testTitles' => $tests,
            'totalTests' => $totalTests,
            'completedTests' => count($completedAttempts),
            'avgScore' => $avgScore,
            'bestScore' => $bestScore,
        ];
        return $this->renderDashboard('dashboard/mock_tests', $data);
    }

    public function mockTestResult($attemptId)
    {
        $attemptModel = model('App\Models\MockTestAttemptModel');
        $attempt = $attemptModel->getWithTest($attemptId);
        if (!$attempt || $attempt['user_id'] != user_id()) {
            return redirect()->to('/dashboard/mock-tests')->with('error', 'Result not found.');
        }

        $answers = model('App\Models\MockTestAnswerModel')->getWithQuestions($attemptId);

        $data = [
            'title' => meta_title('Test Result'),
            'attempt' => $attempt,
            'answers' => $answers,
        ];
        return $this->renderDashboard('dashboard/mock_tests_result', $data);
    }

    public function enrolledCourses()
    {
        $data = [
            'title' => meta_title('My Courses'),
            'enrollments' => model('App\Models\EnrollmentModel')->getUserEnrollments(user_id()),
        ];
        return $this->renderDashboard('dashboard/enrolled_courses', $data);
    }

    public function bookmarks()
    {
        $bookmarkModel = model('App\Models\BookmarkModel');
        $bookmarks = $bookmarkModel->getUserBookmarks(user_id());

        $jobIds = [];
        $courseIds = [];
        foreach ($bookmarks as $b) {
            if ($b['type'] === 'job') $jobIds[] = $b['item_id'];
            if ($b['type'] === 'course') $courseIds[] = $b['item_id'];
        }

        $jobs = [];
        $courses = [];
        if (!empty($jobIds)) {
            $jobs = model('App\Models\JobModel')
                ->select('id, title, company_name, location, job_type, salary_min, salary_max, salary_text, slug')
                ->whereIn('id', $jobIds)->findAll();
            $jobs = array_column($jobs, null, 'id');
        }
        if (!empty($courseIds)) {
            $courses = model('App\Models\CourseModel')
                ->select('id, title, instructor_name, duration, level, slug')
                ->whereIn('id', $courseIds)->findAll();
            $courses = array_column($courses, null, 'id');
        }

        $data = [
            'title' => meta_title('My Bookmarks'),
            'bookmarks' => $bookmarks,
            'jobs' => $jobs,
            'courses' => $courses,
        ];
        return $this->renderDashboard('dashboard/bookmarks', $data);
    }

    public function notifications()
    {
        $notificationModel = model('App\Models\NotificationModel');
        $data = [
            'title' => meta_title('Notifications'),
            'notifications' => $notificationModel->getUserNotifications(user_id()),
        ];
        return $this->renderDashboard('dashboard/notifications', $data);
    }

    public function settings()
    {
        $data = ['title' => meta_title('Settings')];
        return $this->renderDashboard('dashboard/settings', $data);
    }

    public function updateSettings()
    {
        return redirect()->to('/dashboard/settings')->with('success', 'Settings updated successfully.');
    }

    public function toggleBookmark()
    {
        if (!is_logged_in()) {
            return $this->jsonResponse(['error' => 'Unauthorized'], 401);
        }

        $itemId = $this->request->getPost('item_id');
        $type = $this->request->getPost('type');

        $isBookmarked = model('App\Models\BookmarkModel')->toggle(user_id(), $itemId, $type);
        return $this->jsonResponse(['bookmarked' => $isBookmarked]);
    }

    public function applyJob()
    {
        if (!is_logged_in()) {
            return redirect()->to('/login')->with('error', 'Please login to apply.');
        }

        $jobId = $this->request->getPost('job_id');
        $jobModel = model('App\Models\JobModel');
        $job = $jobModel->find($jobId);

        if (!$job) {
            return redirect()->back()->with('error', 'Job not found.');
        }

        $applicationModel = model('App\Models\ApplicationModel');
        if ($applicationModel->hasApplied(user_id(), $jobId, 'job')) {
            return redirect()->back()->with('info', 'You have already applied for this job.');
        }

        $applicationModel->save([
            'user_id' => user_id(),
            'job_id' => $jobId,
            'type' => 'job',
            'status' => 'pending',
            'applied_at' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->back()->with('success', 'Application submitted successfully!');
    }
}
