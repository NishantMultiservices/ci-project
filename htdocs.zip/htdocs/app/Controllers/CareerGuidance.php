<?php

namespace App\Controllers;

class CareerGuidance extends BaseController
{
    public function index()
    {
        $careerModel = model('App\Models\CareerGuidanceModel');
        $data = [
            'title' => meta_title('Career Guidance'),
            'description' => 'Get expert career guidance, tips, and study plans.',
            'articles' => $careerModel->getPublished(20),
        ];
        return $this->render('career_guidance/index', $data);
    }

    public function article($slug)
    {
        $careerModel = model('App\Models\CareerGuidanceModel');
        $article = $careerModel->getBySlug($slug);

        if (!$article) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $data = [
            'title' => meta_title($article['title']),
            'article' => $article,
        ];
        return $this->render('career_guidance/detail', $data);
    }
}
