<?php

namespace App\Controllers;

class Jobs extends BaseController
{
    public function index()
    {
        $jobModel = model('App\Models\JobModel');
        $catModel = model('App\Models\CategoryModel');

        $filters = [
            'keyword' => $this->request->getGet('q'),
            'state' => $this->request->getGet('state'),
            'category' => $this->request->getGet('category'),
            'job_type' => $this->request->getGet('type'),
            'experience' => $this->request->getGet('experience'),
            'salary_min' => $this->request->getGet('salary'),
            'qualification' => $this->request->getGet('qualification'),
            'department' => $this->request->getGet('department'),
        ];

        $data = [
            'title' => meta_title('Latest Jobs'),
            'description' => 'Browse latest job openings in government and private sectors.',
            'jobs' => $jobModel->search(array_filter($filters), 12),
            'pager' => $jobModel->pager,
            'categories' => $catModel->getJobCategories(),
            'filters' => $filters,
            'states' => ['Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Delhi','Goa','Gujarat','Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand','West Bengal','All India'],
        ];

        return $this->render('jobs/index', $data);
    }

    public function detail($id)
    {
        $jobModel = model('App\Models\JobModel');
        $job = $jobModel->find($id);

        if (!$job || !$job['is_active']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $jobModel->incrementViews($id);

        $bookmarked = false;
        if (is_logged_in()) {
            $bookmarked = model('App\Models\BookmarkModel')->isBookmarked(user_id(), $id, 'job');
        }

        $data = [
            'title' => meta_title($job['title'] . ' at ' . $job['company_name']),
            'description' => truncate_text($job['description'] ?? 'Apply for ' . $job['title'] . ' at ' . $job['company_name'] . '. Last date: ' . $job['last_date_to_apply']),
            'job' => $job,
            'related_jobs' => $jobModel->getRelated($id, $job['category_id'], 4),
            'bookmarked' => $bookmarked,
            'jobPosts' => model('App\Models\JobPostModel')->getByJobId($id),
            'og_tags' => og_tags([
                'title' => $job['title'] . ' - RojgarSandhi',
                'description' => truncate_text(strip_tags($job['description'] ?? ''), 160),
                'type' => 'article',
            ]),
        ];

        return $this->render('jobs/detail', $data);
    }

    public function government()
    {
        $jobModel = model('App\Models\JobModel');
        $data = [
            'title' => meta_title('Government Jobs'),
            'description' => 'Find latest government job openings across India.',
            'jobs' => $jobModel->getGovernment(20),
            'job_type' => 'government',
            'states' => ['Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Delhi','Goa','Gujarat','Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand','West Bengal','All India'],
        ];
        return $this->render('jobs/index', $data);
    }

    public function private()
    {
        $jobModel = model('App\Models\JobModel');
        $data = [
            'title' => meta_title('Private Jobs'),
            'description' => 'Browse private sector job opportunities.',
            'jobs' => $jobModel->getPrivate(20),
            'job_type' => 'private',
            'states' => ['Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Delhi','Goa','Gujarat','Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand','West Bengal','All India'],
        ];
        return $this->render('jobs/index', $data);
    }

    public function category($slug)
    {
        $catModel = model('App\Models\CategoryModel');
        $category = $catModel->getBySlug($slug);

        if (!$category) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $jobModel = model('App\Models\JobModel');
        $data = [
            'title' => meta_title($category['name'] . ' Jobs'),
            'description' => 'Find latest ' . $category['name'] . ' job openings.',
            'jobs' => $jobModel->getByCategory($slug, 20),
            'category' => $category,
            'states' => ['Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Delhi','Goa','Gujarat','Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand','West Bengal','All India'],
        ];
        return $this->render('jobs/index', $data);
    }
}
