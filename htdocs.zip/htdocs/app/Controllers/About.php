<?php

namespace App\Controllers;

class About extends BaseController
{
    public function index()
    {
        $data = [
            'title' => meta_title('About Us'),
            'description' => 'Learn about RojgarSandhi - India\'s premier career platform.',
        ];
        return $this->render('about/index', $data);
    }
}
