<?php

namespace App\Controllers;

class Notifications extends BaseController
{
    public function index()
    {
        if (!is_logged_in()) {
            return redirect()->to('/login');
        }

        $notificationModel = model('App\Models\NotificationModel');
        $data = [
            'title' => meta_title('Notifications'),
            'notifications' => $notificationModel->getUserNotifications(user_id()),
        ];
        return $this->render('notifications/index', $data);
    }

    public function markRead($id)
    {
        if (!is_logged_in()) {
            return $this->jsonResponse(['error' => 'Unauthorized'], 401);
        }

        model('App\Models\NotificationModel')->markAsRead($id, user_id());
        return $this->jsonResponse(['success' => true]);
    }
}
