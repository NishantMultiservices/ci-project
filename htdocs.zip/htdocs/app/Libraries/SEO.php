<?php

namespace App\Libraries;

class SEO
{
    protected array $data = [
        'title' => '',
        'description' => '',
        'keywords' => '',
        'og_image' => '',
        'og_type' => 'website',
        'canonical' => '',
        'noindex' => false,
    ];

    public function setTitle(string $title): self
    {
        $this->data['title'] = $title;
        return $this;
    }

    public function setDescription(string $description): self
    {
        $this->data['description'] = $description;
        return $this;
    }

    public function setKeywords(string $keywords): self
    {
        $this->data['keywords'] = $keywords;
        return $this;
    }

    public function setOgImage(string $image): self
    {
        $this->data['og_image'] = $image;
        return $this;
    }

    public function setCanonical(string $url): self
    {
        $this->data['canonical'] = $url;
        return $this;
    }

    public function setNoindex(bool $noindex = true): self
    {
        $this->data['noindex'] = $noindex;
        return $this;
    }

    public function render(): array
    {
        return $this->data;
    }
}
