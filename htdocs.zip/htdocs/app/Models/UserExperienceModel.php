<?php

namespace App\Models;

use CodeIgniter\Model;

class UserExperienceModel extends Model
{
    protected $table = 'user_experience';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'user_id', 'company', 'role', 'location',
        'from_date', 'to_date', 'is_current', 'description'
    ];
    protected $useTimestamps = true;

    public function getUserExperiences(int $userId): array
    {
        return $this->where('user_id', $userId)->orderBy('from_date', 'DESC')->findAll();
    }

    public function deleteByUserId(int $userId): void
    {
        $this->where('user_id', $userId)->delete();
    }
}
