<?php

namespace App\Models;

use CodeIgniter\Model;

class BookmarkModel extends Model
{
    protected $table = 'bookmarks';
    protected $primaryKey = 'id';
    protected $allowedFields = ['user_id', 'item_id', 'type'];
    protected $useTimestamps = false;

    public function getUserBookmarks(int $userId, string $type = null): array
    {
        $builder = $this->where('user_id', $userId);
        if ($type) $builder->where('type', $type);
        return $builder->orderBy('created_at', 'DESC')->findAll();
    }

    public function isBookmarked(int $userId, int $itemId, string $type): bool
    {
        return $this->where('user_id', $userId)
            ->where('item_id', $itemId)
            ->where('type', $type)
            ->first() !== null;
    }

    public function toggle(int $userId, int $itemId, string $type): bool
    {
        $existing = $this->where('user_id', $userId)
            ->where('item_id', $itemId)
            ->where('type', $type)
            ->first();
        
        if ($existing) {
            $this->delete($existing['id']);
            return false;
        }
        
        $this->save([
            'user_id' => $userId,
            'item_id' => $itemId,
            'type' => $type
        ]);
        return true;
    }
}
