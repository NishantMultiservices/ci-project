<?php

namespace App\Models;

use CodeIgniter\Model;

class CategoryModel extends Model
{
    protected $table = 'categories';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'name', 'slug', 'type', 'description', 'icon', 'parent_id', 'sort_order', 'is_active'
    ];
    protected $useTimestamps = true;

    public function getByType(string $type): array
    {
        return $this->where('type', $type)
            ->where('is_active', 1)
            ->orderBy('sort_order', 'ASC')
            ->findAll();
    }

    public function getJobCategories(): array
    {
        return $this->getByType('job');
    }

    public function getCourseCategories(): array
    {
        return $this->getByType('course');
    }

    public function getBySlug(string $slug): ?array
    {
        return $this->where('slug', $slug)->first();
    }
}
