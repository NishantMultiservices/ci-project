<?php

namespace App\Models;

use CodeIgniter\Model;

class SettingModel extends Model
{
    protected $table = 'settings';
    protected $primaryKey = 'id';
    protected $allowedFields = ['key_name', 'key_value', 'group_name'];
    protected $useTimestamps = true;

    public function get(string $key, string $default = ''): string
    {
        $result = $this->where('key_name', $key)->first();
        return $result ? $result['key_value'] : $default;
    }

    public function set($key, $value = '', ?bool $escape = null)
    {
        $existing = $this->where('key_name', $key)->first();
        if ($existing) {
            $this->update($existing['id'], ['key_value' => $value]);
        } else {
            $this->save(['key_name' => $key, 'key_value' => $value]);
        }
    }

    public function getGroup(string $group): array
    {
        $results = $this->where('group_name', $group)->findAll();
        $settings = [];
        foreach ($results as $row) {
            $settings[$row['key_name']] = $row['key_value'];
        }
        return $settings;
    }
}
