<?php

namespace App\Models;

use CodeIgniter\Model;

class LessonQuizAnswerModel extends Model
{
    protected $table = 'lesson_quiz_answers';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'attempt_id', 'question_id', 'selected_option',
        'is_correct', 'marks_obtained'
    ];
    protected $useTimestamps = false;
}
