<?php

namespace App\Models;

use CodeIgniter\Model;

class InternshipModel extends Model
{
    protected $table = 'internships';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'title', 'slug', 'company_name', 'company_logo', 'category_id', 'type',
        'location', 'state', 'stipend_min', 'stipend_max', 'stipend_text',
        'duration', 'duration_months', 'qualification_required', 'skills_required',
        'description', 'responsibilities', 'perks', 'apply_link',
        'last_date_to_apply', 'start_date', 'positions_available',
        'is_featured', 'is_active', 'views_count'
    ];
    protected $useTimestamps = true;
    protected $useSoftDeletes = true;

    public function getLatest(int $limit = 10): array
    {
        return $this->where('is_active', 1)->orderBy('created_at', 'DESC')->findAll($limit);
    }

    public function getFeatured(int $limit = 6): array
    {
        return $this->where('is_featured', 1)->where('is_active', 1)->findAll($limit);
    }

    public function getByType(string $type, int $limit = 10): array
    {
        return $this->where('type', $type)->where('is_active', 1)->orderBy('created_at', 'DESC')->findAll($limit);
    }

    public function getTotalInternships(): int
    {
        return $this->where('is_active', 1)->countAllResults();
    }

    public function incrementViews(int $id): void
    {
        $this->set('views_count', 'views_count + 1', false)->where('id', $id)->update();
    }
}
