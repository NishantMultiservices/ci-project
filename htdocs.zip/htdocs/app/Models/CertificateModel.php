<?php

namespace App\Models;

use CodeIgniter\Model;

class CertificateModel extends Model
{
    protected $table = 'certificates';
    protected $primaryKey = 'id';
    protected $allowedFields = ['user_id', 'course_id', 'certificate_number', 'issued_at'];
    protected $useTimestamps = true;

    public function getUserCertificates(int $userId): array
    {
        return $this->select('certificates.*, courses.title as course_title, courses.instructor_name, courses.duration')
            ->join('courses', 'courses.id = certificates.course_id')
            ->where('certificates.user_id', $userId)
            ->orderBy('certificates.issued_at', 'DESC')
            ->findAll();
    }

    public function hasCertificate(int $userId, int $courseId): bool
    {
        return $this->where('user_id', $userId)->where('course_id', $courseId)->first() !== null;
    }

    public function generate(int $userId, int $courseId): ?array
    {
        if ($this->hasCertificate($userId, $courseId)) {
            return $this->where('user_id', $userId)->where('course_id', $courseId)->first();
        }

        $course = model('App\Models\CourseModel')->find($courseId);
        $number = 'CERT-' . strtoupper(substr(md5($userId . '-' . $courseId . '-' . time()), 0, 10)) . '-' . $userId . '-' . $courseId;

        $this->insert([
            'user_id' => $userId,
            'course_id' => $courseId,
            'certificate_number' => $number,
            'issued_at' => date('Y-m-d H:i:s'),
        ]);

        return $this->where('user_id', $userId)->where('course_id', $courseId)->first();
    }
}
