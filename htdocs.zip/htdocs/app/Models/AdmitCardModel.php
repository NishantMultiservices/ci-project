<?php

namespace App\Models;

use CodeIgniter\Model;

class AdmitCardModel extends Model
{
    protected $table = 'admit_cards';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'title', 'slug', 'category_id', 'exam_name', 'description', 'download_link',
        'pdf_file', 'exam_date', 'release_date', 'last_date_to_download', 'instructions',
        'is_active', 'views_count'
    ];
    protected $useTimestamps = true;
    protected $useSoftDeletes = true;

    public function getLatest(int $limit = 10): array
    {
        return $this->where('is_active', 1)->orderBy('release_date', 'DESC')->findAll($limit);
    }

    public function incrementViews(int $id): void
    {
        $this->set('views_count', 'views_count + 1', false)->where('id', $id)->update();
    }
}
