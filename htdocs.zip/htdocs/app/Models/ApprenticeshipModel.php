<?php

namespace App\Models;

use CodeIgniter\Model;

class ApprenticeshipModel extends Model
{
    protected $table = 'apprenticeships';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'title', 'slug', 'company_name', 'company_logo', 'category_id', 'type',
        'trade', 'location', 'state', 'stipend', 'stipend_text', 'duration',
        'qualification_required', 'description', 'requirements', 'benefits',
        'apply_link', 'last_date_to_apply', 'is_featured', 'is_active', 'views_count'
    ];
    protected $useTimestamps = true;
    protected $useSoftDeletes = true;

    public function getLatest(int $limit = 10): array
    {
        return $this->where('is_active', 1)->orderBy('created_at', 'DESC')->findAll($limit);
    }

    public function getFeatured(int $limit = 6): array
    {
        return $this->where('is_featured', 1)->where('is_active', 1)->findAll($limit);
    }

    public function getByType(string $type, int $limit = 10): array
    {
        return $this->where('type', $type)->where('is_active', 1)->findAll($limit);
    }

    public function incrementViews(int $id): void
    {
        $this->set('views_count', 'views_count + 1', false)->where('id', $id)->update();
    }
}
