<?php

namespace App\Models;

use CodeIgniter\Model;

class CourseLessonModel extends Model
{
    protected $table = 'course_lessons';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'course_id', 'title', 'content_type', 'content', 'video_url',
        'duration', 'sort_order', 'is_free_preview'
    ];
    protected $useTimestamps = true;

    public function getCourseLessons(int $courseId): array
    {
        return $this->where('course_id', $courseId)
            ->orderBy('sort_order', 'ASC')
            ->orderBy('id', 'ASC')
            ->findAll();
    }
}
