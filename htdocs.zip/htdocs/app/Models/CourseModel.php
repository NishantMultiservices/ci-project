<?php

namespace App\Models;

use CodeIgniter\Model;

class CourseModel extends Model
{
    protected $table = 'courses';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'title', 'slug', 'category_id', 'short_description', 'description', 'thumbnail',
        'price', 'is_free', 'duration', 'level', 'topics_covered', 'what_you_learn',
        'requirements', 'instructor_name', 'instructor_bio', 'instructor_avatar',
        'total_lessons', 'total_hours', 'rating', 'total_enrolled',
        'is_featured', 'is_active', 'views_count'
    ];
    protected $useTimestamps = true;
    protected $useSoftDeletes = true;

    public function getLatest(int $limit = 10): array
    {
        return $this->where('is_active', 1)->orderBy('created_at', 'DESC')->findAll($limit);
    }

    public function getFeatured(int $limit = 6): array
    {
        return $this->where('is_featured', 1)->where('is_active', 1)->findAll($limit);
    }

    public function getByCategory(int $categoryId): array
    {
        return $this->where('category_id', $categoryId)->where('is_active', 1)->findAll();
    }

    public function getTotalCourses(): int
    {
        return $this->where('is_active', 1)->countAllResults();
    }

    public function incrementViews(int $id): void
    {
        $this->set('views_count', 'views_count + 1', false)->where('id', $id)->update();
    }
}
