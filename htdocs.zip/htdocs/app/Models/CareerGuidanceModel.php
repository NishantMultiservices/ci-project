<?php

namespace App\Models;

use CodeIgniter\Model;

class CareerGuidanceModel extends Model
{
    protected $table = 'career_guidance';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'title', 'slug', 'category', 'excerpt', 'content', 'featured_image',
        'author_name', 'is_featured', 'is_published', 'views_count', 'published_at'
    ];
    protected $useTimestamps = true;

    public function getPublished(int $limit = 10): array
    {
        return $this->where('is_published', 1)->orderBy('published_at', 'DESC')->findAll($limit);
    }

    public function getFeatured(int $limit = 3): array
    {
        return $this->where('is_featured', 1)->where('is_published', 1)->findAll($limit);
    }

    public function getBySlug(string $slug): ?array
    {
        return $this->where('slug', $slug)->where('is_published', 1)->first();
    }

    public function getByCategory(string $category): array
    {
        return $this->where('category', $category)->where('is_published', 1)->findAll();
    }
}
