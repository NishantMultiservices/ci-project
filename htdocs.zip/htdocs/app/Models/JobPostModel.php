<?php

namespace App\Models;

use CodeIgniter\Model;

class JobPostModel extends Model
{
    protected $table = 'job_posts';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'job_id', 'title', 'qualification', 'vacancies',
        'experience_min', 'experience_max', 'salary_min', 'salary_max', 'department'
    ];
    protected $useTimestamps = true;

    public function getByJobId(int $jobId): array
    {
        return $this->where('job_id', $jobId)->orderBy('id', 'ASC')->findAll();
    }

    public function deleteByJobId(int $jobId): void
    {
        $this->where('job_id', $jobId)->delete();
    }
}
