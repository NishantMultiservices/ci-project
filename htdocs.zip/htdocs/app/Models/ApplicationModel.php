<?php

namespace App\Models;

use CodeIgniter\Model;

class ApplicationModel extends Model
{
    protected $table = 'applications';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'user_id', 'job_id', 'internship_id', 'apprenticeship_id', 'scholarship_id',
        'type', 'status', 'cover_letter', 'resume_file', 'applied_at'
    ];
    protected $useTimestamps = true;

    public function getUserApplications(int $userId, string $type = null): array
    {
        $builder = $this->where('user_id', $userId);
        if ($type) $builder->where('type', $type);
        return $builder->orderBy('created_at', 'DESC')->findAll();
    }

    public function hasApplied(int $userId, int $itemId, string $type): bool
    {
        return $this->where('user_id', $userId)
            ->where("{$type}_id", $itemId)
            ->where('type', $type)
            ->first() !== null;
    }

    public function getByJob(int $jobId): array
    {
        return $this->where('job_id', $jobId)->where('type', 'job')->findAll();
    }

    public function getByStatus(string $status): array
    {
        return $this->where('status', $status)->findAll();
    }

    public function getTotalApplications(): int
    {
        return $this->countAllResults();
    }
}
