<?php

namespace App\Models;

use CodeIgniter\Model;

class InterviewTopicModel extends Model
{
    protected $table = 'interview_topics';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'title', 'slug', 'category', 'exam_category', 'description', 'content',
        'questions', 'duration_minutes', 'total_questions', 'difficulty', 'is_active', 'views_count'
    ];
    protected $useTimestamps = true;
    protected array $casts = [
        'questions' => 'json',
    ];

    public function getActive(int $limit = 20): array
    {
        return $this->where('is_active', 1)->orderBy('category', 'ASC')->findAll($limit);
    }

    public function getByCategory(string $category): array
    {
        return $this->where('category', $category)->where('is_active', 1)->findAll();
    }

    public function getByExamCategory(string $examCategory): array
    {
        return $this->where('exam_category', $examCategory)->where('is_active', 1)->findAll();
    }
}
