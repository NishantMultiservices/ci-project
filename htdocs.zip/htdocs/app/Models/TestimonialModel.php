<?php

namespace App\Models;

use CodeIgniter\Model;

class TestimonialModel extends Model
{
    protected $table = 'testimonials';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'user_id', 'name', 'designation', 'company', 'avatar', 'content', 'rating', 'is_approved', 'sort_order'
    ];
    protected $useTimestamps = true;

    public function getApproved(int $limit = 10): array
    {
        return $this->where('is_approved', 1)->orderBy('sort_order', 'ASC')->orderBy('created_at', 'DESC')->findAll($limit);
    }
}
