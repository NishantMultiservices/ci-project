<?php

namespace App\Models;

use CodeIgniter\Model;

class UserEducationModel extends Model
{
    protected $table = 'user_education';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'user_id', 'degree', 'institution', 'board',
        'year_from', 'year_to', 'percentage'
    ];
    protected $useTimestamps = true;

    public function getUserEducations(int $userId): array
    {
        return $this->where('user_id', $userId)->orderBy('year_to', 'DESC')->findAll();
    }

    public function deleteByUserId(int $userId): void
    {
        $this->where('user_id', $userId)->delete();
    }
}
