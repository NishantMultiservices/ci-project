<?php

namespace App\Models;

use CodeIgniter\Model;

class MockTestAttemptModel extends Model
{
    protected $table = 'mock_test_attempts';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'mock_test_id', 'user_id', 'started_at', 'completed_at',
        'score', 'total_marks', 'correct_count', 'incorrect_count',
        'unanswered_count', 'status'
    ];
    protected $useTimestamps = true;

    public function getUserAttempts(int $userId, int $limit = 20): array
    {
        return $this->where('user_id', $userId)
            ->orderBy('created_at', 'DESC')
            ->findAll($limit);
    }

    public function getIncompleteAttempt(int $userId, int $mockTestId)
    {
        return $this->where('user_id', $userId)
            ->where('mock_test_id', $mockTestId)
            ->where('status', 'in_progress')
            ->first();
    }

    public function getWithTest(int $id)
    {
        return $this->select('mock_test_attempts.*, mock_tests.title, mock_tests.total_questions, mock_tests.total_marks, mock_tests.passing_marks')
            ->join('mock_tests', 'mock_tests.id = mock_test_attempts.mock_test_id')
            ->where('mock_test_attempts.id', $id)
            ->first();
    }
}
