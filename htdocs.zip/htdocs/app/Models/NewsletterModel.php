<?php

namespace App\Models;

use CodeIgniter\Model;

class NewsletterModel extends Model
{
    protected $table = 'newsletter_subscribers';
    protected $primaryKey = 'id';
    protected $allowedFields = ['email', 'is_active'];
    protected $useTimestamps = false;

    public function subscribe(string $email): bool
    {
        $existing = $this->where('email', $email)->first();
        if ($existing) {
            if (!$existing['is_active']) {
                return $this->update($existing['id'], ['is_active' => 1]);
            }
            return true;
        }
        return $this->save(['email' => $email]) !== false;
    }

    public function unsubscribe(string $email): bool
    {
        return $this->where('email', $email)->set(['is_active' => 0])->update();
    }

    public function getTotalSubscribers(): int
    {
        return $this->where('is_active', 1)->countAllResults();
    }
}
