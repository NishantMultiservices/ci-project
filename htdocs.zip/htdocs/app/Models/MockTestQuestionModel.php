<?php

namespace App\Models;

use CodeIgniter\Model;

class MockTestQuestionModel extends Model
{
    protected $table = 'mock_test_questions';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'mock_test_id', 'question', 'options', 'correct_answer',
        'marks', 'negative_marks', 'sort_order'
    ];
    protected $useTimestamps = true;
    protected $beforeInsert = ['encodeOptions'];
    protected $beforeUpdate = ['encodeOptions'];
    protected $afterFind = ['decodeOptions'];

    protected function encodeOptions(array $data)
    {
        if (isset($data['data']['options']) && is_array($data['data']['options'])) {
            $data['data']['options'] = json_encode($data['data']['options']);
        }
        return $data;
    }

    protected function decodeOptions(array $data)
    {
        if (isset($data['data']['options']) && is_string($data['data']['options'])) {
            $data['data']['options'] = json_decode($data['data']['options'], true);
        }
        if (isset($data['data'][0])) {
            $first = $data['data'][0];
            if (is_object($first) && isset($first->options) && is_string($first->options)) {
                foreach ($data['data'] as &$row) {
                    $row->options = json_decode($row->options, true);
                }
            } elseif (is_array($first) && isset($first['options']) && is_string($first['options'])) {
                foreach ($data['data'] as &$row) {
                    $row['options'] = json_decode($row['options'], true);
                }
            }
        }
        return $data;
    }

    public function getByMockTestId(int $mockTestId): array
    {
        return $this->where('mock_test_id', $mockTestId)
            ->orderBy('sort_order', 'ASC')
            ->orderBy('id', 'ASC')
            ->findAll();
    }

    public function deleteByMockTestId(int $mockTestId): void
    {
        $this->where('mock_test_id', $mockTestId)->delete();
    }
}
