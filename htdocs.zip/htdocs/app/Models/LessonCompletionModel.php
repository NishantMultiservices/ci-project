<?php

namespace App\Models;

use CodeIgniter\Model;

class LessonCompletionModel extends Model
{
    protected $table = 'lesson_completions';
    protected $primaryKey = 'id';
    protected $allowedFields = ['user_id', 'lesson_id', 'course_id', 'completed_at'];
    protected $useTimestamps = true;

    public function getCompletedLessonIds(int $userId, int $courseId): array
    {
        return array_column(
            $this->where('user_id', $userId)->where('course_id', $courseId)->findAll(),
            'lesson_id'
        );
    }

    public function isLessonCompleted(int $userId, int $lessonId): bool
    {
        return $this->where('user_id', $userId)->where('lesson_id', $lessonId)->first() !== null;
    }

    public function markComplete(int $userId, int $lessonId, int $courseId): bool
    {
        if ($this->isLessonCompleted($userId, $lessonId)) return false;
        return $this->insert([
            'user_id' => $userId,
            'lesson_id' => $lessonId,
            'course_id' => $courseId,
            'completed_at' => date('Y-m-d H:i:s'),
        ]) !== false;
    }
}
