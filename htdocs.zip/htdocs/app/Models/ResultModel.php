<?php

namespace App\Models;

use CodeIgniter\Model;

class ResultModel extends Model
{
    protected $table = 'results';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'title', 'slug', 'category_id', 'exam_name', 'description', 'result_date',
        'result_link', 'pdf_file', 'total_appeared', 'total_qualified', 'cutoff_marks',
        'is_active', 'views_count'
    ];
    protected $useTimestamps = true;
    protected $useSoftDeletes = true;

    public function getLatest(int $limit = 10): array
    {
        return $this->where('is_active', 1)->orderBy('result_date', 'DESC')->findAll($limit);
    }

    public function getTotalResults(): int
    {
        return $this->where('is_active', 1)->countAllResults();
    }

    public function incrementViews(int $id): void
    {
        $this->set('views_count', 'views_count + 1', false)->where('id', $id)->update();
    }
}
