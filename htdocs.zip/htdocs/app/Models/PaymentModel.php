<?php

namespace App\Models;

use CodeIgniter\Model;

class PaymentModel extends Model
{
    protected $table = 'payments';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'user_id', 'item_type', 'item_id', 'amount', 'currency',
        'payment_status', 'transaction_id', 'phonepe_transaction_id',
        'merchant_transaction_id', 'payment_method', 'paid_at'
    ];
    protected $useTimestamps = true;

    public function hasPaid(int $userId, string $itemType, int $itemId): bool
    {
        return $this->where('user_id', $userId)
            ->where('item_type', $itemType)
            ->where('item_id', $itemId)
            ->where('payment_status', 'completed')
            ->first() !== null;
    }

    public function getPending(string $merchantTransactionId): ?array
    {
        return $this->where('merchant_transaction_id', $merchantTransactionId)
            ->where('payment_status', 'pending')
            ->first();
    }
}
