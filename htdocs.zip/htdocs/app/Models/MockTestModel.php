<?php

namespace App\Models;

use CodeIgniter\Model;

class MockTestModel extends Model
{
    protected $table = 'mock_tests';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'title', 'slug', 'description', 'category', 'duration_minutes',
        'total_questions', 'total_marks', 'passing_marks', 'instructions',
        'price', 'is_free', 'is_active', 'attempts_count'
    ];
    protected $useTimestamps = true;

    public function getActive(int $limit = 20): array
    {
        return $this->where('is_active', 1)
            ->orderBy('created_at', 'DESC')
            ->findAll($limit);
    }

    public function getBySlug(string $slug)
    {
        return $this->where('slug', $slug)->where('is_active', 1)->first();
    }

    public function incrementAttempts(int $id): void
    {
        $this->set('attempts_count', 'attempts_count + 1', false)
            ->where('id', $id)
            ->update();
    }
}
