<?php

namespace App\Models;

use CodeIgniter\Model;

class MockTestAnswerModel extends Model
{
    protected $table = 'mock_test_answers';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'attempt_id', 'question_id', 'selected_answer', 'is_correct', 'marks_obtained'
    ];
    protected $useTimestamps = false;

    public function getByAttemptId(int $attemptId): array
    {
        return $this->where('attempt_id', $attemptId)->findAll();
    }

    public function getWithQuestions(int $attemptId): array
    {
        return $this->select('mock_test_answers.*, mock_test_questions.question, mock_test_questions.options, mock_test_questions.correct_answer, mock_test_questions.marks')
            ->join('mock_test_questions', 'mock_test_questions.id = mock_test_answers.question_id')
            ->where('mock_test_answers.attempt_id', $attemptId)
            ->findAll();
    }
}
