<?php

namespace App\Models;

use CodeIgniter\Model;

class LessonQuizAttemptModel extends Model
{
    protected $table = 'lesson_quiz_attempts';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'user_id', 'lesson_id', 'course_id',
        'total_marks', 'obtained_marks', 'total_questions',
        'correct_answers', 'passed'
    ];
    protected $useTimestamps = true;

    public function getAttempt(int $userId, int $lessonId): ?array
    {
        return $this->where('user_id', $userId)->where('lesson_id', $lessonId)->first();
    }

    public function hasAttempted(int $userId, int $lessonId): bool
    {
        return $this->getAttempt($userId, $lessonId) !== null;
    }
}
