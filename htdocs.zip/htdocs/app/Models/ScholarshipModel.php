<?php

namespace App\Models;

use CodeIgniter\Model;

class ScholarshipModel extends Model
{
    protected $table = 'scholarships';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'name', 'slug', 'category_id', 'type', 'provider_name', 'description',
        'eligibility', 'benefits', 'amount', 'amount_text', 'application_fee',
        'apply_link', 'last_date_to_apply', 'exam_date',
        'is_featured', 'is_active', 'views_count'
    ];
    protected $useTimestamps = true;
    protected $useSoftDeletes = true;

    public function getLatest(int $limit = 10): array
    {
        return $this->where('is_active', 1)->orderBy('created_at', 'DESC')->findAll($limit);
    }

    public function getFeatured(int $limit = 6): array
    {
        return $this->where('is_featured', 1)->where('is_active', 1)->findAll($limit);
    }

    public function getByType(string $type, int $limit = 10): array
    {
        return $this->where('type', $type)->where('is_active', 1)->orderBy('created_at', 'DESC')->findAll($limit);
    }

    public function getTotalScholarships(): int
    {
        return $this->where('is_active', 1)->countAllResults();
    }

    public function incrementViews(int $id): void
    {
        $this->set('views_count', 'views_count + 1', false)->where('id', $id)->update();
    }
}
