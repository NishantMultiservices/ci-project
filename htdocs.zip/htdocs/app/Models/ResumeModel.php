<?php

namespace App\Models;

use CodeIgniter\Model;

class ResumeModel extends Model
{
    protected $table = 'resumes';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'user_id', 'title', 'template', 'full_name', 'email', 'phone', 'address',
        'linkedin', 'portfolio', 'summary', 'education', 'experience', 'projects',
        'skills', 'certifications', 'languages', 'is_primary'
    ];
    protected $useTimestamps = true;
    protected $useSoftDeletes = true;
    protected array $casts = [
        'education' => 'json',
        'experience' => 'json',
        'projects' => 'json',
        'skills' => 'json',
        'certifications' => 'json',
        'languages' => 'json',
    ];

    public function getUserResumes(int $userId): array
    {
        return $this->where('user_id', $userId)->orderBy('is_primary', 'DESC')->findAll();
    }

    public function getPrimary(int $userId): ?array
    {
        return $this->where('user_id', $userId)->where('is_primary', 1)->first();
    }
}
