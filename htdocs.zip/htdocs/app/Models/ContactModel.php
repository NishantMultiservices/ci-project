<?php

namespace App\Models;

use CodeIgniter\Model;

class ContactModel extends Model
{
    protected $table = 'contact_messages';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name', 'email', 'phone', 'subject', 'message', 'is_read', 'replied_at'];
    protected $useTimestamps = false;

    public function getUnreadCount(): int
    {
        return $this->where('is_read', 0)->countAllResults();
    }

    public function markAsRead(int $id): void
    {
        $this->update($id, ['is_read' => 1]);
    }
}
