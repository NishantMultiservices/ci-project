<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'name', 'email', 'phone', 'password', 'google_id', 'avatar', 'role',
        'is_active', 'email_verified_at', 'phone_verified_at', 'otp', 'otp_expires_at',
        'remember_token', 'reset_token', 'reset_token_expires_at', 'last_login_at'
    ];
    protected $useTimestamps = true;
    protected $useSoftDeletes = true;
    protected $beforeInsert = ['hashPassword'];
    protected $beforeUpdate = ['hashPassword'];

    protected function hashPassword(array $data): array
    {
        if (isset($data['data']['password']) && !empty($data['data']['password'])) {
            $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);
        }
        return $data;
    }

    public function verifyPassword(string $password, string $hash): bool
    {
        return password_verify($password, $hash);
    }

    public function getByEmail(string $email): ?array
    {
        return $this->where('email', $email)->first();
    }

    public function getByGoogleId(string $googleId): ?array
    {
        return $this->where('google_id', $googleId)->first();
    }

    public function updateLastLogin(int $userId): void
    {
        $this->update($userId, ['last_login_at' => date('Y-m-d H:i:s')]);
    }

    public function getTotalUsers(): int
    {
        return $this->countAllResults();
    }

    public function getRecentUsers(int $limit = 10): array
    {
        return $this->orderBy('created_at', 'DESC')->findAll($limit);
    }
}
