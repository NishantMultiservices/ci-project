<?php

namespace App\Models;

use CodeIgniter\Model;

class LessonQuizQuestionModel extends Model
{
    protected $table = 'lesson_quiz_questions';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'lesson_id', 'course_id', 'question',
        'option_a', 'option_b', 'option_c', 'option_d',
        'correct_option', 'marks', 'sort_order'
    ];
    protected $useTimestamps = true;

    public function getLessonQuestions(int $lessonId): array
    {
        return $this->where('lesson_id', $lessonId)
            ->orderBy('sort_order', 'ASC')
            ->orderBy('id', 'ASC')
            ->findAll();
    }
}
