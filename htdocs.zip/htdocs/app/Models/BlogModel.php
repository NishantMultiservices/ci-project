<?php

namespace App\Models;

use CodeIgniter\Model;

class BlogModel extends Model
{
    protected $table = 'blogs';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'title', 'slug', 'category_id', 'excerpt', 'content', 'featured_image',
        'author_name', 'author_avatar', 'tags', 'meta_title', 'meta_description',
        'is_published', 'is_featured', 'views_count', 'published_at'
    ];
    protected $useTimestamps = true;
    protected $useSoftDeletes = true;

    public function getPublished(int $limit = 10): array
    {
        return $this->where('is_published', 1)
            ->orderBy('published_at', 'DESC')
            ->findAll($limit);
    }

    public function getFeatured(int $limit = 3): array
    {
        return $this->where('is_featured', 1)->where('is_published', 1)
            ->orderBy('published_at', 'DESC')->findAll($limit);
    }

    public function getBySlug(string $slug): ?array
    {
        return $this->where('slug', $slug)->where('is_published', 1)->first();
    }

    public function getRelated(int $blogId, int $categoryId, int $limit = 3): array
    {
        return $this->where('category_id', $categoryId)
            ->where('id !=', $blogId)
            ->where('is_published', 1)
            ->orderBy('published_at', 'DESC')
            ->findAll($limit);
    }

    public function getTotalBlogs(): int
    {
        return $this->where('is_published', 1)->countAllResults();
    }

    public function incrementViews(int $id): void
    {
        $this->set('views_count', 'views_count + 1', false)->where('id', $id)->update();
    }
}
