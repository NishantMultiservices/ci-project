<?php

namespace App\Models;

use CodeIgniter\Model;

class JobModel extends Model
{
    protected $table = 'jobs';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'title', 'slug', 'company_name', 'company_logo', 'category_id',
        'job_type', 'employment_type', 'location', 'state', 'salary_min', 'salary_max', 'salary_text',
        'experience_min', 'experience_max', 'qualification_required', 'department',
        'total_vacancies', 'description', 'responsibilities', 'requirements', 'benefits',
        'apply_link', 'apply_instructions', 'last_date_to_apply', 'exam_date', 'result_date',
        'is_featured', 'is_trending', 'is_active', 'views_count'
    ];
    protected $useTimestamps = true;
    protected $useSoftDeletes = true;

    public function getLatest(int $limit = 10): array
    {
        return $this->where('is_active', 1)
            ->where('last_date_to_apply >=', date('Y-m-d'))
            ->orWhere('last_date_to_apply IS NULL')
            ->orderBy('created_at', 'DESC')
            ->findAll($limit);
    }

    public function getGovernment(int $limit = 10): array
    {
        return $this->where('job_type', 'government')
            ->where('is_active', 1)
            ->orderBy('created_at', 'DESC')
            ->findAll($limit);
    }

    public function getPrivate(int $limit = 10): array
    {
        return $this->where('job_type', 'private')
            ->where('is_active', 1)
            ->orderBy('created_at', 'DESC')
            ->findAll($limit);
    }

    public function getFeatured(int $limit = 6): array
    {
        return $this->where('is_featured', 1)
            ->where('is_active', 1)
            ->orderBy('created_at', 'DESC')
            ->findAll($limit);
    }

    public function getTrending(int $limit = 6): array
    {
        return $this->where('is_trending', 1)
            ->where('is_active', 1)
            ->orderBy('views_count', 'DESC')
            ->findAll($limit);
    }

    public function search(array $filters = [], int $perPage = 12): array
    {
        $builder = $this->where('is_active', 1);

        if (!empty($filters['keyword'])) {
            $builder->groupStart()
                ->like('title', $filters['keyword'])
                ->orLike('company_name', $filters['keyword'])
                ->orLike('description', $filters['keyword'])
                ->orLike('location', $filters['keyword'])
                ->groupEnd();
        }
        if (!empty($filters['state'])) $builder->where('state', $filters['state']);
        if (!empty($filters['category'])) $builder->where('category_id', $filters['category']);
        if (!empty($filters['job_type'])) $builder->where('job_type', $filters['job_type']);
        if (!empty($filters['experience'])) {
            $exp = explode('-', $filters['experience']);
            if (count($exp) === 2) {
                $builder->where('experience_min >=', (int)$exp[0])
                    ->where('experience_max <=', (int)$exp[1]);
            }
        }
        if (!empty($filters['salary_min'])) $builder->where('salary_min >=', $filters['salary_min']);
        if (!empty($filters['department'])) $builder->like('department', $filters['department']);
        if (!empty($filters['qualification'])) $builder->like('qualification_required', $filters['qualification']);

        return $builder->orderBy('created_at', 'DESC')->paginate($perPage);
    }

    public function getByCategory(string $categorySlug, int $limit = 10): array
    {
        $builder = $this->select('jobs.*')
            ->join('categories', 'categories.id = jobs.category_id')
            ->where('categories.slug', $categorySlug)
            ->where('jobs.is_active', 1)
            ->orderBy('jobs.created_at', 'DESC');
        return $builder->findAll($limit);
    }

    public function getRelated(int $jobId, string $categoryId, int $limit = 4): array
    {
        return $this->where('category_id', $categoryId)
            ->where('id !=', $jobId)
            ->where('is_active', 1)
            ->orderBy('created_at', 'DESC')
            ->findAll($limit);
    }

    public function incrementViews(int $id): void
    {
        $this->set('views_count', 'views_count + 1', false)
            ->where('id', $id)
            ->update();
    }

    public function getTotalJobs(): int
    {
        return $this->where('is_active', 1)->countAllResults();
    }

    public function getTotalGovtJobs(): int
    {
        return $this->where('job_type', 'government')->where('is_active', 1)->countAllResults();
    }

    public function getTotalPrivateJobs(): int
    {
        return $this->where('job_type', 'private')->where('is_active', 1)->countAllResults();
    }
}
