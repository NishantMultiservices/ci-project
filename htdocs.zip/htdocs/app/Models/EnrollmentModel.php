<?php

namespace App\Models;

use CodeIgniter\Model;

class EnrollmentModel extends Model
{
    protected $table = 'enrollments';
    protected $primaryKey = 'id';
    protected $allowedFields = ['user_id', 'course_id', 'status', 'enrolled_at', 'completed_at'];
    protected $useTimestamps = true;

    public function getUserEnrollments(int $userId): array
    {
        return $this->select('enrollments.*, courses.title as course_title, courses.thumbnail, courses.instructor_name, courses.duration, courses.total_lessons, courses.total_enrolled')
            ->join('courses', 'courses.id = enrollments.course_id')
            ->where('enrollments.user_id', $userId)
            ->orderBy('enrollments.created_at', 'DESC')
            ->findAll();
    }

    public function isEnrolled(int $userId, int $courseId): bool
    {
        return $this->where('user_id', $userId)
            ->where('course_id', $courseId)
            ->where('status', 'active')
            ->first() !== null;
    }

    public function enroll(int $userId, int $courseId): bool
    {
        if ($this->isEnrolled($userId, $courseId)) return false;
        return $this->insert([
            'user_id' => $userId,
            'course_id' => $courseId,
            'status' => 'active',
            'enrolled_at' => date('Y-m-d H:i:s'),
        ]) !== false;
    }

    public function getTotalEnrollments(): int
    {
        return $this->countAllResults();
    }
}
