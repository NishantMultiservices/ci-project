<section class="section" style="padding-top:120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Contact Us']]]) ?>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:48px; max-width:1000px; margin:0 auto;">
            <div>
                <div class="section-header" style="text-align:left; margin:0 0 32px;">
                    <span class="section-label">Get in Touch</span>
                    <h1 class="section-title" style="font-size:2rem;">Contact <span class="gradient-text">Us</span></h1>
                    <p class="section-desc">Have questions? We'd love to hear from you. Send us a message and we'll respond as soon as possible.</p>
                </div>
                <div style="display:flex; flex-direction:column; gap:16px;">
                    <div class="glass" style="display:flex; align-items:center; gap:16px; padding:20px; border-radius:12px;"><i class="fas fa-envelope" style="font-size:1.25rem; color:var(--primary);"></i><div><strong>Email</strong><p style="font-size:0.875rem; color:var(--gray-500);">info@rojgarsandhi.in</p></div></div>
                    <div class="glass" style="display:flex; align-items:center; gap:16px; padding:20px; border-radius:12px;"><i class="fas fa-phone" style="font-size:1.25rem; color:var(--primary);"></i><div><strong>Phone</strong><p style="font-size:0.875rem; color:var(--gray-500);">+91-1800-123-4567</p></div></div>
                    <div class="glass" style="display:flex; align-items:center; gap:16px; padding:20px; border-radius:12px;"><i class="fas fa-map-marker-alt" style="font-size:1.25rem; color:var(--primary);"></i><div><strong>Address</strong><p style="font-size:0.875rem; color:var(--gray-500);">New Delhi, India</p></div></div>
                </div>
            </div>
            <div>
                <form action="<?= base_url('contact/send') ?>" method="post" class="glass-card" style="padding:32px;">
                    <?= csrf_field() ?>
                    <div class="form-group"><label class="form-label">Your Name</label><input type="text" name="name" class="form-input" placeholder="John Doe" required></div>
                    <div class="form-group"><label class="form-label">Email Address</label><input type="email" name="email" class="form-input" placeholder="john@example.com" required></div>
                    <div class="form-group"><label class="form-label">Phone (Optional)</label><input type="tel" name="phone" class="form-input" placeholder="9876543210"></div>
                    <div class="form-group"><label class="form-label">Subject</label><input type="text" name="subject" class="form-input" placeholder="How can we help?" required></div>
                    <div class="form-group"><label class="form-label">Message</label><textarea name="message" class="form-textarea" placeholder="Write your message here..." required></textarea></div>
                    <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-paper-plane"></i> Send Message</button>
                </form>
            </div>
        </div>
        <style>@media(max-width:768px){[style*="grid-template-columns: 1fr 1fr"]{grid-template-columns:1fr!important;}}</style>
    </div>
</section>
