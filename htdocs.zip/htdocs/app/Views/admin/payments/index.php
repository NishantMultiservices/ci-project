<h2 style="font-size:1.25rem; font-weight:700; margin-bottom:24px;">Payment Transactions</h2>
<div class="glass-card" style="overflow:hidden;">
    <table class="admin-table">
        <thead><tr><th>ID</th><th>User</th><th>Item</th><th>Amount</th><th>Status</th><th>Transaction ID</th><th>Date</th></tr></thead>
        <tbody>
            <?php if (!empty($payments)): ?>
            <?php foreach ($payments as $p): ?>
            <?php
                $user = model('App\Models\UserModel')->find($p['user_id']);
                $itemName = '';
                if ($p['item_type'] === 'course') {
                    $c = model('App\Models\CourseModel')->find($p['item_id']);
                    $itemName = $c['title'] ?? 'Course #' . $p['item_id'];
                } else {
                    $m = model('App\Models\MockTestModel')->find($p['item_id']);
                    $itemName = $m['title'] ?? 'Test #' . $p['item_id'];
                }
            ?>
            <tr>
                <td><?= $p['id'] ?></td>
                <td><?= esc($user['name'] ?? 'User #' . $p['user_id']) ?></td>
                <td><span class="badge badge-info"><?= ucfirst($p['item_type']) ?></span> <?= esc($itemName) ?></td>
                <td>₹<?= number_format($p['amount']) ?></td>
                <td><span class="badge badge-<?= $p['payment_status'] === 'completed' ? 'success' : ($p['payment_status'] === 'pending' ? 'warning' : 'danger') ?>"><?= ucfirst($p['payment_status']) ?></span></td>
                <td style="font-size:0.75rem;"><?= esc($p['merchant_transaction_id'] ?? '—') ?></td>
                <td><?= date('d M Y', strtotime($p['created_at'])) ?></td>
            </tr>
            <?php endforeach; ?>
            <?php else: ?>
            <tr><td colspan="7" style="text-align:center; padding:40px; color:var(--gray-400);">No payments yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php if (isset($pager)): ?><div style="margin-top:20px;"><?= $pager->links('default', 'default') ?></div><?php endif; ?>
