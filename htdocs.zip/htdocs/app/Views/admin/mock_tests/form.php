<div style="margin-bottom:24px;"><a href="<?= base_url('admin/mock-tests') ?>" style="color:var(--primary); text-decoration:none; font-size:0.875rem;"><i class="fas fa-arrow-left"></i> Back to Mock Tests</a></div>
<h2 style="font-size:1.25rem; font-weight:700; margin-bottom:24px;"><?= isset($test) ? 'Edit Mock Test' : 'Add Mock Test' ?></h2>
<div class="glass-card" style="padding:32px;">
    <form action="<?= base_url('admin/mock-tests/' . (isset($test) ? 'update/' . $test['id'] : 'store')) ?>" method="post">
        <?= csrf_field() ?>
        <div class="grid-2"><div class="form-group"><label class="form-label">Test Title</label><input type="text" name="title" class="form-input" value="<?= esc($test['title'] ?? '') ?>" required></div>
        <div class="form-group"><label class="form-label">Category</label><input type="text" name="category" class="form-input" value="<?= esc($test['category'] ?? '') ?>" placeholder="e.g. UPSC, SSC, Banking"></div></div>
        <div class="grid-2"><div class="form-group"><label class="form-label">Duration (minutes)</label><input type="number" name="duration_minutes" class="form-input" value="<?= $test['duration_minutes'] ?? 30 ?>" required></div>
        <div class="form-group"></div></div>
        <div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-textarea" rows="4"><?= $test['description'] ?? '' ?></textarea></div>
        <div class="form-group"><label class="form-label">Instructions</label><textarea name="instructions" class="form-textarea" rows="5" placeholder="Test instructions for candidates..."><?= $test['instructions'] ?? '' ?></textarea></div>
        <div class="grid-3"><div class="form-group"><label class="form-label">Price (₹)</label><input type="number" name="price" class="form-input" step="0.01" value="<?= $test['price'] ?? 0 ?>"></div>
        <div class="form-group"><label style="display:flex; align-items:center; gap:8px; margin-top:24px;"><input type="checkbox" name="is_free" value="1" <?= isset($test) && $test['is_free'] ? 'checked' : '' ?>> Free Test</label></div>
        <div class="form-group"><label style="display:flex; align-items:center; gap:8px; margin-top:24px;"><input type="checkbox" name="is_active" value="1" <?= !isset($test) || $test['is_active'] ? 'checked' : '' ?>> Active</label></div></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <?= isset($test) ? 'Update' : 'Create' ?> Mock Test</button>
    </form>
</div>