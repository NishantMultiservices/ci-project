<div style="margin-bottom:24px;">
    <a href="<?= base_url('admin/mock-tests') ?>" style="color:var(--primary); text-decoration:none; font-size:0.875rem;"><i class="fas fa-arrow-left"></i> Back to Mock Tests</a>
    <span style="margin:0 8px; color:var(--gray-400);">|</span>
    <a href="<?= base_url('admin/mock-tests/edit/' . $test['id']) ?>" style="color:var(--primary); text-decoration:none; font-size:0.875rem;"><i class="fas fa-edit"></i> Edit Test Info</a>
</div>
<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:24px; flex-wrap:wrap; gap:12px;">
    <h2 style="font-size:1.25rem; font-weight:700;">Questions - <?= esc($test['title']) ?></h2>
    <button type="button" onclick="addQuestion()" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add Question</button>
</div>
<div class="glass-card" style="padding:24px;">
    <form action="<?= base_url('admin/mock-tests/questions/store/' . $test['id']) ?>" method="post">
        <?= csrf_field() ?>
        <div id="questions-container">
            <?php if (!empty($questions)): ?>
            <?php foreach ($questions as $i => $q): ?>
            <?php $opts = is_string($q['options']) ? json_decode($q['options'], true) : $q['options']; ?>
            <div class="question-row" style="padding:20px; margin-bottom:16px; border:1px solid var(--gray-200); border-radius:12px; background:var(--gray-50);">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                    <strong>Question #<?= $i + 1 ?></strong>
                    <button type="button" onclick="this.closest('.question-row').remove()" style="background:none; border:none; color:#ef4444; cursor:pointer;"><i class="fas fa-times"></i> Remove</button>
                </div>
                <div class="form-group"><textarea name="questions[<?= $i ?>][question]" class="form-textarea" rows="2" placeholder="Enter question"><?= esc($q['question']) ?></textarea></div>
                <div class="grid-2">
                    <?php for ($o = 1; $o <= 4; $o++): ?>
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Option <?= $o ?></label>
                        <div style="display:flex; align-items:center; gap:8px;">
                            <input type="radio" name="questions[<?= $i ?>][correct_answer]" value="option_<?= $o ?>" <?= $q['correct_answer'] === 'option_' . $o ? 'checked' : '' ?> required>
                            <input type="text" name="questions[<?= $i ?>][option_<?= $o ?>]" class="form-input" value="<?= esc($opts['option_' . $o] ?? '') ?>" placeholder="Option <?= $o ?>">
                        </div>
                    </div>
                    <?php endfor; ?>
                </div>
                <div class="grid-2">
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Marks</label><input type="number" step="0.01" name="questions[<?= $i ?>][marks]" class="form-input" value="<?= $q['marks'] ?? 1 ?>"></div>
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Negative Marks</label><input type="number" step="0.01" name="questions[<?= $i ?>][negative_marks]" class="form-input" value="<?= $q['negative_marks'] ?? 0 ?>"></div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-primary" style="margin-top:16px;"><i class="fas fa-save"></i> Save All Questions</button>
    </form>
</div>
<script>
var qIdx = <?= count($questions) ?>;
function addQuestion() {
    var container = document.getElementById('questions-container');
    var i = qIdx++;
    var div = document.createElement('div');
    div.className = 'question-row';
    div.style.cssText = 'padding:20px; margin-bottom:16px; border:1px solid var(--gray-200); border-radius:12px; background:var(--gray-50);';
    div.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
            <strong>Question #${i + 1}</strong>
            <button type="button" onclick="this.closest('.question-row').remove()" style="background:none; border:none; color:#ef4444; cursor:pointer;"><i class="fas fa-times"></i> Remove</button>
        </div>
        <div class="form-group"><textarea name="questions[${i}][question]" class="form-textarea" rows="2" placeholder="Enter question"></textarea></div>
        <div class="grid-2">
            ${[1,2,3,4].map(function(o) { return '<div class="form-group"><label class="form-label" style="font-size:0.75rem;">Option ' + o + '</label><div style="display:flex; align-items:center; gap:8px;"><input type="radio" name="questions[' + i + '][correct_answer]" value="option_' + o + '" required><input type="text" name="questions[' + i + '][option_' + o + ']" class="form-input" placeholder="Option ' + o + '"></div></div>'; }).join('')}
        </div>
        <div class="grid-2">
            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Marks</label><input type="number" step="0.01" name="questions[${i}][marks]" class="form-input" value="1"></div>
            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Negative Marks</label><input type="number" step="0.01" name="questions[${i}][negative_marks]" class="form-input" value="0"></div>
        </div>
    `;
    container.appendChild(div);
}
</script>