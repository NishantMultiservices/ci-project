<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:24px; flex-wrap:wrap; gap:12px;">
    <h2 style="font-size:1.25rem; font-weight:700;">Manage Mock Tests</h2>
    <a href="<?= base_url('admin/mock-tests/create') ?>" class="btn btn-primary"><i class="fas fa-plus"></i> Add Mock Test</a>
</div>
<div class="glass-card" style="overflow:hidden;">
    <table class="admin-table">
        <thead><tr><th>Title</th><th>Price</th><th>Questions</th><th>Duration</th><th>Attempts</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
            <?php foreach ($mockTests as $t): ?>
            <tr>
                <td><a href="<?= base_url('mock-tests/' . $t['slug']) ?>" style="color:var(--primary); text-decoration:none; font-weight:500;"><?= esc($t['title']) ?></a></td>
                <td><?= $t['is_free'] ? '<span class="badge badge-success">Free</span>' : '₹' . number_format($t['price'] ?? 0) ?></td>
                <td><?= $t['total_questions'] ?></td>
                <td><?= $t['duration_minutes'] ?> min</td>
                <td><?= $t['attempts_count'] ?? 0 ?></td>
                <td><span class="badge badge-<?= $t['is_active'] ? 'success' : 'secondary' ?>"><?= $t['is_active'] ? 'Active' : 'Inactive' ?></span></td>
                <td>
                    <a href="<?= base_url('admin/mock-tests/questions/' . $t['id']) ?>" class="btn btn-secondary btn-sm" title="Questions"><i class="fas fa-list"></i></a>
                    <a href="<?= base_url('admin/mock-tests/edit/' . $t['id']) ?>" class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></a>
                    <a href="<?= base_url('admin/mock-tests/delete/' . $t['id']) ?>" class="btn btn-secondary btn-sm" onclick="return confirm('Delete this mock test?')" style="color:#ef4444;"><i class="fas fa-trash"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>