<div style="margin-bottom:24px;"><a href="<?= base_url('admin/apprenticeships') ?>" style="color:var(--primary); text-decoration:none; font-size:0.875rem;"><i class="fas fa-arrow-left"></i> Back</a></div>
<h2 style="font-size:1.25rem; font-weight:700; margin-bottom:24px;"><?= isset($apprenticeship) ? 'Edit' : 'Add' ?> Apprenticeship</h2>
<div class="glass-card" style="padding:32px;">
<form action="<?= base_url('admin/apprenticeships/' . (isset($apprenticeship) ? 'update/' . $apprenticeship['id'] : 'store')) ?>" method="post">
<?= csrf_field() ?>
<div class="grid-2"><div class="form-group"><label class="form-label">Title</label><input type="text" name="title" class="form-input" value="<?= esc($apprenticeship['title'] ?? '') ?>" required></div>
<div class="form-group"><label class="form-label">Company Name</label><input type="text" name="company_name" class="form-input" value="<?= esc($apprenticeship['company_name'] ?? '') ?>" required></div></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Trade</label><input type="text" name="trade" class="form-input" value="<?= esc($apprenticeship['trade'] ?? '') ?>"></div>
<div class="form-group"><label class="form-label">Type</label><select name="type" class="form-select"><option value="full-time" <?= (isset($apprenticeship) && $apprenticeship['type'] === 'full-time') ? 'selected' : '' ?>>Full Time</option><option value="part-time" <?= (isset($apprenticeship) && $apprenticeship['type'] === 'part-time') ? 'selected' : '' ?>>Part Time</option></select></div></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Location</label><input type="text" name="location" class="form-input" value="<?= esc($apprenticeship['location'] ?? '') ?>"></div>
<div class="form-group"><label class="form-label">State</label><input type="text" name="state" class="form-input" value="<?= esc($apprenticeship['state'] ?? '') ?>"></div></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Stipend</label><input type="number" name="stipend" class="form-input" value="<?= $apprenticeship['stipend'] ?? '' ?>"></div>
<div class="form-group"><label class="form-label">Duration</label><input type="text" name="duration" class="form-input" value="<?= esc($apprenticeship['duration'] ?? '') ?>"></div></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Qualification Required</label><input type="text" name="qualification_required" class="form-input" value="<?= esc($apprenticeship['qualification_required'] ?? '') ?>"></div>
<div class="form-group"><label class="form-label">Last Date</label><input type="date" name="last_date_to_apply" class="form-input" value="<?= $apprenticeship['last_date_to_apply'] ?? '' ?>"></div></div>
<div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-textarea" rows="5"><?= $apprenticeship['description'] ?? '' ?></textarea></div>
<div class="form-group"><label class="form-label">Requirements</label><textarea name="requirements" class="form-textarea" rows="4"><?= $apprenticeship['requirements'] ?? '' ?></textarea></div>
<div class="form-group"><label class="form-label">Apply Link</label><input type="url" name="apply_link" class="form-input" value="<?= esc($apprenticeship['apply_link'] ?? '') ?>"></div>
<div class="form-group" style="display:flex; gap:20px;"><label style="display:flex; align-items:center; gap:8px;"><input type="checkbox" name="is_featured" value="1" <?= isset($apprenticeship) && $apprenticeship['is_featured'] ? 'checked' : '' ?>> Featured</label><label style="display:flex; align-items:center; gap:8px;"><input type="checkbox" name="is_active" value="1" <?= !isset($apprenticeship) || $apprenticeship['is_active'] ? 'checked' : '' ?>> Active</label></div>
<button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <?= isset($apprenticeship) ? 'Update' : 'Create' ?></button>
</form>
</div>
