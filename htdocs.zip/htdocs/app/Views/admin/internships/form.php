<div style="margin-bottom:24px;"><a href="<?= base_url('admin/internships') ?>" style="color:var(--primary); text-decoration:none; font-size:0.875rem;"><i class="fas fa-arrow-left"></i> Back to Internships</a></div>
<h2 style="font-size:1.25rem; font-weight:700; margin-bottom:24px;"><?= isset($internship) ? 'Edit Internship' : 'Add Internship' ?></h2>
<div class="glass-card" style="padding:32px;">
<form action="<?= base_url('admin/internships/' . (isset($internship) ? 'update/' . $internship['id'] : 'store')) ?>" method="post">
<?= csrf_field() ?>
<div class="grid-2"><div class="form-group"><label class="form-label">Title</label><input type="text" name="title" class="form-input" value="<?= esc($internship['title'] ?? '') ?>" required></div>
<div class="form-group"><label class="form-label">Company Name</label><input type="text" name="company_name" class="form-input" value="<?= esc($internship['company_name'] ?? '') ?>" required></div></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Type</label><select name="type" class="form-select"><option value="full-time" <?= (isset($internship) && $internship['type'] === 'full-time') ? 'selected' : '' ?>>Full Time</option><option value="part-time" <?= (isset($internship) && $internship['type'] === 'part-time') ? 'selected' : '' ?>>Part Time</option><option value="work-from-home" <?= (isset($internship) && $internship['type'] === 'work-from-home') ? 'selected' : '' ?>>Work From Home</option></select></div>
<div class="form-group"><label class="form-label">Category</label><select name="category_id" class="form-select"><option value="">Select</option><?php foreach ($categories ?? [] as $c): ?><option value="<?= $c['id'] ?>" <?= (isset($internship) && ($internship['category_id'] ?? '') == $c['id']) ? 'selected' : '' ?>><?= esc($c['name']) ?></option><?php endforeach; ?></select></div></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Location</label><input type="text" name="location" class="form-input" value="<?= esc($internship['location'] ?? '') ?>"></div>
<div class="form-group"><label class="form-label">State</label><input type="text" name="state" class="form-input" value="<?= esc($internship['state'] ?? '') ?>"></div></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Stipend Min</label><input type="number" name="stipend_min" class="form-input" value="<?= $internship['stipend_min'] ?? '' ?>"></div>
<div class="form-group"><label class="form-label">Stipend Max</label><input type="number" name="stipend_max" class="form-input" value="<?= $internship['stipend_max'] ?? '' ?>"></div></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Duration</label><input type="text" name="duration" class="form-input" value="<?= esc($internship['duration'] ?? '') ?>" placeholder="e.g. 3 months"></div>
<div class="form-group"><label class="form-label">Duration Months</label><input type="number" name="duration_months" class="form-input" value="<?= $internship['duration_months'] ?? '' ?>"></div></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Qualification Required</label><input type="text" name="qualification_required" class="form-input" value="<?= esc($internship['qualification_required'] ?? '') ?>"></div>
<div class="form-group"><label class="form-label">Positions Available</label><input type="number" name="positions_available" class="form-input" value="<?= $internship['positions_available'] ?? '' ?>"></div></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Skills Required</label><input type="text" name="skills_required" class="form-input" value="<?= esc($internship['skills_required'] ?? '') ?>"></div>
<div class="form-group"><label class="form-label">Last Date to Apply</label><input type="date" name="last_date_to_apply" class="form-input" value="<?= $internship['last_date_to_apply'] ?? '' ?>"></div></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Start Date</label><input type="date" name="start_date" class="form-input" value="<?= $internship['start_date'] ?? '' ?>"></div>
<div class="form-group"><label class="form-label">Apply Link</label><input type="url" name="apply_link" class="form-input" value="<?= esc($internship['apply_link'] ?? '') ?>"></div></div>
<div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-textarea" rows="5"><?= $internship['description'] ?? '' ?></textarea></div>
<div class="form-group"><label class="form-label">Responsibilities</label><textarea name="responsibilities" class="form-textarea" rows="4"><?= $internship['responsibilities'] ?? '' ?></textarea></div>
<div class="form-group"><label class="form-label">Perks</label><input type="text" name="perks" class="form-input" value="<?= esc($internship['perks'] ?? '') ?>"></div>
<div class="form-group" style="display:flex; gap:20px;"><label style="display:flex; align-items:center; gap:8px;"><input type="checkbox" name="is_featured" value="1" <?= isset($internship) && $internship['is_featured'] ? 'checked' : '' ?>> Featured</label><label style="display:flex; align-items:center; gap:8px;"><input type="checkbox" name="is_active" value="1" <?= !isset($internship) || $internship['is_active'] ? 'checked' : '' ?>> Active</label></div>
<button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <?= isset($internship) ? 'Update' : 'Create' ?></button>
</form>
</div>
