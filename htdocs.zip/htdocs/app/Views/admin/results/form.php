<div style="margin-bottom:24px;"><a href="<?= base_url('admin/results') ?>" style="color:var(--primary); text-decoration:none; font-size:0.875rem;"><i class="fas fa-arrow-left"></i> Back</a></div>
<h2 style="font-size:1.25rem; font-weight:700; margin-bottom:24px;"><?= isset($result) ? 'Edit' : 'Add' ?> Result</h2>
<div class="glass-card" style="padding:32px;">
<form action="<?= base_url('admin/results/' . (isset($result) ? 'update/' . $result['id'] : 'store')) ?>" method="post">
<?= csrf_field() ?>
<div class="grid-2"><div class="form-group"><label class="form-label">Title</label><input type="text" name="title" class="form-input" value="<?= esc($result['title'] ?? '') ?>" required></div>
<div class="form-group"><label class="form-label">Exam Name</label><input type="text" name="exam_name" class="form-input" value="<?= esc($result['exam_name'] ?? '') ?>"></div></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Result Date</label><input type="date" name="result_date" class="form-input" value="<?= $result['result_date'] ?? '' ?>"></div>
<div class="form-group"><label class="form-label">Result Link</label><input type="url" name="result_link" class="form-input" value="<?= esc($result['result_link'] ?? '') ?>"></div></div>
<div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-textarea" rows="5"><?= $result['description'] ?? '' ?></textarea></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Total Appeared</label><input type="number" name="total_appeared" class="form-input" value="<?= $result['total_appeared'] ?? '' ?>"></div>
<div class="form-group"><label class="form-label">Total Qualified</label><input type="number" name="total_qualified" class="form-input" value="<?= $result['total_qualified'] ?? '' ?>"></div></div>
<div class="form-group"><label class="form-label">Cutoff Marks</label><input type="text" name="cutoff_marks" class="form-input" value="<?= esc($result['cutoff_marks'] ?? '') ?>"></div>
<div class="form-group" style="display:flex; gap:20px;"><label style="display:flex; align-items:center; gap:8px;"><input type="checkbox" name="is_active" value="1" <?= !isset($result) || $result['is_active'] ? 'checked' : '' ?>> Active</label></div>
<button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <?= isset($result) ? 'Update' : 'Create' ?></button>
</form>
</div>
