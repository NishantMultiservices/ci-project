<h2 style="font-size:1.25rem; font-weight:700; margin-bottom:24px;">Analytics</h2>
<div class="glass-card" style="padding:32px; text-align:center;"><i class="fas fa-chart-line" style="font-size:3rem; color:var(--gray-300); margin-bottom:16px; display:block;"></i><p style="color:var(--gray-500);">Analytics dashboard coming soon. Track page views, user growth, and job applications.</p></div>
