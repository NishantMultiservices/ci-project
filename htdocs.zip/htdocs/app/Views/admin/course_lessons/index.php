<div style="margin-bottom:24px;">
    <a href="<?= base_url('admin/courses') ?>" style="color:var(--primary); text-decoration:none; font-size:0.875rem;"><i class="fas fa-arrow-left"></i> Back to Courses</a>
</div>
<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:24px; flex-wrap:wrap; gap:12px;">
    <h2 style="font-size:1.25rem; font-weight:700;">Lessons - <?= esc($course['title']) ?></h2>
    <a href="<?= base_url('admin/course-lessons/' . $course['id'] . '/create') ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add Lesson</a>
</div>
<?php if (!empty($lessons)): ?>
<div class="glass-card" style="overflow:hidden;">
    <form action="<?= base_url('admin/course-lessons/reorder/' . $course['id']) ?>" method="post" id="reorder-form">
        <?= csrf_field() ?>
        <table class="admin-table">
            <thead><tr><th style="width:40px;">#</th><th>Title</th><th>Type</th><th>Duration</th><th>Free</th><th style="width:160px;">Actions</th></tr></thead>
            <tbody id="sortable-lessons">
                <?php foreach ($lessons as $i => $l): ?>
                <tr data-id="<?= $l['id'] ?>" style="cursor:grab;">
                    <td style="text-align:center;"><i class="fas fa-grip-vertical" style="color:var(--gray-400);"></i></td>
                    <td><?= esc($l['title']) ?></td>
                    <td><span class="badge badge-<?= $l['content_type'] === 'video' ? 'info' : ($l['content_type'] === 'text' ? 'secondary' : 'warning') ?>"><i class="fas fa-<?= $l['content_type'] === 'video' ? 'play-circle' : ($l['content_type'] === 'text' ? 'file-alt' : ($l['content_type'] === 'quiz' ? 'question-circle' : 'tasks')) ?>"></i> <?= ucfirst($l['content_type']) ?></span></td>
                    <td><?= $l['duration'] ?? '—' ?> min</td>
                    <td><?= $l['is_free_preview'] ? '<span class="badge badge-success">Yes</span>' : '<span class="badge badge-secondary">No</span>' ?></td>
                    <td style="white-space:nowrap;">
                        <?php if ($l['content_type'] === 'quiz'): ?>
                        <a href="<?= base_url('admin/lesson-quiz/' . $l['id']) ?>" class="btn btn-sm" style="background:#f59e0b; color:white; border:none; padding:4px 10px; border-radius:6px; cursor:pointer; text-decoration:none; font-size:0.688rem;"><i class="fas fa-list"></i> Questions</a>
                        <?php endif; ?>
                        <a href="<?= base_url('admin/course-lessons/' . $course['id'] . '/edit/' . $l['id']) ?>" class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></a>
                        <form action="<?= base_url('admin/course-lessons/' . $course['id'] . '/delete/' . $l['id']) ?>" method="post" style="display:inline;" onsubmit="return confirm('Delete this lesson?')"><input type="hidden" name="_method" value="DELETE"><?= csrf_field() ?><button type="submit" class="btn btn-sm" style="background:#ef4444; color:white; border:none; padding:4px 10px; border-radius:6px; cursor:pointer;"><i class="fas fa-trash"></i></button></form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <input type="hidden" name="order" id="lesson-order" value="">
    </form>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const tbody = document.getElementById('sortable-lessons');
    let dragged = null;
    tbody.querySelectorAll('tr').forEach(tr => {
        tr.draggable = true;
        tr.addEventListener('dragstart', function() { dragged = this; this.style.opacity = '0.4'; });
        tr.addEventListener('dragend', function() { this.style.opacity = '1'; });
        tr.addEventListener('dragover', function(e) { e.preventDefault(); if (dragged && dragged !== this) { const rect = this.getBoundingClientRect(); const mid = rect.top + rect.height / 2; if (e.clientY < mid) this.parentNode.insertBefore(dragged, this); else this.parentNode.insertBefore(dragged, this.nextSibling); } });
    });
    document.querySelector('table').addEventListener('dragend', function() {
        const order = [];
        document.querySelectorAll('#sortable-lessons tr').forEach(tr => order.push(tr.dataset.id));
        document.getElementById('lesson-order').value = JSON.stringify(order);
        document.getElementById('reorder-form').submit();
    });
});
</script>
<?php else: ?>
<div class="glass-card" style="padding:40px; text-align:center;">
    <i class="fas fa-list" style="font-size:2.5rem; color:var(--gray-300); margin-bottom:12px; display:block;"></i>
    <p style="color:var(--gray-500); margin-bottom:16px;">No lessons yet for this course.</p>
    <a href="<?= base_url('admin/course-lessons/' . $course['id'] . '/create') ?>" class="btn btn-primary"><i class="fas fa-plus"></i> Add First Lesson</a>
</div>
<?php endif; ?>