<div style="margin-bottom:24px;">
    <a href="<?= base_url('admin/course-lessons/' . $course['id']) ?>" style="color:var(--primary); text-decoration:none; font-size:0.875rem;"><i class="fas fa-arrow-left"></i> Back to Lessons</a>
</div>
<h2 style="font-size:1.25rem; font-weight:700; margin-bottom:24px;"><?= isset($lesson) ? 'Edit Lesson' : 'Add Lesson' ?> - <?= esc($course['title']) ?></h2>
<div class="glass-card" style="padding:32px;">
    <form action="<?= base_url('admin/course-lessons/' . $course['id'] . '/' . (isset($lesson) ? 'update/' . $lesson['id'] : 'store')) ?>" method="post">
        <?= csrf_field() ?>
        <div class="grid-2">
            <div class="form-group"><label class="form-label">Lesson Title</label><input type="text" name="title" class="form-input" value="<?= esc($lesson['title'] ?? '') ?>" required></div>
            <div class="form-group"><label class="form-label">Content Type</label><select name="content_type" class="form-select" id="content-type" required><option value="video" <?= isset($lesson) && $lesson['content_type'] === 'video' ? 'selected' : '' ?>>Video</option><option value="text" <?= isset($lesson) && $lesson['content_type'] === 'text' ? 'selected' : '' ?>>Text</option><option value="quiz" <?= isset($lesson) && $lesson['content_type'] === 'quiz' ? 'selected' : '' ?>>Quiz</option><option value="assignment" <?= isset($lesson) && $lesson['content_type'] === 'assignment' ? 'selected' : '' ?>>Assignment</option></select></div>
        </div>
        <div id="video-url-group" class="form-group"><label class="form-label">Video URL (YouTube or file path)</label><input type="url" name="video_url" class="form-input" value="<?= esc($lesson['video_url'] ?? '') ?>" placeholder="https://www.youtube.com/watch?v=..."></div>
        <div class="form-group" id="content-group"><label class="form-label">Content (HTML for text lessons)</label><textarea name="content" class="form-textarea" rows="10"><?= $lesson['content'] ?? '' ?></textarea></div>
        <div class="grid-3">
            <div class="form-group"><label class="form-label">Duration (minutes)</label><input type="number" name="duration" class="form-input" value="<?= $lesson['duration'] ?? 15 ?>"></div>
            <div class="form-group"><label class="form-label">Sort Order</label><input type="number" name="sort_order" class="form-input" value="<?= $lesson['sort_order'] ?? 0 ?>"></div>
            <div class="form-group"><label style="display:flex; align-items:center; gap:8px; margin-top:24px;"><input type="checkbox" name="is_free_preview" value="1" <?= isset($lesson) && $lesson['is_free_preview'] ? 'checked' : '' ?>> Free Preview</label></div>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <?= isset($lesson) ? 'Update' : 'Create' ?></button>
    </form>
</div>
<script>
document.getElementById('content-type').addEventListener('change', toggleFields);
toggleFields();
function toggleFields() {
    var ct = document.getElementById('content-type').value;
    document.getElementById('video-url-group').style.display = ct === 'video' ? 'block' : 'none';
    document.getElementById('content-group').style.display = ct !== 'video' ? 'block' : 'none';
}
</script>