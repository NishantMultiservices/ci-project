<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:24px;">
    <h2 style="font-size:1.25rem; font-weight:700;">Site Settings</h2>
</div>

<?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success" style="margin-bottom:20px;"><?= esc(session()->getFlashdata('success')) ?></div>
<?php endif; ?>

<form action="<?= base_url('admin/settings/update') ?>" method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>

    <div class="glass-card" style="padding:24px; margin-bottom:20px;">
        <h3 style="font-size:1.063rem; font-weight:600; margin-bottom:16px; display:flex; align-items:center; gap:8px;">
            <i class="fas fa-info-circle" style="color:var(--primary);"></i> General Settings
        </h3>
        <div class="form-grid">
            <div>
                <label class="form-label">Site Name</label>
                <input type="text" name="settings[site_name]" class="form-input" value="<?= esc($groups['general']['site_name'] ?? 'RojgarSandhi') ?>">
            </div>
            <div>
                <label class="form-label">Site Tagline</label>
                <input type="text" name="settings[site_tagline]" class="form-input" value="<?= esc($groups['general']['site_tagline'] ?? '') ?>">
            </div>
            <div>
                <label class="form-label">Site Email</label>
                <input type="email" name="settings[site_email]" class="form-input" value="<?= esc($groups['general']['site_email'] ?? '') ?>">
            </div>
            <div>
                <label class="form-label">Site Phone</label>
                <input type="text" name="settings[site_phone]" class="form-input" value="<?= esc($groups['general']['site_phone'] ?? '') ?>">
            </div>
            <div style="grid-column: span 2;">
                <label class="form-label">Site Address</label>
                <input type="text" name="settings[site_address]" class="form-input" value="<?= esc($groups['general']['site_address'] ?? '') ?>">
            </div>
            <div style="grid-column: span 2;">
                <label class="form-label">Footer Text</label>
                <input type="text" name="settings[footer_text]" class="form-input" value="<?= esc($groups['general']['footer_text'] ?? '') ?>">
            </div>
        </div>
    </div>

    <div class="glass-card" style="padding:24px; margin-bottom:20px;">
        <h3 style="font-size:1.063rem; font-weight:600; margin-bottom:16px; display:flex; align-items:center; gap:8px;">
            <i class="fas fa-share-alt" style="color:var(--primary);"></i> Social Links
        </h3>
        <div class="form-grid">
            <div>
                <label class="form-label"><i class="fab fa-facebook" style="color:#1877f2;"></i> Facebook URL</label>
                <input type="url" name="settings[facebook_url]" class="form-input" value="<?= esc($groups['social']['facebook_url'] ?? '') ?>">
            </div>
            <div>
                <label class="form-label"><i class="fab fa-twitter" style="color:#1da1f2;"></i> Twitter URL</label>
                <input type="url" name="settings[twitter_url]" class="form-input" value="<?= esc($groups['social']['twitter_url'] ?? '') ?>">
            </div>
            <div>
                <label class="form-label"><i class="fab fa-instagram" style="color:#e4405f;"></i> Instagram URL</label>
                <input type="url" name="settings[instagram_url]" class="form-input" value="<?= esc($groups['social']['instagram_url'] ?? '') ?>">
            </div>
            <div>
                <label class="form-label"><i class="fab fa-linkedin" style="color:#0a66c2;"></i> LinkedIn URL</label>
                <input type="url" name="settings[linkedin_url]" class="form-input" value="<?= esc($groups['social']['linkedin_url'] ?? '') ?>">
            </div>
            <div>
                <label class="form-label"><i class="fab fa-youtube" style="color:#ff0000;"></i> YouTube URL</label>
                <input type="url" name="settings[youtube_url]" class="form-input" value="<?= esc($groups['social']['youtube_url'] ?? '') ?>">
            </div>
            <div>
                <label class="form-label"><i class="fab fa-telegram" style="color:#0088cc;"></i> Telegram URL</label>
                <input type="url" name="settings[telegram_url]" class="form-input" value="<?= esc($groups['social']['telegram_url'] ?? '') ?>">
            </div>
            <div>
                <label class="form-label"><i class="fab fa-whatsapp" style="color:#25d366;"></i> WhatsApp Number</label>
                <input type="text" name="settings[whatsapp_number]" class="form-input" value="<?= esc($groups['social']['whatsapp_number'] ?? '') ?>">
            </div>
        </div>
    </div>

    <div class="glass-card" style="padding:24px; margin-bottom:20px;">
        <h3 style="font-size:1.063rem; font-weight:600; margin-bottom:16px; display:flex; align-items:center; gap:8px;">
            <i class="fas fa-search" style="color:var(--primary);"></i> SEO Settings
        </h3>
        <div class="form-grid">
            <div style="grid-column: span 2;">
                <label class="form-label">Meta Title</label>
                <input type="text" name="settings[meta_title]" class="form-input" value="<?= esc($groups['seo']['meta_title'] ?? 'RojgarSandhi - Your Gateway to Jobs, Skills & Career Success') ?>">
            </div>
            <div style="grid-column: span 2;">
                <label class="form-label">Meta Description</label>
                <textarea name="settings[meta_description]" class="form-input" rows="3"><?= esc($groups['seo']['meta_description'] ?? '') ?></textarea>
            </div>
            <div style="grid-column: span 2;">
                <label class="form-label">Meta Keywords</label>
                <input type="text" name="settings[meta_keywords]" class="form-input" value="<?= esc($groups['seo']['meta_keywords'] ?? '') ?>">
            </div>
        </div>
    </div>

    <div class="glass-card" style="padding:24px; margin-bottom:20px;">
        <h3 style="font-size:1.063rem; font-weight:600; margin-bottom:16px; display:flex; align-items:center; gap:8px;">
            <i class="fas fa-image" style="color:var(--primary);"></i> Logo & Branding
        </h3>
        <div class="form-grid">
            <div>
                <label class="form-label">Favicon (.ico)</label>
                <input type="file" name="logo_favicon" class="form-input" accept=".ico">
                <?php if (file_exists(FCPATH . 'assets/images/logo/favicon.ico')): ?>
                    <div style="margin-top:8px; font-size:0.813rem; color:var(--gray-500);">Current: favicon.ico</div>
                <?php endif; ?>
            </div>
            <div>
                <label class="form-label">Apple Touch Icon (180x180 .png)</label>
                <input type="file" name="logo_apple" class="form-input" accept=".png">
                <?php if (file_exists(FCPATH . 'assets/images/logo/apple-touch-icon.png')): ?>
                    <div style="margin-top:8px; font-size:0.813rem; color:var(--gray-500);">Current: apple-touch-icon.png</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div style="display:flex; gap:12px;">
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save All Settings</button>
        <a href="<?= base_url('admin') ?>" class="btn btn-secondary">Cancel</a>
    </div>
</form>

<style>
.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
}
.form-grid > div {
    min-width: 0;
}
.form-label {
    display: block;
    font-size: 0.813rem;
    font-weight: 600;
    color: var(--gray-700);
    margin-bottom: 6px;
}
.form-input {
    width: 100%;
    padding: 10px 14px;
    border: 1px solid var(--gray-200);
    border-radius: 8px;
    font-size: 0.875rem;
    background: var(--bg);
    color: var(--text);
    transition: border-color 0.2s;
    box-sizing: border-box;
}
.form-input:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(99,102,241,0.1);
}
textarea.form-input {
    resize: vertical;
    font-family: inherit;
}
[data-theme="dark"] .form-input {
    border-color: var(--gray-700);
    background: var(--gray-800);
}
</style>
