<div style="margin-bottom:24px;"><a href="<?= base_url('admin/courses') ?>" style="color:var(--primary); text-decoration:none; font-size:0.875rem;"><i class="fas fa-arrow-left"></i> Back</a></div>
<h2 style="font-size:1.25rem; font-weight:700; margin-bottom:24px;"><?= isset($course) ? 'Edit Course' : 'Add Course' ?></h2>
<div class="glass-card" style="padding:32px;">
    <form action="<?= base_url('admin/courses/' . (isset($course) ? 'update/' . $course['id'] : 'store')) ?>" method="post">
        <?= csrf_field() ?>
        <div class="grid-2"><div class="form-group"><label class="form-label">Course Title</label><input type="text" name="title" class="form-input" value="<?= esc($course['title'] ?? '') ?>" required></div>
        <div class="form-group"><label class="form-label">Category</label><select name="category_id" class="form-select"><option value="">Select</option><?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= (isset($course) && ($course['category_id'] ?? '') == $c['id']) ? 'selected' : '' ?>><?= esc($c['name']) ?></option><?php endforeach; ?></select></div></div>
        <div class="form-group"><label class="form-label">Short Description</label><input type="text" name="short_description" class="form-input" value="<?= esc($course['short_description'] ?? '') ?>"></div>
        <div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-textarea"><?= $course['description'] ?? '' ?></textarea></div>
        <div class="grid-2"><div class="form-group"><label class="form-label">Duration</label><input type="text" name="duration" class="form-input" value="<?= esc($course['duration'] ?? '') ?>"></div>
        <div class="form-group"><label class="form-label">Level</label><select name="level" class="form-select"><option value="beginner" <?= (isset($course) && ($course['level'] ?? '') === 'beginner') ? 'selected' : '' ?>>Beginner</option><option value="intermediate" <?= (isset($course) && ($course['level'] ?? '') === 'intermediate') ? 'selected' : '' ?>>Intermediate</option><option value="advanced" <?= (isset($course) && ($course['level'] ?? '') === 'advanced') ? 'selected' : '' ?>>Advanced</option></select></div></div>
        <div class="grid-2"><div class="form-group"><label class="form-label">Price (₹)</label><input type="number" name="price" class="form-input" value="<?= $course['price'] ?? 0 ?>"></div>
        <div class="form-group"><label style="display:flex; align-items:center; gap:8px; margin-top:24px;"><input type="checkbox" name="is_free" value="1" <?= isset($course) && $course['is_free'] ? 'checked' : '' ?>> Free Course</label></div></div>
        <div class="form-group"><label class="form-label">Instructor Name</label><input type="text" name="instructor_name" class="form-input" value="<?= esc($course['instructor_name'] ?? '') ?>"></div>
        <div class="form-group"><label style="display:flex; align-items:center; gap:8px;"><input type="checkbox" name="is_active" value="1" <?= !isset($course) || $course['is_active'] ? 'checked' : '' ?>> Active</label></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <?= isset($course) ? 'Update' : 'Create' ?></button>
    </form>
</div>
