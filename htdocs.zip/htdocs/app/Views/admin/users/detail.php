<div style="margin-bottom:24px; display:flex; align-items:center; justify-content:space-between;">
    <a href="<?= base_url('admin/users') ?>" style="color:var(--primary); text-decoration:none; font-size:0.875rem;"><i class="fas fa-arrow-left"></i> Back to Users</a>
    <div style="display:flex; gap:8px;">
        <form action="<?= base_url('admin/users/reset-password/' . $user['id']) ?>" method="post" style="display:inline;" onsubmit="return confirm('Reset password for <?= esc($user['name'], 'js') ?>?')"><?= csrf_field() ?><button type="submit" class="btn btn-sm" style="background:#f59e0b; color:white; border:none; padding:6px 14px; border-radius:8px; cursor:pointer; font-size:0.813rem;"><i class="fas fa-key"></i> Reset Password</button></form>
        <form action="<?= base_url('admin/users/delete/' . $user['id']) ?>" method="post" style="display:inline;" onsubmit="return confirm('Delete user <?= esc($user['name'], 'js') ?>? This cannot be undone.')"><input type="hidden" name="_method" value="DELETE"><?= csrf_field() ?><button type="submit" class="btn btn-sm" style="background:#ef4444; color:white; border:none; padding:6px 14px; border-radius:8px; cursor:pointer; font-size:0.813rem;"><i class="fas fa-trash"></i> Delete User</button></form>
    </div>
</div>

<div class="glass-card" style="padding:24px; margin-bottom:24px;">
    <div style="display:flex; align-items:center; gap:16px; margin-bottom:20px;">
        <div style="width:56px; height:56px; border-radius:50%; background:var(--gradient-1); display:flex; align-items:center; justify-content:center; color:white; font-size:1.25rem; font-weight:700;"><?= strtoupper(substr($user['name'], 0, 1)) ?></div>
        <div>
            <h2 style="font-size:1.25rem; font-weight:700;"><?= esc($user['name']) ?></h2>
            <span style="font-size:0.813rem; color:var(--gray-500);"><?= esc($user['email']) ?></span>
        </div>
        <div style="margin-left:auto;">
            <?php if ($user['is_active']): ?>
            <span style="background:rgba(16,185,129,0.1); color:#10b981; padding:4px 12px; border-radius:20px; font-size:0.75rem;"><i class="fas fa-circle" style="font-size:0.5rem; vertical-align:middle;"></i> Active</span>
            <?php else: ?>
            <span style="background:rgba(239,68,68,0.1); color:#ef4444; padding:4px 12px; border-radius:20px; font-size:0.75rem;"><i class="fas fa-circle" style="font-size:0.5rem; vertical-align:middle;"></i> Inactive</span>
            <?php endif; ?>
            <span style="background:rgba(99,102,241,0.1); color:var(--primary); padding:4px 12px; border-radius:20px; font-size:0.75rem; margin-left:8px;"><?= ucfirst($user['role']) ?></span>
        </div>
    </div>
    <div class="grid-3">
        <div><label style="font-size:0.75rem; color:var(--gray-500); display:block;">Phone</label><span style="font-weight:500;"><?= esc($user['phone'] ?? 'N/A') ?></span></div>
        <div><label style="font-size:0.75rem; color:var(--gray-500); display:block;">Joined</label><span style="font-weight:500;"><?= date('d M Y', strtotime($user['created_at'])) ?></span></div>
        <div><label style="font-size:0.75rem; color:var(--gray-500); display:block;">Last Login</label><span style="font-weight:500;"><?= $user['last_login_at'] ? date('d M Y, h:i A', strtotime($user['last_login_at'])) : 'Never' ?></span></div>
    </div>
</div>

<?php if (!empty($applications)): ?>
<div class="glass-card" style="padding:24px;">
    <h3 style="font-size:1.063rem; font-weight:600; margin-bottom:16px;">Applications (<?= count($applications) ?>)</h3>
    <div style="overflow-x:auto;">
        <table class="admin-table">
            <thead>
                <tr><th>Type</th><th>Status</th><th>Applied At</th></tr>
            </thead>
            <tbody>
                <?php foreach ($applications as $a): ?>
                <tr>
                    <td><?= ucfirst($a['type']) ?></td>
                    <td><span class="badge badge-<?= $a['status'] ?>"><?= ucfirst($a['status']) ?></span></td>
                    <td style="font-size:0.813rem; white-space:nowrap;"><?= date('d M Y, h:i A', strtotime($a['applied_at'])) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php else: ?>
<div class="glass-card" style="padding:32px; text-align:center; color:var(--gray-500);">
    <i class="fas fa-inbox" style="font-size:2rem; display:block; margin-bottom:8px; color:var(--gray-300);"></i>
    <p style="font-size:0.875rem;">No applications yet.</p>
</div>
<?php endif; ?>
