<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Admin Panel - RojgarSandhi') ?></title>
    <meta name="robots" content="noindex, nofollow">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Tiro+Devanagari+Marathi:ital@0;1&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css?v=' . filemtime(FCPATH . 'assets/css/style.css')) ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/admin.css?v=' . filemtime(FCPATH . 'assets/css/admin.css')) ?>">
</head>
<body>
    <div class="admin-layout">
        <aside class="admin-sidebar" id="admin-sidebar">
            <div class="sidebar-brand">
                <a href="<?= base_url() ?>" class="logo" style="color:white;">
                    <div class="logo-icon" style="width:36px; height:36px; font-size:1rem;">RS</div>
                    <span style="font-weight:700; font-size:1.125rem;">Admin Panel</span>
                </a>
            </div>
            <nav class="sidebar-nav">
                <div class="sidebar-label">Main</div>
                <a href="<?= base_url('admin') ?>" class="sidebar-item <?= uri_string() === 'admin' ? 'active' : '' ?>"><i class="fas fa-th-large"></i> Dashboard</a>
                <a href="<?= base_url('admin/analytics') ?>" class="sidebar-item"><i class="fas fa-chart-line"></i> Analytics</a>
                
                <div class="sidebar-label">Content</div>
                <a href="<?= base_url('admin/jobs') ?>" class="sidebar-item"><i class="fas fa-briefcase"></i> Jobs</a>
                <a href="<?= base_url('admin/internships') ?>" class="sidebar-item"><i class="fas fa-laptop-code"></i> Internships</a>
                <a href="<?= base_url('admin/apprenticeships') ?>" class="sidebar-item"><i class="fas fa-tools"></i> Apprenticeships</a>
                <a href="<?= base_url('admin/courses') ?>" class="sidebar-item"><i class="fas fa-graduation-cap"></i> Courses</a>
                <a href="<?= base_url('admin/scholarships') ?>" class="sidebar-item"><i class="fas fa-award"></i> Scholarships</a>
                <a href="<?= base_url('admin/blogs') ?>" class="sidebar-item"><i class="fas fa-blog"></i> Blogs</a>
                <a href="<?= base_url('admin/results') ?>" class="sidebar-item"><i class="fas fa-poll"></i> Results</a>
                <a href="<?= base_url('admin/admit-cards') ?>" class="sidebar-item"><i class="fas fa-ticket-alt"></i> Admit Cards</a>
                <a href="<?= base_url('admin/mock-tests') ?>" class="sidebar-item"><i class="fas fa-clipboard-check"></i> Mock Tests</a>
                
                <div class="sidebar-label">Management</div>
                <a href="<?= base_url('admin/users') ?>" class="sidebar-item"><i class="fas fa-users"></i> Users</a>
                <a href="<?= base_url('admin/categories') ?>" class="sidebar-item"><i class="fas fa-tags"></i> Categories</a>
                <a href="<?= base_url('admin/testimonials') ?>" class="sidebar-item"><i class="fas fa-quote-right"></i> Testimonials</a>
                <a href="<?= base_url('admin/payments') ?>" class="sidebar-item"><i class="fas fa-credit-card"></i> Payments</a>
                <a href="<?= base_url('admin/applications') ?>" class="sidebar-item"><i class="fas fa-paper-plane"></i> Applications</a>
                <a href="<?= base_url('admin/contact-messages') ?>" class="sidebar-item"><i class="fas fa-envelope"></i> Messages</a>
                
                <div class="sidebar-label">System</div>
                <a href="<?= base_url('admin/settings') ?>" class="sidebar-item <?= uri_string() === 'admin/settings' ? 'active' : '' ?>"><i class="fas fa-cog"></i> Settings</a>
                <a href="<?= base_url('/') ?>" class="sidebar-item"><i class="fas fa-external-link-alt"></i> View Site</a>
                <a href="<?= base_url('logout') ?>" class="sidebar-item" style="color:#ef4444;"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
        </aside>
        <div class="admin-main">
            <header class="admin-header">
                <button onclick="document.getElementById('admin-sidebar').classList.toggle('open')" style="background:none; border:none; font-size:1.25rem; cursor:pointer; display:none;" class="mobile-sidebar-toggle"><i class="fas fa-bars"></i></button>
                <h2 style="font-size:1.125rem; font-weight:600;"><?= esc($title ?? 'Dashboard') ?></h2>
                <div style="display:flex; align-items:center; gap:16px;">
                    <span style="font-size:0.875rem; color:var(--gray-500);"><?= esc($current_user['name'] ?? 'Admin') ?></span>
                    <a href="<?= base_url('logout') ?>" class="btn btn-secondary btn-sm"><i class="fas fa-sign-out-alt"></i></a>
                </div>
            </header>
            <div class="admin-content">
