<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:24px; flex-wrap:wrap; gap:12px;">
    <h2 style="font-size:1.25rem; font-weight:700;">Manage Jobs</h2>
    <a href="<?= base_url('admin/jobs/create') ?>" class="btn btn-primary"><i class="fas fa-plus"></i> Add Job</a>
</div>
<div class="glass-card" style="overflow:hidden;">
    <table class="admin-table">
        <thead><tr><th>Title</th><th>Company</th><th>Type</th><th>Posts</th><th>Last Date</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
            <?php foreach ($jobs as $j): ?>
            <tr>
                <td><a href="<?= base_url('jobs/' . $j['id']) ?>" style="color:var(--primary); text-decoration:none; font-weight:500;"><?= esc($j['title']) ?></a></td>
                <td><?= esc($j['company_name']) ?></td>
                <td><span class="badge badge-<?= $j['job_type'] === 'government' ? 'success' : 'info' ?>"><?= ucfirst($j['job_type']) ?></span></td>
                <td><span class="badge badge-primary"><?= $postCounts[$j['id']] ?? 0 ?> posts</span></td>
                <td><?= $j['last_date_to_apply'] ? format_date($j['last_date_to_apply']) : 'N/A' ?></td>
                <td><span class="badge badge-<?= $j['is_active'] ? 'success' : 'secondary' ?>"><?= $j['is_active'] ? 'Active' : 'Inactive' ?></span></td>
                <td>
                    <a href="<?= base_url('admin/jobs/edit/' . $j['id']) ?>" class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></a>
                    <a href="<?= base_url('admin/jobs/delete/' . $j['id']) ?>" class="btn btn-secondary btn-sm" onclick="return confirm('Delete this job?')" style="color:#ef4444;"><i class="fas fa-trash"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= view('partials/pagination', ['pager' => $pager ?? null]) ?>
