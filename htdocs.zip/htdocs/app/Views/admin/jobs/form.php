<div style="margin-bottom:24px;"><a href="<?= base_url('admin/jobs') ?>" style="color:var(--primary); text-decoration:none; font-size:0.875rem;"><i class="fas fa-arrow-left"></i> Back to Jobs</a></div>
<h2 style="font-size:1.25rem; font-weight:700; margin-bottom:24px;"><?= isset($job) ? 'Edit Job' : 'Add Job' ?></h2>
<div class="glass-card" style="padding:32px;">
    <form action="<?= base_url('admin/jobs/' . (isset($job) ? 'update/' . $job['id'] : 'store')) ?>" method="post">
        <?= csrf_field() ?>
        <div class="grid-2"><div class="form-group"><label class="form-label">Job Title</label><input type="text" name="title" class="form-input" value="<?= esc($job['title'] ?? '') ?>" required></div>
        <div class="form-group"><label class="form-label">Company Name</label><input type="text" name="company_name" class="form-input" value="<?= esc($job['company_name'] ?? '') ?>" required></div></div>
        <div class="grid-2"><div class="form-group"><label class="form-label">Location</label><input type="text" name="location" class="form-input" value="<?= esc($job['location'] ?? '') ?>"></div>
        <div class="form-group"><label class="form-label">State</label><input type="text" name="state" class="form-input" value="<?= esc($job['state'] ?? '') ?>"></div></div>
        <div class="grid-2"><div class="form-group"><label class="form-label">Job Type</label><select name="job_type" class="form-select"><option value="government" <?= (isset($job) && $job['job_type'] === 'government') ? 'selected' : '' ?>>Government</option><option value="private" <?= (isset($job) && $job['job_type'] === 'private') ? 'selected' : '' ?>>Private</option><option value="apprenticeship" <?= (isset($job) && $job['job_type'] === 'apprenticeship') ? 'selected' : '' ?>>Apprenticeship</option></select></div>
        <div class="form-group"><label class="form-label">Category</label><select name="category_id" class="form-select"><option value="">Select Category</option><?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= (isset($job) && ($job['category_id'] ?? '') == $c['id']) ? 'selected' : '' ?>><?= esc($c['name']) ?></option><?php endforeach; ?></select></div></div>
        <div class="grid-2"><div class="form-group"><label class="form-label">Salary Min</label><input type="number" name="salary_min" class="form-input" value="<?= $job['salary_min'] ?? '' ?>"></div>
        <div class="form-group"><label class="form-label">Salary Max</label><input type="number" name="salary_max" class="form-input" value="<?= $job['salary_max'] ?? '' ?>"></div></div>
        <div class="grid-2"><div class="form-group"><label class="form-label">Experience Min (years)</label><input type="number" name="experience_min" class="form-input" value="<?= $job['experience_min'] ?? '' ?>"></div>
        <div class="form-group"><label class="form-label">Experience Max</label><input type="number" name="experience_max" class="form-input" value="<?= $job['experience_max'] ?? '' ?>"></div></div>
        <div class="grid-2"><div class="form-group"><label class="form-label">Department</label><input type="text" name="department" class="form-input" value="<?= esc($job['department'] ?? '') ?>"></div>
        <div class="form-group"><label class="form-label">Total Vacancies</label><input type="number" name="total_vacancies" class="form-input" value="<?= $job['total_vacancies'] ?? '' ?>"></div></div>
        <div class="grid-2"><div class="form-group"><label class="form-label">Last Date to Apply</label><input type="date" name="last_date_to_apply" class="form-input" value="<?= $job['last_date_to_apply'] ?? '' ?>"></div>
        <div class="form-group"></div></div>

        <!-- Job Posts (Multiple Positions) -->
        <div style="margin: 24px 0; padding: 20px; background: var(--gray-50); border-radius: 12px; border: 1px solid var(--gray-200);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
                <h3 style="font-size: 1rem; font-weight: 700;">Job Positions / Posts</h3>
                <button type="button" onclick="addJobPost()" class="btn btn-secondary btn-sm"><i class="fas fa-plus"></i> Add Post</button>
            </div>
            <div id="job-posts-container">
                <?php if (!empty($jobPosts)): ?>
                    <?php foreach ($jobPosts as $i => $post): ?>
                    <div class="job-post-row" style="padding:16px; margin-bottom:12px; background:white; border-radius:8px; border:1px solid var(--gray-200);">
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                            <strong style="font-size:0.875rem;">Post #<?= $i + 1 ?></strong>
                            <button type="button" onclick="this.closest('.job-post-row').remove()" style="background:none; border:none; color:#ef4444; cursor:pointer; font-size:0.813rem;"><i class="fas fa-times"></i> Remove</button>
                        </div>
                        <div class="grid-2">
                            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Post Title</label><input type="text" name="post_title[]" class="form-input" value="<?= esc($post['title']) ?>" placeholder="e.g. Junior Engineer"></div>
                            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Qualification</label><input type="text" name="post_qualification[]" class="form-input" value="<?= esc($post['qualification']) ?>" placeholder="e.g. BE/B.Tech"></div>
                        </div>
                        <div class="grid-2">
                            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Vacancies</label><input type="number" name="post_vacancies[]" class="form-input" value="<?= $post['vacancies'] ?>" placeholder="e.g. 10"></div>
                            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Department</label><input type="text" name="post_department[]" class="form-input" value="<?= esc($post['department']) ?>"></div>
                        </div>
                        <div class="grid-2">
                            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Experience Min</label><input type="number" name="post_experience_min[]" class="form-input" value="<?= $post['experience_min'] ?>" placeholder="Years"></div>
                            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Experience Max</label><input type="number" name="post_experience_max[]" class="form-input" value="<?= $post['experience_max'] ?>" placeholder="Years"></div>
                        </div>
                        <div class="grid-2">
                            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Salary Min</label><input type="number" step="0.01" name="post_salary_min[]" class="form-input" value="<?= $post['salary_min'] ?>"></div>
                            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Salary Max</label><input type="number" step="0.01" name="post_salary_max[]" class="form-input" value="<?= $post['salary_max'] ?>"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
        <script>
        function addJobPost() {
            const container = document.getElementById('job-posts-container');
            const idx = container.children.length + 1;
            const div = document.createElement('div');
            div.className = 'job-post-row';
            div.style.cssText = 'padding:16px; margin-bottom:12px; background:white; border-radius:8px; border:1px solid var(--gray-200);';
            div.innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                    <strong style="font-size:0.875rem;">Post #\${idx}</strong>
                    <button type="button" onclick="this.closest('.job-post-row').remove()" style="background:none; border:none; color:#ef4444; cursor:pointer; font-size:0.813rem;"><i class="fas fa-times"></i> Remove</button>
                </div>
                <div class="grid-2">
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Post Title</label><input type="text" name="post_title[]" class="form-input" placeholder="e.g. Junior Engineer"></div>
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Qualification</label><input type="text" name="post_qualification[]" class="form-input" placeholder="e.g. BE/B.Tech"></div>
                </div>
                <div class="grid-2">
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Vacancies</label><input type="number" name="post_vacancies[]" class="form-input" placeholder="e.g. 10"></div>
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Department</label><input type="text" name="post_department[]" class="form-input"></div>
                </div>
                <div class="grid-2">
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Experience Min</label><input type="number" name="post_experience_min[]" class="form-input" placeholder="Years"></div>
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Experience Max</label><input type="number" name="post_experience_max[]" class="form-input" placeholder="Years"></div>
                </div>
                <div class="grid-2">
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Salary Min</label><input type="number" step="0.01" name="post_salary_min[]" class="form-input"></div>
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Salary Max</label><input type="number" step="0.01" name="post_salary_max[]" class="form-input"></div>
                </div>
            `;
            container.appendChild(div);
        }
        </script>

        <div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-textarea" rows="5"><?= $job['description'] ?? '' ?></textarea></div>
        <div class="form-group"><label class="form-label">Requirements</label><textarea name="requirements" class="form-textarea" rows="4"><?= $job['requirements'] ?? '' ?></textarea></div>
        <div class="form-group"><label class="form-label">Apply Link</label><input type="url" name="apply_link" class="form-input" value="<?= esc($job['apply_link'] ?? '') ?>"></div>
        <div class="form-group" style="display:flex; gap:20px;"><label style="display:flex; align-items:center; gap:8px;"><input type="checkbox" name="is_featured" value="1" <?= isset($job) && $job['is_featured'] ? 'checked' : '' ?>> Featured</label><label style="display:flex; align-items:center; gap:8px;"><input type="checkbox" name="is_trending" value="1" <?= isset($job) && $job['is_trending'] ? 'checked' : '' ?>> Trending</label><label style="display:flex; align-items:center; gap:8px;"><input type="checkbox" name="is_active" value="1" <?= !isset($job) || $job['is_active'] ? 'checked' : '' ?>> Active</label></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <?= isset($job) ? 'Update Job' : 'Create Job' ?></button>
    </form>
</div>
