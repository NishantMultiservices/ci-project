<div style="margin-bottom:24px;">
    <a href="<?= base_url('admin/course-lessons/' . $course['id']) ?>" style="color:var(--primary); text-decoration:none; font-size:0.875rem;"><i class="fas fa-arrow-left"></i> Back to Lessons</a>
</div>
<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:24px; flex-wrap:wrap; gap:12px;">
    <h2 style="font-size:1.25rem; font-weight:700;">Quiz Questions - <?= esc($lesson['title']) ?></h2>
    <a href="<?= base_url('admin/lesson-quiz/' . $lesson['id'] . '/create') ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add Question</a>
</div>
<?php if (!empty($questions)): ?>
<div class="glass-card" style="overflow:hidden;">
    <table class="admin-table">
        <thead><tr><th>#</th><th>Question</th><th>Options</th><th>Correct</th><th>Marks</th><th style="width:140px;">Actions</th></tr></thead>
        <tbody>
            <?php foreach ($questions as $i => $q): ?>
            <tr>
                <td><?= $i + 1 ?></td>
                <td style="max-width:300px;"><?= esc($q['question']) ?></td>
                <td style="font-size:0.75rem;">
                    A: <?= esc($q['option_a']) ?><br>
                    B: <?= esc($q['option_b']) ?><br>
                    C: <?= esc($q['option_c']) ?><br>
                    D: <?= esc($q['option_d']) ?>
                </td>
                <td><span class="badge badge-success"><?= strtoupper($q['correct_option']) ?></span></td>
                <td><?= $q['marks'] ?></td>
                <td style="white-space:nowrap;">
                    <a href="<?= base_url('admin/lesson-quiz/' . $lesson['id'] . '/edit/' . $q['id']) ?>" class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></a>
                    <form action="<?= base_url('admin/lesson-quiz/' . $lesson['id'] . '/delete/' . $q['id']) ?>" method="post" style="display:inline;" onsubmit="return confirm('Delete this question?')"><?= csrf_field() ?><input type="hidden" name="_method" value="DELETE"><button type="submit" class="btn btn-sm" style="background:#ef4444; color:white; border:none; padding:4px 10px; border-radius:6px; cursor:pointer;"><i class="fas fa-trash"></i></button></form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php else: ?>
<div class="glass-card" style="padding:40px; text-align:center;">
    <i class="fas fa-question-circle" style="font-size:2.5rem; color:var(--gray-300); margin-bottom:12px; display:block;"></i>
    <p style="color:var(--gray-500); margin-bottom:16px;">No questions yet for this quiz.</p>
    <a href="<?= base_url('admin/lesson-quiz/' . $lesson['id'] . '/create') ?>" class="btn btn-primary"><i class="fas fa-plus"></i> Add First Question</a>
</div>
<?php endif; ?>
