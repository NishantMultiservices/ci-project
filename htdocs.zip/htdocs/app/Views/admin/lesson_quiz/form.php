<div style="margin-bottom:24px;">
    <a href="<?= base_url('admin/lesson-quiz/' . $lesson['id']) ?>" style="color:var(--primary); text-decoration:none; font-size:0.875rem;"><i class="fas fa-arrow-left"></i> Back to Questions</a>
</div>
<h2 style="font-size:1.25rem; font-weight:700; margin-bottom:24px;"><?= isset($question) ? 'Edit Question' : 'Add Question' ?> - <?= esc($lesson['title']) ?></h2>
<div class="glass-card" style="padding:32px;">
    <form action="<?= base_url('admin/lesson-quiz/' . $lesson['id'] . '/' . (isset($question) ? 'update/' . $question['id'] : 'store')) ?>" method="post">
        <?= csrf_field() ?>
        <div class="form-group"><label class="form-label">Question</label><textarea name="question" class="form-textarea" rows="3" required><?= esc($question['question'] ?? '') ?></textarea></div>
        <div class="grid-2">
            <div class="form-group"><label class="form-label">Option A</label><input type="text" name="option_a" class="form-input" value="<?= esc($question['option_a'] ?? '') ?>" required></div>
            <div class="form-group"><label class="form-label">Option B</label><input type="text" name="option_b" class="form-input" value="<?= esc($question['option_b'] ?? '') ?>" required></div>
            <div class="form-group"><label class="form-label">Option C</label><input type="text" name="option_c" class="form-input" value="<?= esc($question['option_c'] ?? '') ?>" required></div>
            <div class="form-group"><label class="form-label">Option D</label><input type="text" name="option_d" class="form-input" value="<?= esc($question['option_d'] ?? '') ?>" required></div>
        </div>
        <div class="grid-3">
            <div class="form-group"><label class="form-label">Correct Option</label><select name="correct_option" class="form-select" required><option value="a" <?= (isset($question) && $question['correct_option'] === 'a') ? 'selected' : '' ?>>A</option><option value="b" <?= (isset($question) && $question['correct_option'] === 'b') ? 'selected' : '' ?>>B</option><option value="c" <?= (isset($question) && $question['correct_option'] === 'c') ? 'selected' : '' ?>>C</option><option value="d" <?= (isset($question) && $question['correct_option'] === 'd') ? 'selected' : '' ?>>D</option></select></div>
            <div class="form-group"><label class="form-label">Marks</label><input type="number" name="marks" class="form-input" step="0.01" value="<?= $question['marks'] ?? 1 ?>"></div>
            <div class="form-group"><label class="form-label">Sort Order</label><input type="number" name="sort_order" class="form-input" value="<?= $question['sort_order'] ?? 0 ?>"></div>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <?= isset($question) ? 'Update' : 'Add' ?> Question</button>
    </form>
</div>
