<div style="margin-bottom:24px;"><a href="<?= base_url('admin/admit-cards') ?>" style="color:var(--primary); text-decoration:none; font-size:0.875rem;"><i class="fas fa-arrow-left"></i> Back</a></div>
<h2 style="font-size:1.25rem; font-weight:700; margin-bottom:24px;"><?= isset($admit_card) ? 'Edit' : 'Add' ?> Admit Card</h2>
<div class="glass-card" style="padding:32px;">
<form action="<?= base_url('admin/admit-cards/' . (isset($admit_card) ? 'update/' . $admit_card['id'] : 'store')) ?>" method="post">
<?= csrf_field() ?>
<div class="grid-2"><div class="form-group"><label class="form-label">Title</label><input type="text" name="title" class="form-input" value="<?= esc($admit_card['title'] ?? '') ?>" required></div>
<div class="form-group"><label class="form-label">Exam Name</label><input type="text" name="exam_name" class="form-input" value="<?= esc($admit_card['exam_name'] ?? '') ?>"></div></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Release Date</label><input type="date" name="release_date" class="form-input" value="<?= $admit_card['release_date'] ?? '' ?>"></div>
<div class="form-group"><label class="form-label">Exam Date</label><input type="date" name="exam_date" class="form-input" value="<?= $admit_card['exam_date'] ?? '' ?>"></div></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Download Link</label><input type="url" name="download_link" class="form-input" value="<?= esc($admit_card['download_link'] ?? '') ?>"></div>
<div class="form-group"><label class="form-label">Last Date to Download</label><input type="date" name="last_date_to_download" class="form-input" value="<?= $admit_card['last_date_to_download'] ?? '' ?>"></div></div>
<div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-textarea" rows="5"><?= $admit_card['description'] ?? '' ?></textarea></div>
<div class="form-group"><label class="form-label">Instructions</label><textarea name="instructions" class="form-textarea" rows="4"><?= $admit_card['instructions'] ?? '' ?></textarea></div>
<div class="form-group" style="display:flex; gap:20px;"><label style="display:flex; align-items:center; gap:8px;"><input type="checkbox" name="is_active" value="1" <?= !isset($admit_card) || $admit_card['is_active'] ? 'checked' : '' ?>> Active</label></div>
<button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <?= isset($admit_card) ? 'Update' : 'Create' ?></button>
</form>
</div>
