<div style="margin-bottom:24px;"><a href="<?= base_url('admin/blogs') ?>" style="color:var(--primary); text-decoration:none; font-size:0.875rem;"><i class="fas fa-arrow-left"></i> Back to Blogs</a></div>
<h2 style="font-size:1.25rem; font-weight:700; margin-bottom:24px;"><?= isset($blog) ? 'Edit Blog' : 'Add Blog' ?></h2>
<div class="glass-card" style="padding:32px;">
<form action="<?= base_url('admin/blogs/' . (isset($blog) ? 'update/' . $blog['id'] : 'store')) ?>" method="post">
<?= csrf_field() ?>
<div class="grid-2"><div class="form-group"><label class="form-label">Title</label><input type="text" name="title" class="form-input" value="<?= esc($blog['title'] ?? '') ?>" required></div>
<div class="form-group"><label class="form-label">Slug</label><input type="text" name="slug" class="form-input" value="<?= esc($blog['slug'] ?? '') ?>"></div></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Category</label><select name="category_id" class="form-select"><option value="">Select</option><?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= (isset($blog) && ($blog['category_id'] ?? '') == $c['id']) ? 'selected' : '' ?>><?= esc($c['name']) ?></option><?php endforeach; ?></select></div>
<div class="form-group"><label class="form-label">Author Name</label><input type="text" name="author_name" class="form-input" value="<?= esc($blog['author_name'] ?? '') ?>"></div></div>
<div class="form-group"><label class="form-label">Excerpt</label><textarea name="excerpt" class="form-textarea" rows="3"><?= $blog['excerpt'] ?? '' ?></textarea></div>
<div class="form-group"><label class="form-label">Content</label><textarea name="content" class="form-textarea" rows="12"><?= $blog['content'] ?? '' ?></textarea></div>
<div class="grid-2"><div class="form-group"><label class="form-label">Meta Title</label><input type="text" name="meta_title" class="form-input" value="<?= esc($blog['meta_title'] ?? '') ?>"></div>
<div class="form-group"><label class="form-label">Meta Description</label><textarea name="meta_description" class="form-textarea" rows="2"><?= $blog['meta_description'] ?? '' ?></textarea></div></div>
<div class="form-group" style="display:flex; gap:20px;"><label style="display:flex; align-items:center; gap:8px;"><input type="checkbox" name="is_published" value="1" <?= isset($blog) && $blog['is_published'] ? 'checked' : '' ?>> Published</label><label style="display:flex; align-items:center; gap:8px;"><input type="checkbox" name="is_featured" value="1" <?= isset($blog) && $blog['is_featured'] ? 'checked' : '' ?>> Featured</label></div>
<button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <?= isset($blog) ? 'Update' : 'Create' ?></button>
</form>
</div>
