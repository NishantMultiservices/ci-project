<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:wght@400;700&family=Tiro+Devanagari+Marathi&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family:'Inter',sans-serif; background:linear-gradient(135deg,#f8fafc 0%,#eef2ff 50%,#f0fdf4 100%); display:flex; align-items:center; justify-content:center; min-height:100vh; padding:32px; }
        .certificate-wrapper { max-width:960px; width:100%; }
        .certificate { background:white; border-radius:24px; padding:56px; box-shadow:0 25px 80px rgba(0,0,0,0.08); position:relative; overflow:hidden; border:2px solid #e0e7ff; }
        .certificate::before { content:''; position:absolute; inset:0; background:linear-gradient(135deg,rgba(99,102,241,0.02),rgba(16,185,129,0.02)); pointer-events:none; }
        .cert-border-deco { position:absolute; top:10px; left:10px; right:10px; bottom:10px; border:2px solid #e0e7ff; border-radius:18px; pointer-events:none; }
        .cert-border-deco2 { position:absolute; top:16px; left:16px; right:16px; bottom:16px; border:1px solid #f1f5f9; border-radius:14px; pointer-events:none; }
        .cert-top-bar { position:absolute; top:0; left:0; right:0; height:6px; background:linear-gradient(90deg,#6366f1,#a855f7,#06b6d4,#10b981); border-radius:24px 24px 0 0; }
        .cert-header { text-align:center; position:relative; z-index:1; }
        .cert-badge { display:inline-flex; align-items:center; gap:8px; background:linear-gradient(135deg,#fef3c7,#fde68a); color:#92400e; padding:6px 20px; border-radius:30px; font-size:0.75rem; font-weight:700; margin-bottom:20px; letter-spacing:0.3px; border:1px solid #fcd34d; }
        .cert-badge i { color:#f59e0b; }
        .cert-title { font-family:'Playfair Display',serif; font-size:2.2rem; font-weight:700; color:#312e81; margin-bottom:4px; letter-spacing:1px; }
        .cert-subtitle { color:#94a3b8; font-size:0.85rem; font-weight:500; text-transform:uppercase; letter-spacing:3px; margin-bottom:28px; }
        .cert-seal { width:72px; height:72px; margin:0 auto 24px; border-radius:50%; background:linear-gradient(145deg,#fef3c7,#fde68a); border:3px solid #f59e0b; display:flex; align-items:center; justify-content:center; font-size:1.8rem; color:#92400e; box-shadow:0 4px 16px rgba(245,158,11,0.2); position:relative; }
        .cert-seal-ring { position:absolute; top:-6px; left:-6px; right:-6px; bottom:-6px; border:1.5px dashed #fcd34d; border-radius:50%; pointer-events:none; }
        .cert-label { text-align:center; color:#94a3b8; font-size:0.8rem; font-weight:500; letter-spacing:1px; text-transform:uppercase; margin-bottom:6px; }
        .cert-recipient { font-family:'Playfair Display',serif; font-size:2rem; font-weight:700; color:#1e293b; text-align:center; margin-bottom:8px; }
        .cert-recipient-underline { width:80px; height:2px; background:linear-gradient(90deg,#6366f1,transparent); margin:0 auto 16px; border-radius:2px; }
        .cert-text { color:#64748b; text-align:center; font-size:0.9rem; line-height:1.6; max-width:520px; margin:0 auto 20px; }
        .cert-course-name { display:inline-block; font-size:1.1rem; font-weight:700; color:#1e293b; text-align:center; padding:8px 28px; border-radius:8px; background:linear-gradient(135deg,rgba(99,102,241,0.06),rgba(16,185,129,0.06)); border:1px solid #e0e7ff; margin-bottom:28px; }
        .cert-details { display:flex; justify-content:center; gap:32px; padding:20px 0; border-top:1px solid #f1f5f9; border-bottom:1px solid #f1f5f9; margin-bottom:20px; flex-wrap:wrap; }
        .cert-detail-item { text-align:center; min-width:120px; }
        .cert-detail-label { font-size:0.65rem; text-transform:uppercase; color:#94a3b8; font-weight:600; letter-spacing:0.8px; margin-bottom:4px; }
        .cert-detail-value { font-size:0.85rem; font-weight:600; color:#1e293b; }
        .cert-footer { display:flex; justify-content:space-between; align-items:flex-end; padding-top:20px; flex-wrap:wrap; gap:16px; }
        .cert-signature { text-align:center; }
        .cert-signature-line { width:180px; height:1.5px; background:#e0e7ff; margin-bottom:6px; border-radius:2px; }
        .cert-signature-label { font-size:0.7rem; color:#94a3b8; letter-spacing:0.5px; }
        .cert-number { font-size:0.7rem; color:#94a3b8; text-align:right; }
        .cert-actions { display:flex; gap:12px; margin-top:28px; justify-content:center; }
        .btn { display:inline-flex; align-items:center; gap:8px; padding:11px 22px; border-radius:10px; font-size:0.85rem; font-weight:600; text-decoration:none; cursor:pointer; transition:all 0.2s; border:none; }
        .btn-primary { background:#6366f1; color:white; }
        .btn-primary:hover { background:#4f46e5; transform:translateY(-1px); box-shadow:0 4px 12px rgba(99,102,241,0.3); }
        .btn-outline { background:transparent; color:#475569; border:1.5px solid #e2e8f0; }
        .btn-outline:hover { background:#f8fafc; border-color:#cbd5e1; }
        @media print { body { padding:16px; background:white; } .cert-actions { display:none; } .certificate { box-shadow:none; border:2px solid #e0e7ff; border-radius:16px; padding:40px; } }
    </style>
</head>
<body>
<div class="certificate-wrapper">
    <div class="certificate" id="certificate">
        <div class="cert-top-bar"></div>
        <div class="cert-border-deco"></div>
        <div class="cert-border-deco2"></div>
        <div class="cert-header">
            <div class="cert-badge"><i class="fas fa-award"></i> Certificate of Completion</div>
            <div class="cert-title">RojgarSandhi</div>
            <div class="cert-subtitle">Skill Development Program</div>
        </div>
        <div class="cert-seal"><div class="cert-seal-ring"></div><i class="fas fa-check"></i></div>
        <div class="cert-label">This is to certify that</div>
        <div class="cert-recipient"><?= esc($user['name']) ?></div>
        <div class="cert-recipient-underline"></div>
        <div class="cert-text">has successfully completed the online course</div>
        <div class="cert-course-name"><?= esc($course['title']) ?></div>
        <div class="cert-details">
            <div class="cert-detail-item"><div class="cert-detail-label">Instructor</div><div class="cert-detail-value"><?= esc($course['instructor_name'] ?? 'Expert Instructor') ?></div></div>
            <div class="cert-detail-item"><div class="cert-detail-label">Duration</div><div class="cert-detail-value"><?= esc($course['duration'] ?? 'Self-paced') ?></div></div>
            <div class="cert-detail-item"><div class="cert-detail-label">Issued On</div><div class="cert-detail-value"><?= date('d M Y', strtotime($cert['issued_at'])) ?></div></div>
            <div class="cert-detail-item"><div class="cert-detail-label">Certificate No.</div><div class="cert-detail-value"><?= esc($cert['certificate_number']) ?></div></div>
        </div>
        <div class="cert-footer">
            <div class="cert-signature">
                <img src="<?= base_url('assets/images/signature.png') ?>" alt="Authorized Signature" style="height:36px; display:block; margin:0 auto 4px;">
                <div class="cert-signature-line"></div>
                <div class="cert-signature-label">Authorized Signature</div>
            </div>
            <div style="text-align:right;">
                <div style="font-size:0.85rem; font-weight:600; color:#1e293b;"><?= date('d/m/Y', strtotime($cert['issued_at'])) ?></div>
                <div style="font-size:0.65rem; color:#94a3b8; text-transform:uppercase; letter-spacing:0.5px;">Issue Date</div>
            </div>
        </div>
        <div class="cert-number"><i class="fas fa-certificate" style="color:#6366f1;"></i> RojgarSandhi — <?= esc($cert['certificate_number']) ?></div>
    </div>
    <div class="cert-actions">
        <button onclick="downloadPDF()" class="btn btn-primary"><i class="fas fa-download"></i> Download PDF</button>
        <a href="<?= base_url('dashboard/my-courses') ?>" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back to Courses</a>
        <a href="<?= base_url('dashboard/certificates') ?>" class="btn btn-outline"><i class="fas fa-certificate"></i> All Certificates</a>
    </div>
</div>
<script>
function downloadPDF() {
    var btn = document.querySelector('.btn-primary');
    var btns = document.querySelectorAll('.cert-actions .btn');
    btns.forEach(function(el) { el.style.display = 'none'; });
    var wrapper = document.querySelector('.certificate-wrapper');
    wrapper.style.maxWidth = '100%';
    var element = document.getElementById('certificate');
    var opt = {
        margin: [0, 0, 0, 0],
        filename: 'certificate-<?= esc($cert['certificate_number'], 'js') ?>.pdf',
        image: { type: 'jpeg', quality: 1 },
        html2canvas: { scale: 2, useCORS: true, letterRendering: true, logging: false },
        jsPDF: { unit: 'in', format: 'a4', orientation: 'landscape' }
    };
    html2pdf().set(opt).from(element).save().then(function() {
        btns.forEach(function(el) { el.style.display = ''; });
        wrapper.style.maxWidth = '';
    });
}
</script>
</body>
</html>