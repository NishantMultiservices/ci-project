<section class="section" style="padding-top:120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'About Us']]]) ?>
        <div class="section-header">
            <span class="section-label">About Us</span>
            <h1 class="section-title">Empowering <span class="gradient-text">Career Dreams</span></h1>
            <p class="section-desc">RojgarSandhi is India's premier career platform dedicated to connecting job seekers with their dream opportunities.</p>
        </div>
        <div style="max-width:800px; margin:0 auto;">
            <div class="glass-card" style="padding:40px; margin-bottom:32px;">
                <h3 style="margin-bottom:16px;">Our Mission</h3>
                <p style="color:var(--gray-600); line-height:1.8; margin-bottom:20px;">At RojgarSandhi, we believe that everyone deserves access to quality career opportunities. Our platform bridges the gap between job seekers and employers, making the job search process seamless, efficient, and accessible to all.</p>
                <h3 style="margin-bottom:16px;">What We Offer</h3>
                <ul style="color:var(--gray-600); line-height:2; padding-left:20px;">
                    <li>50,000+ active job listings across government and private sectors</li>
                    <li>Comprehensive skill development courses</li>
                    <li>Free resume builder with multiple templates</li>
                    <li>Interview preparation resources</li>
                    <li>Scholarship and financial aid information</li>
                    <li>Career guidance and counseling</li>
                </ul>
            </div>
            <div class="grid-3">
                <div class="glass-card" style="padding:24px; text-align:center;">
                    <div style="font-size:2.5rem; margin-bottom:12px; color:var(--primary);"><i class="fas fa-users"></i></div>
                    <h4 style="margin-bottom:4px;">10,000+</h4>
                    <p style="font-size:0.875rem; color:var(--gray-500);">Active Users</p>
                </div>
                <div class="glass-card" style="padding:24px; text-align:center;">
                    <div style="font-size:2.5rem; margin-bottom:12px; color:var(--success);"><i class="fas fa-briefcase"></i></div>
                    <h4 style="margin-bottom:4px;">50,000+</h4>
                    <p style="font-size:0.875rem; color:var(--gray-500);">Jobs Listed</p>
                </div>
                <div class="glass-card" style="padding:24px; text-align:center;">
                    <div style="font-size:2.5rem; margin-bottom:12px; color:var(--accent);"><i class="fas fa-building"></i></div>
                    <h4 style="margin-bottom:4px;">500+</h4>
                    <p style="font-size:0.875rem; color:var(--gray-500);">Partner Companies</p>
                </div>
            </div>
        </div>
    </div>
</section>
