<section class="section" style="padding-top:120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Internships']]]) ?>
        <div class="section-header animate-on-scroll" style="text-align:left; margin:0 0 32px;">
            <h1 class="section-title">Internships <span class="gradient-text">for You</span></h1>
            <p class="section-desc">Paid, remote, campus & summer internships from top companies.</p>
        </div>
        <div style="display:flex; gap:8px; margin-bottom:24px; flex-wrap:wrap;">
            <a href="<?= base_url('internships') ?>" class="btn btn-sm <?= !service('request')->getGet('type') ? 'btn-primary' : 'btn-secondary' ?>">All</a>
            <?php foreach ($types as $t): ?>
                <a href="<?= base_url('internships?type=' . $t) ?>" class="btn btn-sm <?= (service('request')->getGet('type') ?? '') === $t ? 'btn-primary' : 'btn-secondary' ?>"><?= ucfirst($t) ?></a>
            <?php endforeach; ?>
        </div>
        <div class="grid-3">
            <?php foreach ($internships as $item): ?>
            <div class="course-card">
                <div class="course-thumb" style="background:linear-gradient(135deg,#06b6d4,#3b82f6); height:120px;">
                    <div style="text-align:center;"><i class="fas fa-laptop-code" style="font-size:2rem;"></i><div style="font-size:0.875rem; margin-top:8px; font-weight:600;"><?= esc($item['company_name']) ?></div></div>
                    <span class="course-badge free"><?= ucfirst($item['type']) ?></span>
                </div>
                <div class="course-body">
                    <h3><?= esc($item['title']) ?></h3>
                    <div class="course-instructor"><i class="fas fa-map-marker-alt"></i> <?= esc($item['location'] ?? 'Remote') ?> &middot; <i class="fas fa-clock"></i> <?= esc($item['duration'] ?? '3 months') ?></div>
                    <div class="course-meta"><span style="font-weight:600;color:var(--success);"><?= format_salary($item['stipend_min'], $item['stipend_max'], $item['stipend_text']) ?></span><a href="<?= base_url('internships/' . $item['id']) ?>" class="btn btn-primary btn-sm">Apply</a></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
