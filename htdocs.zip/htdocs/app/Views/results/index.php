<section class="section" style="padding-top:120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Results']]]) ?>
        <div class="section-header" style="text-align:left; margin:0 0 32px;">
            <h1 class="section-title">Exam <span class="gradient-text">Results</span></h1>
            <p class="section-desc">Check latest exam results and cut-off marks.</p>
        </div>
        <div class="grid-3"><?php foreach ($results as $r): ?><div class="glass-card" style="padding:24px;"><div style="display:flex; align-items:flex-start; gap:16px;"><div style="width:48px; height:48px; border-radius:12px; background:linear-gradient(135deg,#10b981,#06b6d4); display:flex; align-items:center; justify-content:center; color:white; flex-shrink:0;"><i class="fas fa-poll"></i></div><div><h3 style="font-size:1rem; font-weight:600; margin-bottom:4px;"><a href="<?= base_url('results/' . $r['id']) ?>" style="color:var(--gray-900); text-decoration:none;"><?= esc($r['title']) ?></a></h3><p style="font-size:0.813rem; color:var(--gray-500);"><?= $r['exam_name'] ?? '' ?> <?= $r['result_date'] ? '&middot; ' . format_date($r['result_date']) : '' ?></p></div></div></div><?php endforeach; ?></div>
    </div>
</section>
