<!DOCTYPE html>
<html lang="en" data-theme="<?= session('theme') ?? 'light' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <title><?= esc($title ?? ($settings['meta_title'] ?? 'RojgarSandhi - Your Gateway to Jobs, Skills & Career Success')) ?></title>
    <meta name="description" content="<?= esc($description ?? ($settings['meta_description'] ?? '')) ?>">
    <meta name="keywords" content="<?= esc($settings['meta_keywords'] ?? 'jobs, government jobs, private jobs, internships, courses, career, India jobs, Sarkari Naukri, Rojgar') ?>">
    <meta name="author" content="<?= esc($settings['site_name'] ?? 'RojgarSandhi') ?>">
    <meta name="robots" content="index, follow">
    
    <!-- Open Graph Tags -->
    <?= $og_tags ?? '' ?>
    
    <!-- Canonical URL -->
    <link rel="canonical" href="<?= current_url() ?>">
    
    <!-- JSON-LD Structured Data -->
    <?= $json_ld ?? '' ?>
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?= base_url('assets/images/logo/favicon.ico') ?>">
    <link rel="apple-touch-icon" href="<?= base_url('assets/images/logo/apple-touch-icon.png') ?>">
    
    <!-- Manifest for PWA -->
    <link rel="manifest" href="<?= base_url('manifest.json') ?>">
    <meta name="theme-color" content="#6366f1">
    
    <!-- Preconnect to Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Tiro+Devanagari+Marathi:ital@0;1&display=swap" rel="stylesheet">
    
    <!-- Font Awesome 6 (Free) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- Tailwind CSS via CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Custom Styles -->
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css?v=' . filemtime(FCPATH . 'assets/css/style.css')) ?>">
    
    <!-- Additional Styles -->
    <?= $this->renderSection('styles') ?? '' ?>
    
    <!-- Service Worker Registration -->
    <script>
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('<?= base_url('sw.js') ?>')
                    .then(reg => console.log('SW registered:', reg.scope))
                    .catch(err => console.log('SW registration failed:', err));
            });
        }
    </script>
</head>
<body>
    <!-- Toast Container -->
    <div id="toast-container" class="toast-container"></div>
    
    <!-- Flash Messages -->
    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div>
    <?php endif; ?>
    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-error"><?= esc(session()->getFlashdata('error')) ?></div>
    <?php endif; ?>
    <?php if (session()->getFlashdata('info')): ?>
        <div class="alert alert-info"><?= esc(session()->getFlashdata('info')) ?></div>
    <?php endif; ?>
    <?php if (session()->getFlashdata('warning')): ?>
        <div class="alert alert-warning"><?= esc(session()->getFlashdata('warning')) ?></div>
    <?php endif; ?>
    
    <!-- Navigation -->
    <nav id="navbar" class="navbar">
        <div class="nav-container">
            <a href="<?= base_url() ?>" class="logo">
                <div class="logo-icon">RS</div>
                <span class="logo-text">Rojgar<span>Sandhi</span></span>
            </a>
            
            <ul id="nav-links" class="nav-links">
                <li><a href="<?= base_url('jobs') ?>" class="nav-link"><i class="fas fa-briefcase"></i> Latest Jobs</a></li>
                <li><a href="<?= base_url('admit-cards') ?>" class="nav-link"><i class="fas fa-ticket-alt"></i> Hall Ticket</a></li>
                <li><a href="<?= base_url('answer-keys') ?>" class="nav-link"><i class="fas fa-key"></i> Answer Key</a></li>
                <li><a href="<?= base_url('results') ?>" class="nav-link"><i class="fas fa-poll"></i> Result</a></li>
                <li><a href="<?= base_url('courses') ?>" class="nav-link"><i class="fas fa-graduation-cap"></i> Courses</a></li>
                <li><a href="<?= base_url('mock-tests') ?>" class="nav-link"><i class="fas fa-clipboard-check"></i> Mock Test</a></li>
                <li class="nav-item-dropdown">
                    <a href="#" class="nav-link dropdown-trigger"><i class="fas fa-ellipsis-h"></i> Other <i class="fas fa-chevron-down" style="font-size:0.625rem;margin-left:4px;"></i></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?= base_url('private-jobs') ?>"><i class="fas fa-building"></i> Private</a></li>
                        <li><a href="<?= base_url('internships') ?>"><i class="fas fa-laptop-code"></i> Internships</a></li>
                        <li><a href="<?= base_url('apprenticeships') ?>"><i class="fas fa-tools"></i> Apprentice</a></li>
                        <li><a href="<?= base_url('scholarships') ?>"><i class="fas fa-award"></i> Scholarships</a></li>
                        <li><a href="<?= base_url('blog') ?>"><i class="fas fa-blog"></i> Blogs</a></li>
                    </ul>
                </li>
            </ul>
            
            <div class="nav-actions">
                <!-- Auth Buttons -->
                <?php if ($is_logged_in ?? false): ?>
                    <a href="<?= base_url('dashboard') ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-user-circle"></i> Dashboard
                    </a>
                    <?php if ($is_admin ?? false): ?>
                        <a href="<?= base_url('admin') ?>" class="btn btn-secondary btn-sm">
                            <i class="fas fa-shield-alt"></i> Admin
                        </a>
                    <?php endif; ?>
                    <a href="<?= base_url('logout') ?>" class="btn btn-secondary btn-sm">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                <?php else: ?>
                    <a href="<?= base_url('login') ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-user"></i> Login / Register
                    </a>
                <?php endif; ?>
                
                <!-- Mobile Menu Button -->
                <button id="mobile-menu-btn" class="mobile-menu-btn">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </div>
    </nav>
    
    <main>