    </main>
    
    <!-- Newsletter Section -->
    <?php if (!str_starts_with(uri_string(), 'mock-tests') && !str_starts_with(uri_string(), 'courses/')): ?>
    <section class="section" style="background: linear-gradient(135deg, rgba(99, 102, 241, 0.04) 0%, rgba(139, 92, 246, 0.06) 100%);">
        <div class="container">
            <div class="newsletter-box">
                <span class="section-label">Stay Updated</span>
                <h2 class="section-title">Get Latest Job Alerts</h2>
                <p class="section-desc">Subscribe to our newsletter and never miss a job opportunity.</p>
                <form action="<?= base_url('home/subscribe') ?>" method="post" class="newsletter-form">
                    <?= csrf_field() ?>
                    <input type="email" name="email" placeholder="Enter your email address" required>
                    <button type="submit" class="btn btn-primary">Subscribe <i class="fas fa-paper-plane"></i></button>
                </form>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <a href="<?= base_url() ?>" class="logo">
                        <div class="logo-icon">RS</div>
                        <span class="logo-text" style="color: white;">Rojgar<span style="background: linear-gradient(135deg, #a5b4fc, #c4b5fd); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Sandhi</span></span>
                    </a>
                    <p>RojgarSandhi is India's premier career platform connecting millions of job seekers with the best opportunities in government, private, and skill development sectors.</p>
                    <div style="display: flex; gap: 12px; margin-top: 20px; flex-wrap: wrap;">
                        <?php if (!empty($settings['facebook_url'])): ?><a href="<?= esc($settings['facebook_url']) ?>" class="btn btn-secondary btn-sm" target="_blank" rel="noopener" style="border-color: #1e293b; color: #94a3b8;"><i class="fab fa-facebook-f"></i></a><?php endif; ?>
                        <?php if (!empty($settings['twitter_url'])): ?><a href="<?= esc($settings['twitter_url']) ?>" class="btn btn-secondary btn-sm" target="_blank" rel="noopener" style="border-color: #1e293b; color: #94a3b8;"><i class="fab fa-twitter"></i></a><?php endif; ?>
                        <?php if (!empty($settings['instagram_url'])): ?><a href="<?= esc($settings['instagram_url']) ?>" class="btn btn-secondary btn-sm" target="_blank" rel="noopener" style="border-color: #1e293b; color: #94a3b8;"><i class="fab fa-instagram"></i></a><?php endif; ?>
                        <?php if (!empty($settings['linkedin_url'])): ?><a href="<?= esc($settings['linkedin_url']) ?>" class="btn btn-secondary btn-sm" target="_blank" rel="noopener" style="border-color: #1e293b; color: #94a3b8;"><i class="fab fa-linkedin-in"></i></a><?php endif; ?>
                        <?php if (!empty($settings['youtube_url'])): ?><a href="<?= esc($settings['youtube_url']) ?>" class="btn btn-secondary btn-sm" target="_blank" rel="noopener" style="border-color: #1e293b; color: #94a3b8;"><i class="fab fa-youtube"></i></a><?php endif; ?>
                        <?php if (!empty($settings['telegram_url'])): ?><a href="<?= esc($settings['telegram_url']) ?>" class="btn btn-secondary btn-sm" target="_blank" rel="noopener" style="border-color: #1e293b; color: #94a3b8;"><i class="fab fa-telegram-plane"></i></a><?php endif; ?>
                    </div>
                </div>
                
                <div>
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="<?= base_url('jobs') ?>">Latest Jobs</a></li>
                        <li><a href="<?= base_url('government-jobs') ?>">Government Jobs</a></li>
                        <li><a href="<?= base_url('private-jobs') ?>">Private Jobs</a></li>
                        <li><a href="<?= base_url('internships') ?>">Internships</a></li>
                        <li><a href="<?= base_url('apprenticeships') ?>">Apprenticeships</a></li>
                        <li><a href="<?= base_url('results') ?>">Exam Results</a></li>
                        <li><a href="<?= base_url('admit-cards') ?>">Admit Cards</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4>Categories</h4>
                    <ul>
                        <li><a href="<?= base_url('jobs/category/upsc') ?>">UPSC Jobs</a></li>
                        <li><a href="<?= base_url('jobs/category/ssc') ?>">SSC Jobs</a></li>
                        <li><a href="<?= base_url('jobs/category/banking') ?>">Banking Jobs</a></li>
                        <li><a href="<?= base_url('jobs/category/railway') ?>">Railway Jobs</a></li>
                        <li><a href="<?= base_url('jobs/category/police') ?>">Police Jobs</a></li>
                        <li><a href="<?= base_url('jobs/category/defence') ?>">Defence Jobs</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4>Resources</h4>
                    <ul>
                        <li><a href="<?= base_url('courses') ?>">Skill Courses</a></li>
                        <li><a href="<?= base_url('scholarships') ?>">Scholarships</a></li>
                        <li><a href="<?= base_url('resume-builder') ?>">Resume Builder</a></li>
                        <li><a href="<?= base_url('interview-preparation') ?>">Interview Prep</a></li>
                        <li><a href="<?= base_url('career-guidance') ?>">Career Guidance</a></li>
                        <li><a href="<?= base_url('blog') ?>">Blog</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4>Support</h4>
                    <ul>
                        <li><a href="<?= base_url('about') ?>">About Us</a></li>
                        <li><a href="<?= base_url('contact') ?>">Contact Us</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Terms of Service</a></li>
                        <li><a href="#">Disclaimer</a></li>
                        <li><a href="#">Sitemap</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?= date('Y') ?> <?= esc($settings['site_name'] ?? 'RojgarSandhi') ?>. <?= esc($settings['footer_text'] ?? 'All rights reserved.') ?></p>
                <p>🇮🇳 Made in India</p>
            </div>
        </div>
    </footer>

    <!-- Search Suggestions CSS -->
    <style>
        .search-bar {
            padding: 16px 0;
            background: rgba(255,255,255,0.95);
            border-bottom: 1px solid var(--gray-200);
        }
        [data-theme="dark"] .search-bar {
            background: rgba(15,23,42,0.95);
        }
        .search-suggestions {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.12);
            z-index: 100;
            max-height: 400px;
            overflow-y: auto;
        }
        [data-theme="dark"] .search-suggestions {
            background: var(--gray-800);
        }
        .search-suggestions.hidden { display: none; }
        .suggestion-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            text-decoration: none;
            color: var(--gray-700);
            border-bottom: 1px solid var(--gray-100);
            transition: background 0.2s;
        }
        .suggestion-item:last-child { border-bottom: none; }
        .suggestion-item:hover { background: var(--gray-50); }
        .suggestion-title { display: block; font-weight: 600; font-size: 0.875rem; }
        .suggestion-company { display: block; font-size: 0.813rem; color: var(--gray-500); }
        #nav-links.active {
            display: flex;
            flex-direction: column;
            position: fixed;
            top: 72px;
            left: 0;
            right: 0;
            background: white;
            padding: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            max-height: calc(100vh - 72px);
            overflow-y: auto;
            z-index: 999;
        }
        [data-theme="dark"] #nav-links.active {
            background: var(--gray-800);
        }
    </style>

    <!-- Scripts -->
    <?= csrf_field() ?>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script>
    var baseUrl = '<?= base_url() ?>';
    </script>
    <script src="<?= base_url('assets/js/app.js?v=' . filemtime(FCPATH . 'assets/js/app.js')) ?>"></script>
    <script src="<?= base_url('assets/js/payment.js?v=' . filemtime(FCPATH . 'assets/js/payment.js')) ?>"></script>
    
    <script>
        function toggleSearch() {
            const searchBar = document.getElementById('search-bar');
            searchBar.style.display = searchBar.style.display === 'none' ? 'block' : 'none';
            if (searchBar.style.display === 'block') {
                document.getElementById('search-input').focus();
            }
        }
    </script>
    
    <?= $this->renderSection('scripts') ?? '' ?>
</body>
</html>