<section class="section" style="padding-top:120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Interview Preparation']]]) ?>
        <div class="section-header animate-on-scroll" style="text-align:left; margin:0 0 32px;">
            <h1 class="section-title">Interview <span class="gradient-text">Preparation</span></h1>
            <p class="section-desc">HR questions, technical questions, mock tests, and more.</p>
        </div>
        <div style="display:flex; gap:8px; margin-bottom:24px; flex-wrap:wrap;">
            <a href="<?= base_url('interview-preparation') ?>" class="btn btn-sm <?= !service('request')->getGet('category') && !service('request')->getGet('exam') ? 'btn-primary' : 'btn-secondary' ?>">All</a>
            <?php foreach ($categories as $c): ?><a href="<?= base_url('interview-preparation?category=' . $c) ?>" class="btn btn-sm <?= (service('request')->getGet('category') ?? '') === $c ? 'btn-primary' : 'btn-secondary' ?>"><?= ucfirst($c) ?></a><?php endforeach; ?>
        </div>
        <div style="margin-bottom:24px;"><h3 style="font-size:1rem; margin-bottom:12px;">Exam Categories</h3><div style="display:flex; gap:8px; flex-wrap:wrap;"><?php foreach ($exam_categories as $ec): ?><a href="<?= base_url('interview-preparation?exam=' . $ec) ?>" class="btn btn-sm <?= (service('request')->getGet('exam') ?? '') === $ec ? 'btn-primary' : 'btn-secondary' ?>"><?= ucfirst($ec) ?></a><?php endforeach; ?></div></div>
        <div class="grid-3">
            <?php foreach ($topics as $t): ?>
            <div class="glass-card" style="padding:24px;">
                <div style="display:flex; align-items:flex-start; gap:16px;">
                    <div style="width:48px; height:48px; border-radius:12px; background:linear-gradient(135deg,#10b981,#06b6d4); display:flex; align-items:center; justify-content:center; color:white; flex-shrink:0;"><i class="fas fa-<?= $t['category'] === 'hr' ? 'handshake' : ($t['category'] === 'technical' ? 'laptop-code' : ($t['category'] === 'mock' ? 'clipboard-check' : 'brain')) ?>"></i></div>
                    <div style="flex:1;"><h3 style="font-size:1rem; font-weight:600; margin-bottom:4px;"><a href="<?= base_url('interview-preparation/' . $t['slug']) ?>" style="color:var(--gray-900); text-decoration:none;"><?= esc($t['title']) ?></a></h3><p style="font-size:0.813rem; color:var(--gray-500);"><span class="job-tag"><?= ucfirst($t['category']) ?></span> <?= $t['total_questions'] ? $t['total_questions'] . ' questions' : '' ?> <?= $t['duration_minutes'] ? '&middot; ' . $t['duration_minutes'] . ' min' : '' ?></p></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
