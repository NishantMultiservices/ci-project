<section class="section" style="padding-top: 120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Mock Tests', 'url' => base_url('mock-tests')], ['name' => $test['title']]]]) ?>
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 32px;">
            <div>
                <div class="glass-card" style="padding: 32px;">
                    <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 20px;">
                        <div style="width: 56px; height: 56px; border-radius: 14px; background: var(--gradient-1); display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: white;"><i class="fas fa-clipboard-list"></i></div>
                        <div>
                            <h1 style="font-size: 1.5rem; font-weight: 700;"><?= esc($test['title']) ?></h1>
                            <?php if ($test['category']): ?><span class="job-tag" style="margin-top: 4px;"><?= esc($test['category']) ?></span><?php endif; ?>
                        </div>
                    </div>
                    <?php if ($test['description']): ?><p style="color: var(--gray-600); line-height: 1.8; margin-bottom: 24px;"><?= $test['description'] ?></p><?php endif; ?>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 16px; padding: 20px; background: var(--gray-50); border-radius: 12px; margin-bottom: 24px;">
                        <div style="text-align: center;"><span style="display: block; font-size: 1.5rem; font-weight: 700; color: var(--primary);"><?= $test['total_questions'] ?></span><span style="font-size: 0.813rem; color: var(--gray-500);">Total Questions</span></div>
                        <div style="text-align: center;"><span style="display: block; font-size: 1.5rem; font-weight: 700; color: var(--primary);"><?= $test['total_marks'] ?></span><span style="font-size: 0.813rem; color: var(--gray-500);">Total Marks</span></div>
                        <div style="text-align: center;"><span style="display: block; font-size: 1.5rem; font-weight: 700; color: var(--primary);"><?= $test['duration_minutes'] ?> min</span><span style="font-size: 0.813rem; color: var(--gray-500);">Duration</span></div>
                        <div style="text-align: center;"><span style="display: block; font-size: 1.5rem; font-weight: 700; color: var(--primary);"><?= $test['passing_marks'] ?: 'N/A' ?></span><span style="font-size: 0.813rem; color: var(--gray-500);">Passing Marks</span></div>
                    </div>
                    <?php if ($test['instructions']): ?>
                    <h3 style="font-size: 1.125rem; margin-bottom: 12px;">Instructions</h3>
                    <div style="color: var(--gray-600); line-height: 1.8;"><?= $test['instructions'] ?></div>
                    <?php endif; ?>
                </div>
            </div>
            <div>
                <div class="glass-card" style="padding: 24px; position: sticky; top: 100px;">
                    <h3 style="font-size: 1.063rem; margin-bottom: 16px;">Ready to Begin?</h3>
                    <ul style="list-style: none; padding: 0; margin: 0 0 20px; font-size: 0.875rem; color: var(--gray-600);">
                        <li style="padding: 8px 0; border-bottom: 1px solid var(--gray-100);"><i class="fas fa-check-circle" style="color: #10b981; width: 20px;"></i> <?= $test['total_questions'] ?> questions</li>
                        <li style="padding: 8px 0; border-bottom: 1px solid var(--gray-100);"><i class="fas fa-check-circle" style="color: #10b981; width: 20px;"></i> <?= $test['duration_minutes'] ?> minutes duration</li>
                        <li style="padding: 8px 0; border-bottom: 1px solid var(--gray-100);"><i class="fas fa-check-circle" style="color: #10b981; width: 20px;"></i> <?= $test['total_marks'] ?> total marks</li>
                        <li style="padding: 8px 0;"><i class="fas fa-check-circle" style="color: #10b981; width: 20px;"></i> Instant results</li>
                    </ul>
                    <?php if ($test['is_free']): ?>
                    <a href="<?= base_url('mock-tests/' . $test['slug'] . '/attempt') ?>" class="btn btn-primary btn-block btn-lg"><i class="fas fa-play"></i> Start Test Now</a>
                    <?php else: ?>
                    <div style="margin-bottom:12px;">
                        <span style="font-size:1.25rem; font-weight:700; color:var(--primary);">₹<?= number_format($test['price']) ?></span>
                        <?php if (isset($hasPaid) && $hasPaid): ?>
                        <span class="badge badge-success" style="margin-left:8px;">Purchased</span>
                        <?php endif; ?>
                    </div>
                    <?php if (isset($hasPaid) && $hasPaid): ?>
                    <a href="<?= base_url('mock-tests/' . $test['slug'] . '/attempt') ?>" class="btn btn-primary btn-block btn-lg"><i class="fas fa-play"></i> Start Test Now</a>
                    <?php else: ?>
                    <button class="btn btn-primary btn-block btn-lg" id="buy-now-btn" data-item="mock_test" data-id="<?= $test['id'] ?>"><i class="fas fa-shopping-cart"></i> Buy Now — ₹<?= number_format($test['price']) ?></button>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>