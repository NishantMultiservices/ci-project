<section class="section" style="padding-top: 120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Mock Tests']]]) ?>
        <div class="section-header animate-on-scroll" style="text-align: left; margin: 0 0 32px;">
            <h1 class="section-title">Mock <span class="gradient-text">Tests</span></h1>
            <p class="section-desc">Practice with timed mock tests for competitive exams. Get instant results with detailed analysis.</p>
        </div>
        <?php if (!empty($mockTests)): ?>
        <div class="grid-3">
            <?php foreach ($mockTests as $t): ?>
            <div class="glass-card animate-on-scroll" style="padding: 0; overflow: hidden;">
                <div style="background: linear-gradient(135deg, #6366f1, #8b5cf6); padding: 24px; color: white;">
                    <div style="font-size: 2rem; margin-bottom: 8px;"><i class="fas fa-clipboard-list"></i></div>
                    <div style="display:flex; align-items:flex-start; justify-content:space-between;">
                        <div><h3 style="font-size: 1.125rem; font-weight: 700; margin-bottom: 4px;"><?= esc($t['title']) ?></h3>
                        <?php if ($t['category']): ?><span style="display: inline-block; background: rgba(255,255,255,0.2); padding: 2px 10px; border-radius: 20px; font-size: 0.75rem;"><?= esc($t['category']) ?></span><?php endif; ?></div>
                        <span style="background:<?= $t['is_free'] ? 'rgba(16,185,129,0.9)' : 'rgba(245,158,11,0.9)' ?>; color:white; padding:3px 10px; border-radius:20px; font-size:0.7rem; font-weight:600; white-space:nowrap;"><?= $t['is_free'] ? 'Free' : '₹' . number_format($t['price']) ?></span>
                    </div>
                </div>
                <div style="padding: 20px;">
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; margin-bottom: 16px; text-align: center;">
                        <div><span style="display: block; font-size: 1.25rem; font-weight: 700; color: var(--primary);"><?= $t['total_questions'] ?></span><span style="font-size: 0.75rem; color: var(--gray-500);">Questions</span></div>
                        <div><span style="display: block; font-size: 1.25rem; font-weight: 700; color: var(--primary);"><?= $t['duration_minutes'] ?>m</span><span style="font-size: 0.75rem; color: var(--gray-500);">Duration</span></div>
                        <div><span style="display: block; font-size: 1.25rem; font-weight: 700; color: var(--primary);"><?= $t['total_marks'] ?></span><span style="font-size: 0.75rem; color: var(--gray-500);">Marks</span></div>
                    </div>
                    <p style="font-size: 0.875rem; color: var(--gray-600); margin-bottom: 16px; line-height: 1.6;"><?= esc(truncate_text($t['description'] ?? '', 120)) ?></p>
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-size: 0.75rem; color: var(--gray-400);"><i class="fas fa-users"></i> <?= number_format($t['attempts_count'] ?? 0) ?> attempts</span>
                        <a href="<?= base_url('mock-tests/' . $t['slug']) ?>" class="btn btn-primary btn-sm"><i class="fas fa-play"></i> Start Test</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div style="text-align: center; padding: 80px 20px;">
            <i class="fas fa-clipboard-list" style="font-size: 3rem; color: var(--gray-300); margin-bottom: 16px; display: block;"></i>
            <h3 style="margin-bottom: 8px;">No Mock Tests Available</h3>
            <p style="color: var(--gray-500);">Check back soon for new practice tests.</p>
        </div>
        <?php endif; ?>
    </div>
</section>