<section class="section" style="padding-top: 100px;">
    <div class="container">
        <form id="mockTestForm" action="<?= base_url('mock-tests/submit') ?>" method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="attempt_id" value="<?= $attemptId ?>">
            <div style="display: grid; grid-template-columns: 1fr 280px; gap: 24px;">
                <div>
                    <div class="glass-card" style="padding: 24px; margin-bottom: 16px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; flex-wrap: wrap; gap: 12px;">
                            <h2 style="font-size: 1.125rem; font-weight: 700;"><?= esc($test['title']) ?></h2>
                            <div style="display: flex; align-items: center; gap: 16px;">
                                <span style="font-size: 0.875rem; color: var(--gray-500);"><i class="fas fa-clock"></i> Time Left: <strong id="timer" style="color: var(--primary);"><?= sprintf('%02d:%02d', $test['duration_minutes'], 0) ?></strong></span>
                            </div>
                        </div>
                    </div>
                    <?php $qNum = 0; ?>
                    <?php foreach ($questions as $q): $qNum++; ?>
                    <div class="glass-card" style="padding: 24px; margin-bottom: 16px;" id="q-<?= $q['id'] ?>">
                        <div style="display: flex; gap: 16px;">
                            <div style="width: 32px; height: 32px; border-radius: 50%; background: var(--primary); color: white; display: flex; align-items: center; justify-content: center; font-size: 0.813rem; font-weight: 600; flex-shrink: 0;"><?= $qNum ?></div>
                            <div style="flex: 1;">
                                <p style="font-weight: 500; margin-bottom: 16px; line-height: 1.6;"><?= esc($q['question']) ?></p>
                                <?php $optIndex = 0; ?>
                                <?php foreach (($q['options'] ?? []) as $key => $value): $optIndex++; ?>
                                <?php if (empty($value)) continue; ?>
                                <label style="display: flex; align-items: center; gap: 12px; padding: 10px 14px; margin-bottom: 8px; border: 2px solid var(--gray-200); border-radius: 10px; cursor: pointer; transition: all 0.2s; font-size: 0.938rem;" class="option-label">
                                    <input type="radio" name="answers[<?= $q['id'] ?>]" value="<?= $key ?>" style="accent-color: var(--primary); width: 18px; height: 18px;">
                                    <span><?= esc($value) ?></span>
                                </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <div style="text-align: center; margin-top: 24px;">
                        <button type="submit" class="btn btn-primary btn-lg" onclick="return confirm('Are you sure you want to submit the test?')"><i class="fas fa-paper-plane"></i> Submit Test</button>
                    </div>
                </div>
                <div>
                    <div class="glass-card" style="padding: 20px; position: sticky; top: 100px;">
                        <h3 style="font-size: 0.938rem; font-weight: 700; margin-bottom: 12px;">Question Palette</h3>
                        <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 6px; margin-bottom: 16px;">
                            <?php $qIdx = 0; ?>
                            <?php foreach ($questions as $q): $qIdx++; ?>
                            <a href="#q-<?= $q['id'] ?>" class="q-palette-item" data-qid="<?= $q['id'] ?>" style="display: flex; align-items: center; justify-content: center; width: 100%; aspect-ratio: 1; border-radius: 8px; font-size: 0.75rem; font-weight: 600; background: var(--gray-100); color: var(--gray-600); text-decoration: none; transition: all 0.2s;" onclick="highlightQuestion(this)"><?= $qIdx ?></a>
                            <?php endforeach; ?>
                        </div>
                        <div style="font-size: 0.75rem; color: var(--gray-500);">
                            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;"><span style="width: 12px; height: 12px; border-radius: 3px; background: var(--gray-100); display: inline-block;"></span> Unanswered</div>
                            <div style="display: flex; align-items: center; gap: 8px;"><span style="width: 12px; height: 12px; border-radius: 3px; background: var(--primary); display: inline-block;"></span> Answered</div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>
<style>
.option-label:has(input:checked) { border-color: var(--primary); background: rgba(99, 102, 241, 0.05); }
.q-palette-item.answered { background: var(--primary); color: white; }
@media (max-width: 992px) { [style*="grid-template-columns: 1fr 280px"] { grid-template-columns: 1fr !important; } }
</style>
<script>
(function() {
    var duration = <?= $test['duration_minutes'] ?> * 60;
    var timerEl = document.getElementById('timer');
    var form = document.getElementById('mockTestForm');
    var radios = form.querySelectorAll('input[type="radio"]');

    function updateTimer() {
        if (duration <= 0) {
            timerEl.textContent = '00:00';
            form.submit();
            return;
        }
        duration--;
        var m = Math.floor(duration / 60);
        var s = duration % 60;
        timerEl.textContent = String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
    }

    function updatePalette() {
        var answered = {};
        radios.forEach(function(r) { if (r.checked) answered[r.name] = true; });
        document.querySelectorAll('.q-palette-item').forEach(function(item) {
            var qid = item.dataset.qid;
            if (answered['answers[' + qid + ']']) item.classList.add('answered');
            else item.classList.remove('answered');
        });
    }

    radios.forEach(function(r) { r.addEventListener('change', updatePalette); });
    setInterval(updateTimer, 1000);
    updatePalette();
})();
function highlightQuestion(el) {
    document.querySelectorAll('.q-palette-item').forEach(function(i) { i.style.outline = 'none'; });
    el.style.outline = '2px solid var(--primary)';
}
</script>