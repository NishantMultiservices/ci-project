<section class="section" style="padding-top: 120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Mock Tests', 'url' => base_url('mock-tests')], ['name' => 'Result']]]) ?>
        <?php $passed = $attempt['score'] >= $attempt['passing_marks']; ?>
        <div class="glass-card" style="padding: 40px; text-align: center; margin-bottom: 32px;">
            <div style="font-size: 4rem; margin-bottom: 16px; color: <?= $passed ? '#10b981' : '#ef4444' ?>;">
                <i class="fas fa-<?= $passed ? 'trophy' : 'times-circle' ?>"></i>
            </div>
            <h1 style="font-size: 1.75rem; font-weight: 700; margin-bottom: 8px;"><?= $passed ? 'Congratulations!' : 'Better Luck Next Time!' ?></h1>
            <p style="color: var(--gray-500); margin-bottom: 24px;"><?= esc($attempt['title']) ?></p>
            <div style="display: flex; justify-content: center; gap: 40px; flex-wrap: wrap; margin-bottom: 24px;">
                <div><span style="display: block; font-size: 2.5rem; font-weight: 800; color: var(--primary);"><?= $attempt['score'] ?></span><span style="font-size: 0.875rem; color: var(--gray-500);">Score (out of <?= $attempt['total_marks'] ?>)</span></div>
                <div><span style="display: block; font-size: 2.5rem; font-weight: 800; color: #10b981;"><?= $attempt['correct_count'] ?></span><span style="font-size: 0.875rem; color: var(--gray-500);">Correct</span></div>
                <div><span style="display: block; font-size: 2.5rem; font-weight: 800; color: #ef4444;"><?= $attempt['incorrect_count'] ?></span><span style="font-size: 0.875rem; color: var(--gray-500);">Incorrect</span></div>
                <div><span style="display: block; font-size: 2.5rem; font-weight: 800; color: var(--gray-400);"><?= $attempt['unanswered_count'] ?></span><span style="font-size: 0.875rem; color: var(--gray-500);">Unanswered</span></div>
            </div>
            <?php $pct = $attempt['total_marks'] > 0 ? round(($attempt['score'] / $attempt['total_marks']) * 100) : 0; ?>
            <div style="max-width: 400px; margin: 0 auto 24px;">
                <div style="background: var(--gray-200); border-radius: 20px; height: 12px; overflow: hidden;">
                    <div style="height: 100%; border-radius: 20px; background: <?= $passed ? 'linear-gradient(90deg, #10b981, #059669)' : 'linear-gradient(90deg, #ef4444, #dc2626)' ?>; width: <?= $pct ?>%;"></div>
                </div>
                <span style="font-size: 0.875rem; color: var(--gray-500); margin-top: 6px; display: block;"><?= $pct ?>% Score (Passing: <?= $attempt['passing_marks'] ?> marks)</span>
            </div>
            <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
                <a href="<?= base_url('mock-tests') ?>" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back to Tests</a>
            </div>
        </div>
        <?php if (!empty($answers)): ?>
        <h2 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 20px;">Detailed <span class="gradient-text">Review</span></h2>
        <?php $idx = 0; ?>
        <?php foreach ($answers as $a): $idx++; ?>
        <div class="glass-card" style="padding: 20px; margin-bottom: 12px; border-left: 4px solid <?= $a['is_correct'] ? '#10b981' : ($a['selected_answer'] ? '#ef4444' : 'var(--gray-300)') ?>;">
            <div style="display: flex; gap: 12px;">
                <span style="width: 28px; height: 28px; border-radius: 50%; background: var(--gray-100); display: flex; align-items: center; justify-content: center; font-size: 0.75rem; font-weight: 600; flex-shrink: 0;"><?= $idx ?></span>
                <div style="flex: 1;">
                    <p style="font-weight: 500; margin-bottom: 12px;"><?= esc($a['question']) ?></p>
                    <?php $options = is_string($a['options']) ? json_decode($a['options'], true) : $a['options']; ?>
                    <?php foreach (($options ?? []) as $key => $value): ?>
                    <?php if (empty($value)) continue; ?>
                    <div style="padding: 8px 12px; margin-bottom: 6px; border-radius: 8px; font-size: 0.875rem; border: 2px solid var(--gray-200); <?= $key === $a['correct_answer'] ? 'border-color: #10b981; background: rgba(16,185,129,0.05);' : ($key === $a['selected_answer'] && $key !== $a['correct_answer'] ? 'border-color: #ef4444; background: rgba(239,68,68,0.05);' : '') ?>">
                        <?= esc($value) ?>
                        <?php if ($key === $a['correct_answer']): ?><i class="fas fa-check-circle" style="color: #10b981; margin-left: 8px;"></i><?php endif; ?>
                        <?php if ($key === $a['selected_answer'] && $key !== $a['correct_answer']): ?><i class="fas fa-times-circle" style="color: #ef4444; margin-left: 8px;"></i><?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                    <div style="margin-top: 8px; font-size: 0.813rem; color: var(--gray-500);">
                        <?php if ($a['is_correct']): ?><span style="color: #10b981;"><i class="fas fa-check"></i> Correct (+<?= $a['marks_obtained'] ?> marks)</span>
                        <?php elseif ($a['selected_answer']): ?><span style="color: #ef4444;"><i class="fas fa-times"></i> Incorrect (<?= $a['marks_obtained'] >= 0 ? '+' : '' ?><?= $a['marks_obtained'] ?> marks)</span>
                        <?php else: ?><span style="color: var(--gray-400);"><i class="fas fa-minus"></i> Not Answered (0 marks)</span><?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
</section>