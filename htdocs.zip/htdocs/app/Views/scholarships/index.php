<section class="section" style="padding-top:120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Scholarships']]]) ?>
        <div class="section-header animate-on-scroll" style="text-align:left; margin:0 0 32px;">
            <h1 class="section-title">Scholarships & <span class="gradient-text">Financial Aid</span></h1>
            <p class="section-desc">Government, private, and minority scholarships for students.</p>
        </div>
        <div style="display:flex; gap:8px; margin-bottom:24px; flex-wrap:wrap;">
            <a href="<?= base_url('scholarships') ?>" class="btn btn-sm <?= !service('request')->getGet('type') ? 'btn-primary' : 'btn-secondary' ?>">All</a>
            <a href="<?= base_url('scholarships?type=government') ?>" class="btn btn-sm <?= service('request')->getGet('type') === 'government' ? 'btn-primary' : 'btn-secondary' ?>">Government</a>
            <a href="<?= base_url('scholarships?type=private') ?>" class="btn btn-sm <?= service('request')->getGet('type') === 'private' ? 'btn-primary' : 'btn-secondary' ?>">Private</a>
            <a href="<?= base_url('scholarships?type=minority') ?>" class="btn btn-sm <?= service('request')->getGet('type') === 'minority' ? 'btn-primary' : 'btn-secondary' ?>">Minority</a>
        </div>
        <div class="grid-3">
            <?php foreach ($scholarships as $s): ?>
            <div class="glass-card" style="padding:24px;">
                <div style="display:flex; align-items:flex-start; gap:16px;">
                    <div style="width:52px; height:52px; border-radius:12px; background:linear-gradient(135deg,#f59e0b,#ef4444); display:flex; align-items:center; justify-content:center; color:white; flex-shrink:0;"><i class="fas fa-award"></i></div>
                    <div style="flex:1;">
                        <h3 style="font-size:1rem; font-weight:600; margin-bottom:4px;"><a href="<?= base_url('scholarships/' . $s['id']) ?>" style="color:var(--gray-900); text-decoration:none;"><?= esc($s['name']) ?></a></h3>
                        <p style="font-size:0.813rem; color:var(--gray-500);"><?= esc($s['provider_name']) ?> &middot; <span class="job-tag"><?= ucfirst($s['type']) ?></span></p>
                        <div style="margin-top:12px; display:flex; align-items:center; justify-content:space-between;">
                            <span style="font-weight:600; color:var(--success);"><?= esc($s['amount_text'] ?? '₹' . number_format($s['amount'] ?? 0)) ?></span>
                            <a href="<?= base_url('scholarships/' . $s['id']) ?>" class="btn btn-primary btn-sm">Details</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
