<section class="section" style="padding-top:120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Courses']]]) ?>
        <div class="section-header animate-on-scroll" style="text-align:left; margin:0 0 32px;">
            <h1 class="section-title">Skill Development <span class="gradient-text">Courses</span></h1>
            <p class="section-desc">Upskill with industry-relevant courses. Learn at your own pace.</p>
        </div>
        <div class="grid-4">
            <?php foreach ($courses as $course): ?>
            <div class="course-card">
                <div class="course-thumb" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);">
                    <i class="fas fa-graduation-cap"></i>
                    <span class="course-badge <?= $course['is_free'] ? 'free' : 'premium' ?>"><?= $course['is_free'] ? 'Free' : '₹' . number_format($course['price']) ?></span>
                </div>
                <div class="course-body">
                    <h3><?= esc($course['title']) ?></h3>
                    <div class="course-instructor"><i class="fas fa-user-tie"></i> <?= esc($course['instructor_name'] ?? 'Expert Instructor') ?></div>
                    <p style="font-size:0.813rem;color:var(--gray-500);margin-bottom:12px;"><?= esc(truncate_text($course['short_description'] ?? '', 80)) ?></p>
                    <div class="course-meta">
                        <span class="course-rating"><i class="fas fa-star"></i> <?= $course['rating'] ?? '4.5' ?></span>
                        <span class="course-students"><i class="fas fa-users"></i> <?= number_format($course['total_enrolled'] ?? 0) ?></span>
                        <button class="bookmark-btn btn btn-sm" style="background:rgba(245,158,11,0.12); color:#d97706; border:none;" data-id="<?= $course['id'] ?>" data-type="course"><i class="far fa-heart"></i></button>
                        <a href="<?= base_url('courses/' . $course['id']) ?>" class="btn btn-primary btn-sm">Enroll</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
