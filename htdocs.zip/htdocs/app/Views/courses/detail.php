<section class="section" style="padding-top:120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Courses', 'url' => base_url('courses')], ['name' => $course['title']]]]) ?>

        <div style="display:grid; grid-template-columns:2fr 1fr; gap:32px;">
            <div>
                <div class="glass-card" style="padding:32px;">
                    <div style="display:flex; align-items:flex-start; gap:20px; margin-bottom:24px; flex-wrap:wrap;">
                        <div style="width:72px; height:72px; border-radius:16px; background:linear-gradient(135deg,#6366f1,#8b5cf6); display:flex; align-items:center; justify-content:center; font-size:1.5rem; color:white; flex-shrink:0;"><i class="fas fa-graduation-cap"></i></div>
                        <div style="flex:1;">
                            <h1 style="font-size:1.5rem; font-weight:700; margin-bottom:4px;"><?= esc($course['title']) ?></h1>
                            <p style="font-size:1rem; color:var(--gray-500);"><i class="fas fa-user-tie"></i> <?= esc($course['instructor_name'] ?? 'Expert Instructor') ?></p>
                            <div style="display:flex; gap:16px; margin-top:12px; flex-wrap:wrap;">
                                <span style="display:flex; align-items:center; gap:6px; font-size:0.875rem; color:var(--gray-500);"><i class="fas fa-star" style="color:#f59e0b;"></i> <?= $course['rating'] ?? '4.5' ?> Rating</span>
                                <span style="display:flex; align-items:center; gap:6px; font-size:0.875rem; color:var(--gray-500);"><i class="fas fa-users" style="color:var(--primary);"></i> <?= number_format($course['total_enrolled'] ?? 0) ?> Enrolled</span>
                                <span style="display:flex; align-items:center; gap:6px; font-size:0.875rem; color:var(--gray-500);"><i class="fas fa-clock" style="color:var(--primary);"></i> <?= esc($course['duration'] ?? 'Self-paced') ?></span>
                                <?php if ($course['level']): ?><span style="display:flex; align-items:center; gap:6px; font-size:0.875rem; color:var(--gray-500);"><i class="fas fa-signal" style="color:var(--primary);"></i> <?= ucfirst($course['level']) ?></span><?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div style="display:flex; gap:12px; margin-bottom:32px; flex-wrap:wrap;">
                        <span class="badge badge-<?= $course['is_free'] ? 'success' : 'warning' ?>" style="font-size:0.813rem; padding:6px 16px;"><?= $course['is_free'] ? 'Free' : '₹' . number_format($course['price']) ?></span>
                        <?php if ($course['total_lessons']): ?><span class="badge badge-info" style="font-size:0.813rem; padding:6px 16px;"><?= $course['total_lessons'] ?> Lessons</span><?php endif; ?>
                        <?php if ($course['total_hours']): ?><span class="badge badge-secondary" style="font-size:0.813rem; padding:6px 16px;"><?= $course['total_hours'] ?> Hours</span><?php endif; ?>
                        <span class="badge badge-secondary" style="font-size:0.813rem; padding:6px 16px;"><i class="fas fa-eye"></i> <?= number_format($course['views_count'] ?? 0) ?> Views</span>
                    </div>

                    <?php if ($course['short_description']): ?>
                    <div style="margin-bottom:24px;">
                        <h3 style="font-size:1.125rem; margin-bottom:8px;">About This Course</h3>
                        <p style="color:var(--gray-600); line-height:1.7;"><?= esc($course['short_description']) ?></p>
                    </div>
                    <?php endif; ?>

                    <?php if ($course['description']): ?>
                    <div style="margin-bottom:24px;">
                        <h3 style="font-size:1.125rem; margin-bottom:8px;">Full Description</h3>
                        <div style="color:var(--gray-600); line-height:1.7;"><?= $course['description'] ?></div>
                    </div>
                    <?php endif; ?>

                    <?php if ($course['what_you_learn']): ?>
                    <div style="margin-bottom:24px;">
                        <h3 style="font-size:1.125rem; margin-bottom:12px;"><i class="fas fa-check-circle" style="color:var(--success);"></i> What You'll Learn</h3>
                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;"><?php $items = is_string($course['what_you_learn']) ? explode("\n", $course['what_you_learn']) : $course['what_you_learn']; ?><?php foreach ($items as $item): if (trim($item)): ?><div style="display:flex; align-items:center; gap:8px; font-size:0.875rem; color:var(--gray-600);"><i class="fas fa-check" style="color:var(--success); font-size:0.75rem;"></i> <?= esc(trim($item)) ?></div><?php endif; endforeach; ?></div>
                    </div>
                    <?php endif; ?>

                    <?php if ($course['topics_covered']): ?>
                    <div style="margin-bottom:24px;">
                        <h3 style="font-size:1.125rem; margin-bottom:12px;"><i class="fas fa-list"></i> Topics Covered</h3>
                        <div style="display:flex; flex-wrap:wrap; gap:8px;"><?php $topics = is_string($course['topics_covered']) ? explode(",", $course['topics_covered']) : $course['topics_covered']; ?><?php foreach ($topics as $t): if (trim($t)): ?><span style="padding:4px 14px; background:rgba(99,102,241,0.08); color:var(--primary); border-radius:20px; font-size:0.813rem;"><?= esc(trim($t)) ?></span><?php endif; endforeach; ?></div>
                    </div>
                    <?php endif; ?>

                    <?php if ($course['requirements']): ?>
                    <div style="margin-bottom:24px; padding:20px; background:rgba(245,158,11,0.06); border-radius:12px; border:1px solid rgba(245,158,11,0.15);">
                        <h3 style="font-size:1.125rem; margin-bottom:8px; color:var(--warning);"><i class="fas fa-exclamation-triangle"></i> Requirements</h3>
                        <div style="font-size:0.875rem; color:var(--gray-600); line-height:1.7;"><?= esc($course['requirements']) ?></div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <div style="position:sticky; top:100px; align-self:start;">
                <div class="glass-card" style="padding:24px; text-align:center;">
                    <?php if ($course['thumbnail']): ?>
                    <img src="<?= base_url($course['thumbnail']) ?>" alt="<?= esc($course['title']) ?>" style="width:100%; border-radius:12px; margin-bottom:16px;">
                    <?php else: ?>
                    <div style="width:100%; height:180px; border-radius:12px; background:linear-gradient(135deg,#6366f1,#8b5cf6); display:flex; align-items:center; justify-content:center; font-size:3rem; color:rgba(255,255,255,0.5); margin-bottom:16px;"><i class="fas fa-graduation-cap"></i></div>
                    <?php endif; ?>

                    <div style="font-size:2rem; font-weight:800; margin-bottom:8px;">
                        <?php if ($course['is_free']): ?><span style="color:var(--success);">Free</span><?php else: ?><span>₹<?= number_format($course['price']) ?></span><?php endif; ?>
                    </div>

                    <?php if ($course['instructor_name']): ?>
                    <div style="display:flex; align-items:center; gap:12px; padding:16px 0; border-top:1px solid var(--gray-200); margin-top:16px; text-align:left;">
                        <div style="width:44px; height:44px; border-radius:50%; background:linear-gradient(135deg,#6366f1,#8b5cf6); display:flex; align-items:center; justify-content:center; color:white; font-weight:700; flex-shrink:0;"><?= strtoupper(substr($course['instructor_name'], 0, 2)) ?></div>
                        <div><p style="font-weight:600; font-size:0.875rem;"><?= esc($course['instructor_name']) ?></p><p style="font-size:0.75rem; color:var(--gray-500);"><?= esc($course['instructor_bio'] ?? 'Instructor') ?></p></div>
                    </div>
                    <?php endif; ?>

                    <div style="display:flex; flex-direction:column; gap:10px; margin-top:20px;">
                        <?php if (is_logged_in()): ?>
                            <?php if ($isEnrolled): ?>
                                <a href="<?= base_url('courses/learn/' . $course['id']) ?>" class="btn btn-success" style="width:100%; padding:14px; text-decoration:none; text-align:center;"><i class="fas fa-play-circle"></i> Go to Course</a>
                                <form action="<?= base_url('courses/unenroll/' . $course['id']) ?>" method="post" style="display:block;"><?= csrf_field() ?><button type="submit" class="btn btn-secondary" style="width:100%; padding:14px;"><i class="fas fa-times"></i> Unenroll</button></form>
                            <?php elseif ($course['is_free']): ?>
                                <form action="<?= base_url('courses/enroll/' . $course['id']) ?>" method="post" style="display:block;"><?= csrf_field() ?><button type="submit" class="btn btn-primary" style="width:100%; padding:14px;"><i class="fas fa-graduation-cap"></i> Enroll Now — Free</button></form>
                            <?php elseif (isset($hasPaidCourse) && $hasPaidCourse): ?>
                                <form action="<?= base_url('courses/enroll/' . $course['id']) ?>" method="post" style="display:block;"><?= csrf_field() ?><button type="submit" class="btn btn-success" style="width:100%; padding:14px;"><i class="fas fa-graduation-cap"></i> Enroll Now (Purchased)</button></form>
                            <?php else: ?>
                                <button class="btn btn-primary" style="width:100%; padding:14px;" id="buy-course-btn" data-item="course" data-id="<?= $course['id'] ?>"><i class="fas fa-shopping-cart"></i> Buy Now — ₹<?= number_format($course['price']) ?></button>
                            <?php endif; ?>
                            <button class="btn btn-secondary bookmark-btn" style="width:100%; padding:14px;" data-id="<?= $course['id'] ?>" data-type="course"><i class="<?= $isBookmarked ? 'fas' : 'far' ?> fa-heart"></i> <span><?= $isBookmarked ? 'Remove from Wishlist' : 'Add to Wishlist' ?></span></button>
                        <?php else: ?>
                            <a href="<?= base_url('login') ?>" class="btn btn-primary" style="width:100%; padding:14px; text-decoration:none; text-align:center;"><i class="fas fa-graduation-cap"></i> Login to Enroll</a>
                        <?php endif; ?>
                    </div>

                    <div style="margin-top:20px; font-size:0.813rem; color:var(--gray-500); text-align:left;">
                        <div style="display:flex; align-items:center; gap:8px; padding:6px 0;"><i class="fas fa-infinity" style="color:var(--primary); width:18px;"></i> Full lifetime access</div>
                        <div style="display:flex; align-items:center; gap:8px; padding:6px 0;"><i class="fas fa-mobile-alt" style="color:var(--primary); width:18px;"></i> Access on mobile & TV</div>
                        <div style="display:flex; align-items:center; gap:8px; padding:6px 0;"><i class="fas fa-certificate" style="color:var(--primary); width:18px;"></i> Certificate of completion</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>