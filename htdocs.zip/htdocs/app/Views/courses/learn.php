<section class="section" style="padding-top:100px;">
    <div class="container">
        <div style="display:flex; align-items:center; gap:12px; margin-bottom:24px;">
            <a href="<?= base_url('dashboard/my-courses') ?>" style="color:var(--gray-500); text-decoration:none; font-size:0.875rem;"><i class="fas fa-arrow-left"></i> My Courses</a>
            <span style="color:var(--gray-300);">/</span>
            <span style="font-size:0.875rem; color:var(--gray-600);"><?= esc($course['title']) ?></span>
        </div>

        <div style="display:grid; grid-template-columns:320px 1fr; gap:24px; align-items:start;">
            <div class="glass-card" style="padding:0; overflow:hidden;">
                <div style="padding:16px; border-bottom:1px solid var(--gray-200);">
                    <h3 style="font-size:0.938rem; font-weight:700;">Course Content</h3>
                    <p style="font-size:0.75rem; color:var(--gray-500);"><?= count($completedLessonIds) ?>/<?= count($lessons) ?> lessons completed</p>
                </div>
                <div style="max-height:500px; overflow-y:auto;">
                    <?php if (!empty($lessons)): ?>
                    <?php foreach ($lessons as $i => $l):
                    $isCompleted = in_array($l['id'], $completedLessonIds);
                    ?>
                    <a href="<?= base_url('courses/learn/' . $course['id'] . '?lesson=' . $l['id']) ?>" style="display:flex; align-items:center; gap:10px; padding:12px 16px; text-decoration:none; color:inherit; border-left:3px solid <?= $currentLesson && $currentLesson['id'] == $l['id'] ? 'var(--primary)' : 'transparent' ?>; background:<?= $currentLesson && $currentLesson['id'] == $l['id'] ? 'rgba(99,102,241,0.04)' : 'transparent' ?>; transition:background 0.2s;">
                        <div style="width:28px; height:28px; border-radius:50%; background:<?= $isCompleted ? 'var(--success)' : ($currentLesson && $currentLesson['id'] == $l['id'] ? 'var(--primary)' : 'var(--gray-200)') ?>; display:flex; align-items:center; justify-content:center; font-size:0.7rem; font-weight:700; color:white; flex-shrink:0;"><?= $isCompleted ? '<i class="fas fa-check" style="font-size:0.6rem;"></i>' : ($i + 1) ?></div>
                        <div style="flex:1; min-width:0;">
                            <p style="font-size:0.813rem; font-weight:<?= $currentLesson && $currentLesson['id'] == $l['id'] ? '600' : '500' ?>; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;"><?= esc($l['title']) ?></p>
                            <p style="font-size:0.688rem; color:var(--gray-500);">
                                <i class="fas fa-<?= $l['content_type'] === 'video' ? 'play-circle' : ($l['content_type'] === 'text' ? 'file-alt' : ($l['content_type'] === 'quiz' ? 'question-circle' : 'tasks')) ?>"></i>
                                <?= ucfirst($l['content_type']) ?>
                                <?php if ($l['duration']): ?> &middot; <?= $l['duration'] ?> min<?php endif; ?>
                            </p>
                        </div>
                        <?php if ($isCompleted): ?>
                        <i class="fas fa-check-circle" style="font-size:0.75rem; color:var(--success);"></i>
                        <?php elseif ($currentLesson && $currentLesson['id'] == $l['id']): ?>
                        <i class="fas fa-play" style="font-size:0.625rem; color:var(--primary);"></i>
                        <?php endif; ?>
                    </a>
                    <?php endforeach; ?>
                    <?php else: ?>
                    <div style="padding:32px; text-align:center; color:var(--gray-400); font-size:0.875rem;">No lessons added yet.</div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="glass-card" style="padding:0; overflow:hidden;">
                <?php if ($currentLesson): ?>
                <?php if ($currentLesson['content_type'] === 'video' && $currentLesson['video_url']): ?>
                <div style="position:relative; padding-bottom:56.25%; background:#000;">
                    <?php
                    $videoUrl = $currentLesson['video_url'];
                    if (str_contains($videoUrl, 'youtube.com') || str_contains($videoUrl, 'youtu.be')) {
                        preg_match('/(?:youtube\.com\/(?:watch\?v=|embed\/|v\/)|youtu\.be\/)([a-zA-Z0-9_-]+)/', $videoUrl, $matches);
                        $ytId = $matches[1] ?? '';
                        if ($ytId): ?>
                    <iframe style="position:absolute; top:0; left:0; width:100%; height:100%; border:none;" src="https://www.youtube.com/embed/<?= $ytId ?>" allowfullscreen></iframe>
                        <?php endif;
                    } else { ?>
                    <video style="position:absolute; top:0; left:0; width:100%; height:100%;" controls>
                        <source src="<?= base_url($videoUrl) ?>" type="video/mp4">
                    </video>
                    <?php } ?>
                </div>
                <?php endif; ?>

                <div style="padding:24px;">
                    <h2 style="font-size:1.125rem; font-weight:700; margin-bottom:8px;"><?= esc($currentLesson['title']) ?></h2>
                    <div style="display:flex; gap:12px; margin-bottom:16px; font-size:0.75rem; color:var(--gray-500);">
                        <span><i class="fas fa-<?= $currentLesson['content_type'] === 'video' ? 'play-circle' : ($currentLesson['content_type'] === 'quiz' ? 'question-circle' : ($currentLesson['content_type'] === 'assignment' ? 'tasks' : 'file-alt')) ?>"></i> <?= ucfirst($currentLesson['content_type']) ?></span>
                        <?php if ($currentLesson['duration']): ?><span><i class="fas fa-clock"></i> <?= $currentLesson['duration'] ?> min</span><?php endif; ?>
                    </div>

                    <?php if ($currentLesson['content_type'] === 'quiz'): ?>
                    <div id="quiz-container">
                        <?php if (!empty($quizQuestions)): ?>
                        <form id="quiz-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="lesson_id" value="<?= $currentLesson['id'] ?>">
                            <?php $qIndex = 0; ?>
                            <?php $savedMap = []; foreach ($quizAnswers as $sa) { $savedMap[$sa['question_id']] = $sa; } ?>
                            <?php foreach ($quizQuestions as $q): $qIndex++; ?>
                            <div class="quiz-question" style="margin-bottom:20px; padding:16px; background:var(--gray-50); border-radius:8px; border:1px solid var(--gray-200);">
                                <p style="font-weight:600; margin-bottom:10px; font-size:0.938rem;"><?= $qIndex ?>. <?= esc($q['question']) ?> <span style="font-weight:400; color:var(--gray-500); font-size:0.75rem;">(<?= $q['marks'] ?> mark<?= $q['marks'] > 1 ? 's' : '' ?>)</span></p>
                                <?php $selected = isset($savedMap[$q['id']]) ? $savedMap[$q['id']]['selected_option'] : ''; ?>
                                <?php $disabled = $quizAttempt ? 'disabled' : ''; ?>
                                <?php $showCorrect = $quizAttempt ? true : false; ?>
                                <?php foreach (['a','b','c','d'] as $opt): $optVal = $q['option_'.$opt]; ?>
                                <label style="display:flex; align-items:center; gap:8px; padding:6px 10px; margin:4px 0; border-radius:6px; background:<?= $showCorrect && $q['correct_option'] === $opt ? 'rgba(16,185,129,0.1)' : ($selected === $opt && $selected !== $q['correct_option'] ? 'rgba(239,68,68,0.1)' : 'transparent') ?>; border:1px solid <?= $showCorrect && $q['correct_option'] === $opt ? 'var(--success)' : ($selected === $opt && $selected !== $q['correct_option'] ? '#ef4444' : 'transparent') ?>; cursor:<?= $disabled ? 'default' : 'pointer' ?>;">
                                    <input type="radio" name="q_<?= $q['id'] ?>" value="<?= $opt ?>" <?= $selected === $opt ? 'checked' : '' ?> <?= $disabled ?> required>
                                    <span style="font-size:0.875rem;"><?= esc($optVal) ?></span>
                                    <?php if ($showCorrect && $q['correct_option'] === $opt): ?>
                                    <i class="fas fa-check-circle" style="color:var(--success); font-size:0.75rem; margin-left:auto;"></i>
                                    <?php elseif ($showCorrect && $selected === $opt && $selected !== $q['correct_option']): ?>
                                    <i class="fas fa-times-circle" style="color:#ef4444; font-size:0.75rem; margin-left:auto;"></i>
                                    <?php endif; ?>
                                </label>
                                <?php endforeach; ?>
                            </div>
                            <?php endforeach; ?>
                            <?php if (!$quizAttempt): ?>
                            <button type="submit" class="btn btn-primary" id="quiz-submit-btn"><i class="fas fa-paper-plane"></i> Submit Quiz</button>
                            <?php else: ?>
                            <div style="padding:16px; background:rgba(16,185,129,0.06); border-radius:8px; text-align:center; margin-top:16px;">
                                <p style="font-weight:600; color:var(--success); font-size:1rem;"><i class="fas fa-check-circle"></i> Quiz Completed</p>
                                <p style="font-size:0.875rem; color:var(--gray-600);">Score: <?= $quizAttempt['obtained_marks'] ?> / <?= $quizAttempt['total_marks'] ?> (<?= $quizAttempt['correct_answers'] ?> / <?= $quizAttempt['total_questions'] ?> correct)</p>
                                <?php if ($quizAttempt['passed']): ?>
                                <span class="badge badge-success">Passed</span>
                                <?php else: ?>
                                <span class="badge badge-danger">Failed</span>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </form>
                        <?php else: ?>
                        <p style="color:var(--gray-400);">No questions configured for this quiz.</p>
                        <?php endif; ?>
                    </div>

                    <?php if ($quizAttempt): ?>
                    <div id="quiz-result" style="margin-top:16px;"></div>
                    <?php endif; ?>
                    <?php else: ?>
                    <div style="font-size:0.938rem; line-height:1.8; color:var(--gray-700);">
                        <?php if ($currentLesson['content_type'] === 'text' && $currentLesson['content']): ?>
                        <div><?= $currentLesson['content'] ?></div>
                        <?php elseif ($currentLesson['content_type'] === 'assignment' && $currentLesson['content']): ?>
                        <div><?= $currentLesson['content'] ?></div>
                        <?php elseif ($currentLesson['content_type'] === 'video' && !$currentLesson['video_url'] && $currentLesson['content']): ?>
                        <div><?= $currentLesson['content'] ?></div>
                        <?php elseif ($currentLesson['content_type'] === 'video' && $currentLesson['video_url']): ?>
                        <p style="color:var(--gray-500);">Watch the video above to continue learning.</p>
                        <?php else: ?>
                        <p style="color:var(--gray-400);">No content available for this lesson.</p>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <?php
                    $currentCompleted = in_array($currentLesson['id'], $completedLessonIds);
                    $isLastLesson = $lessons[count($lessons) - 1]['id'] == $currentLesson['id'];
                    $isQuiz = $currentLesson['content_type'] === 'quiz';
                    ?>

                    <div style="margin-top:24px; text-align:center;">
                        <?php if (!$currentCompleted): ?>
                        <?php if (!$isQuiz): ?>
                        <button class="btn btn-success mark-complete-btn" data-lesson="<?= $currentLesson['id'] ?>" data-course="<?= $course['id'] ?>"><i class="fas fa-check-circle"></i> Mark as Complete</button>
                        <?php endif; ?>
                        <?php else: ?>
                        <p style="font-size:0.813rem; color:var(--success);"><i class="fas fa-check-circle"></i> Lesson completed</p>
                        <?php endif; ?>
                    </div>

                    <div id="certificate-section" style="margin-top:16px; <?= $allCompleted && !$hasCertificate ? '' : 'display:none;' ?>">
                        <div style="padding:24px; background:linear-gradient(135deg,rgba(16,185,129,0.08),rgba(99,102,241,0.06)); border-radius:16px; border:1px solid rgba(16,185,129,0.2); text-align:center;">
                            <div style="width:56px; height:56px; border-radius:50%; background:linear-gradient(135deg,#fef3c7,#fde68a); border:2px solid #f59e0b; display:flex; align-items:center; justify-content:center; margin:0 auto 12px; font-size:1.3rem; color:#92400e;"><i class="fas fa-trophy"></i></div>
                            <p style="font-size:1rem; font-weight:700; color:#1e293b; margin-bottom:4px;">Congratulations!</p>
                            <p style="font-size:0.85rem; color:var(--gray-500); margin-bottom:16px;">You completed all lessons. Claim your certificate now.</p>
                            <form action="<?= base_url('courses/complete/' . $course['id']) ?>" method="post" style="display:inline-block;"><?= csrf_field() ?><button type="submit" class="btn btn-success"><i class="fas fa-certificate"></i> Get Certificate</button></form>
                        </div>
                    </div>

                    <?php if ($hasCertificate): ?>
                    <div style="margin-top:16px; padding:20px; background:linear-gradient(135deg,rgba(99,102,241,0.06),rgba(16,185,129,0.06)); border-radius:16px; border:1px solid rgba(99,102,241,0.15); text-align:center;">
                        <div style="width:48px; height:48px; border-radius:50%; background:linear-gradient(135deg,#6366f1,#8b5cf6); display:flex; align-items:center; justify-content:center; margin:0 auto 10px; font-size:1.1rem; color:white;"><i class="fas fa-certificate"></i></div>
                        <p style="font-weight:700; color:#1e293b; font-size:0.95rem; margin-bottom:4px;">Course Completed</p>
                        <p style="font-size:0.8rem; color:var(--gray-500); margin-bottom:14px;">Your certificate is ready for download.</p>
                        <a href="<?= base_url('certificates/view/' . $course['id']) ?>" class="btn btn-primary btn-sm"><i class="fas fa-certificate"></i> View Certificate</a>
                    </div>
                    <?php endif; ?>

                    <div style="display:flex; justify-content:space-between; margin-top:32px; padding-top:16px; border-top:1px solid var(--gray-200);">
                        <?php
                        $prevLesson = null;
                        $nextLesson = null;
                        for ($i = 0; $i < count($lessons); $i++) {
                            if ($lessons[$i]['id'] == $currentLesson['id']) {
                                if ($i > 0) $prevLesson = $lessons[$i - 1];
                                if ($i < count($lessons) - 1) $nextLesson = $lessons[$i + 1];
                                break;
                            }
                        }
                        ?>
                        <div>
                            <?php if ($prevLesson): ?>
                            <a href="<?= base_url('courses/learn/' . $course['id'] . '?lesson=' . $prevLesson['id']) ?>" class="btn btn-secondary"><i class="fas fa-chevron-left"></i> Previous</a>
                            <?php endif; ?>
                        </div>
                        <div>
                            <?php if ($nextLesson): ?>
                            <a href="<?= base_url('courses/learn/' . $course['id'] . '?lesson=' . $nextLesson['id']) ?>" class="btn btn-primary">Next <i class="fas fa-chevron-right"></i></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div style="padding:60px; text-align:center;">
                    <i class="fas fa-book-open" style="font-size:3rem; color:var(--gray-300); margin-bottom:16px; display:block;"></i>
                    <p style="color:var(--gray-500);">No lessons available for this course.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php $csrfName = csrf_token(); $csrfValue = csrf_hash(); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {

    function markLessonCompleteCallback(lessonId) {
        const sidebarLink = document.querySelector('a[href*="lesson=' + lessonId + '"]');
        if (sidebarLink) {
            const circle = sidebarLink.querySelector('div:first-child');
            if (circle) {
                circle.style.background = '#10b981';
                circle.innerHTML = '<i class="fas fa-check" style="font-size:0.6rem;"></i>';
            }
            const playIcon = sidebarLink.querySelector('.fa-play, .fa-check-circle');
            if (playIcon) { playIcon.className = 'fas fa-check-circle'; playIcon.style.color = '#10b981'; }
        }
    }

    function checkAllCompleted() {
        const certSection = document.getElementById('certificate-section');
        if (certSection) {
            <?php if (isset($allCompleted)): ?>
            if (<?= json_encode($allCompleted) ?>) certSection.style.display = 'block';
            <?php endif; ?>
        }
    }

    function getCsrf() {
        var name = '<?= $csrfName ?>';
        var input = document.querySelector('input[name="' + name + '"]');
        return input ? name + '=' + encodeURIComponent(input.value) : '';
    }

    document.querySelectorAll('.mark-complete-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const lessonId = this.dataset.lesson;
            const btnEl = this;
            btnEl.disabled = true;
            btnEl.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';

            fetch('<?= base_url('courses/lesson/complete') ?>', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest'},
                body: 'lesson_id=' + lessonId + '&' + getCsrf()
            })
            .then(r => r.json())
            .then(data => {
                if (data.completed) {
                    btnEl.innerHTML = '<i class="fas fa-check-circle"></i> Completed';
                    btnEl.style.background = '#10b981';
                    btnEl.style.borderColor = '#10b981';
                    btnEl.disabled = true;
                    markLessonCompleteCallback(lessonId);
                    if (data.allCompleted) {
                        const certSection = document.getElementById('certificate-section');
                        if (certSection) certSection.style.display = 'block';
                    }
                }
            })
            .catch(() => {
                btnEl.disabled = false;
                btnEl.innerHTML = '<i class="fas fa-check-circle"></i> Mark as Complete';
            });
        });
    });

    const quizForm = document.getElementById('quiz-form');
    if (quizForm) {
        quizForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const btn = document.getElementById('quiz-submit-btn');
            if (!btn) return;
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';

            const formData = new FormData(quizForm);
            fetch('<?= base_url('courses/quiz/submit') ?>', {
                method: 'POST',
                headers: {'X-Requested-With': 'XMLHttpRequest'},
                body: formData
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    const container = document.getElementById('quiz-container');
                    let resultHtml = '<div style="padding:16px; background:rgba(16,185,129,0.06); border-radius:8px; text-align:center; margin-top:16px;">';
                    resultHtml += '<p style="font-weight:600; color:var(--success); font-size:1rem;"><i class="fas fa-check-circle"></i> Quiz Completed</p>';
                    resultHtml += '<p style="font-size:0.875rem; color:var(--gray-600);">Score: ' + data.obtained_marks + ' / ' + data.total_marks + ' (' + data.correct_answers + ' / ' + data.total_questions + ' correct)</p>';
                    if (data.passed) {
                        resultHtml += '<span class="badge badge-success">Passed</span>';
                    } else {
                        resultHtml += '<span class="badge badge-danger">Failed</span>';
                    }
                    resultHtml += '</div>';
                    container.innerHTML = resultHtml;
                    markLessonCompleteCallback(<?= $currentLesson['id'] ?>);
                    checkAllCompleted();
                } else {
                    const btn2 = document.getElementById('quiz-submit-btn');
                    if (btn2) { btn2.disabled = false; btn2.innerHTML = '<i class="fas fa-paper-plane"></i> Submit Quiz'; }
                    alert('Error: ' + (data.error || 'Failed to submit quiz.'));
                }
            })
            .catch(() => {
                const btn2 = document.getElementById('quiz-submit-btn');
                if (btn2) { btn2.disabled = false; btn2.innerHTML = '<i class="fas fa-paper-plane"></i> Submit Quiz'; }
                alert('Network error. Please try again.');
            });
        });
    }

    checkAllCompleted();
});
</script>