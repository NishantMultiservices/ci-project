<section class="section" style="padding-top:120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Search Results']]]) ?>
        <div class="section-header" style="text-align:left; margin:0 0 32px;">
            <h1 class="section-title">Search Results for "<span class="gradient-text"><?= esc($query) ?></span>"</h1>
        </div>
        <form action="<?= base_url('search') ?>" method="get" class="search-box" style="max-width:600px; margin-bottom:32px;">
            <input type="text" name="q" value="<?= esc($query) ?>" placeholder="Search jobs, companies..." style="flex:1;">
            <button type="submit" class="btn btn-primary btn-sm">Search</button>
        </form>
        <?php if (!empty($results['jobs'])): ?>
            <div class="grid-2">
            <?php foreach ($results['jobs'] as $job): ?>
                <div class="job-card">
                    <div class="job-card-header">
                        <div class="job-company-logo"><?= strtoupper(substr($job['company_name'], 0, 2)) ?></div>
                        <div style="flex:1;"><h3 class="job-card-title"><a href="<?= base_url('jobs/' . $job['id']) ?>"><?= esc($job['title']) ?></a></h3><div class="job-company"><?= esc($job['company_name']) ?></div></div>
                    </div>
                    <div class="job-card-body">
                        <div class="job-meta"><span class="job-meta-item"><i class="fas fa-map-marker-alt"></i> <?= esc($job['location'] ?? 'Multiple') ?></span><span class="job-meta-item"><i class="fas fa-money-bill-wave"></i> <?= format_salary($job['salary_min'], $job['salary_max'], $job['salary_text']) ?></span></div>
                    </div>
                    <div class="job-card-footer"><span style="font-size:0.813rem;color:var(--gray-500);"><?= time_ago($job['created_at']) ?></span><a href="<?= base_url('jobs/' . $job['id']) ?>" class="btn btn-primary btn-sm">View</a></div>
                </div>
            <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div style="text-align:center; padding:60px 20px;"><i class="fas fa-search" style="font-size:3rem; color:var(--gray-300); margin-bottom:16px; display:block;"></i><h3 style="margin-bottom:8px;">No Results Found</h3><p style="color:var(--gray-500);">Try different keywords or browse our job categories.</p></div>
        <?php endif; ?>
    </div>
</section>
