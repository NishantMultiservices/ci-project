<div class="auth-page">
    <div class="auth-card animate-fade-up">
        <div style="text-align: center; margin-bottom: 32px;">
            <div style="width: 64px; height: 64px; margin: 0 auto 16px; border-radius: 16px; background: linear-gradient(135deg, #f59e0b, #ef4444); display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: white;">
                <i class="fas fa-key"></i>
            </div>
            <h1 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 8px;">Forgot Password</h1>
            <p style="color: var(--gray-500); font-size: 0.875rem;">Enter your email and we'll send you a reset link</p>
        </div>

        <form action="<?= base_url('forgot-password') ?>" method="post">
            <?= csrf_field() ?>
            
            <div class="form-group">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-input" placeholder="you@example.com" required>
            </div>

            <button type="submit" class="btn btn-primary btn-block btn-lg">
                <i class="fas fa-paper-plane"></i> Send Reset Link
            </button>
        </form>

        <div style="text-align: center; margin-top: 24px;">
            <a href="<?= base_url('login') ?>" style="color: var(--primary); font-size: 0.875rem; text-decoration: none; font-weight: 500;">
                <i class="fas fa-arrow-left"></i> Back to Login
            </a>
        </div>
    </div>
</div>
