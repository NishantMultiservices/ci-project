<div class="auth-page">
    <div class="auth-card animate-fade-up">
        <div style="text-align: center; margin-bottom: 32px;">
            <a href="<?= base_url() ?>" class="logo" style="justify-content: center; margin-bottom: 16px;">
                <div class="logo-icon">RS</div>
                <span class="logo-text">Rojgar<span>Sandhi</span></span>
            </a>
            <h1 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 8px;">Welcome Back</h1>
            <p style="color: var(--gray-500); font-size: 0.875rem;">Sign in to your account to continue</p>
        </div>

        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-error" style="margin-bottom: 20px; padding: 12px 16px; background: #fef2f2; color: #dc2626; border-radius: 12px; font-size: 0.875rem; border: 1px solid #fecaca; text-align: center;"><?= esc(session()->getFlashdata('error')) ?></div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('success')): ?>
            <div class="alert alert-success" style="margin-bottom: 20px; padding: 12px 16px; background: #f0fdf4; color: #16a34a; border-radius: 12px; font-size: 0.875rem; border: 1px solid #bbf7d0; text-align: center;"><?= esc(session()->getFlashdata('success')) ?></div>
        <?php endif; ?>
        <form action="<?= base_url('login') ?>" method="post">
            <?= csrf_field() ?>
            
            <div class="form-group">
                <label class="form-label">Email Address</label>
                <div style="position: relative;">
                    <i class="fas fa-envelope" style="position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: var(--gray-400);"></i>
                    <input type="email" name="email" class="form-input" style="padding-left: 44px;" placeholder="you@example.com" required>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Password</label>
                <div style="position: relative;">
                    <i class="fas fa-lock" style="position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: var(--gray-400);"></i>
                    <input type="password" name="password" class="form-input" style="padding-left: 44px; padding-right: 44px;" placeholder="Enter your password" required>
                    <button type="button" class="password-toggle" style="position: absolute; right: 14px; top: 50%; transform: translateY(-50%); background: none; border: none; cursor: pointer; color: var(--gray-400);">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px;">
                <label style="display: flex; align-items: center; gap: 8px; font-size: 0.875rem; color: var(--gray-600); cursor: pointer;">
                    <input type="checkbox" name="remember" value="1" style="accent-color: var(--primary);">
                    Remember me
                </label>
                <a href="<?= base_url('forgot-password') ?>" style="font-size: 0.875rem; color: var(--primary); text-decoration: none; font-weight: 500;">Forgot Password?</a>
            </div>

            <button type="submit" class="btn btn-primary btn-block btn-lg">
                <i class="fas fa-sign-in-alt"></i> Sign In
            </button>
        </form>

        <div style="text-align: center; margin-top: 24px; position: relative;">
            <div style="border-top: 1px solid var(--gray-200); margin-bottom: 24px;"></div>
            <p style="font-size: 0.875rem; color: var(--gray-500);">
                Don't have an account? 
                <a href="<?= base_url('register') ?>" style="color: var(--primary); font-weight: 600; text-decoration: none;">Create Account</a>
            </p>
        </div>
    </div>
</div>
