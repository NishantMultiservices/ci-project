<div class="auth-page">
    <div class="auth-card animate-fade-up">
        <div style="text-align: center; margin-bottom: 32px;">
            <div style="width: 64px; height: 64px; margin: 0 auto 16px; border-radius: 16px; background: linear-gradient(135deg, #10b981, #06b6d4); display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: white;">
                <i class="fas fa-lock"></i>
            </div>
            <h1 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 8px;">Reset Password</h1>
            <p style="color: var(--gray-500); font-size: 0.875rem;">Enter your new password</p>
        </div>

        <form action="<?= base_url('reset-password') ?>" method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="token" value="<?= $token ?? '' ?>">
            
            <div class="form-group">
                <label class="form-label">New Password</label>
                <input type="password" name="password" class="form-input" placeholder="Min. 6 characters" required>
            </div>

            <div class="form-group">
                <label class="form-label">Confirm Password</label>
                <input type="password" name="pass_confirm" class="form-input" placeholder="Confirm password" required>
            </div>

            <button type="submit" class="btn btn-primary btn-block btn-lg">
                <i class="fas fa-save"></i> Reset Password
            </button>
        </form>
    </div>
</div>
