<div class="auth-page">
    <div class="auth-card animate-fade-up" style="max-width: 520px;">
        <div style="text-align: center; margin-bottom: 32px;">
            <a href="<?= base_url() ?>" class="logo" style="justify-content: center; margin-bottom: 16px;">
                <div class="logo-icon">RS</div>
                <span class="logo-text">Rojgar<span>Sandhi</span></span>
            </a>
            <h1 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 8px;">Create Account</h1>
            <p style="color: var(--gray-500); font-size: 0.875rem;">Join millions of job seekers on RojgarSandhi</p>
        </div>

        <form action="<?= base_url('register') ?>" method="post">
            <?= csrf_field() ?>

            <?php if (session()->getFlashdata('errors')): ?>
                <div class="alert alert-error">
                    <ul style="margin: 0; padding-left: 16px;">
                        <?php foreach (session()->getFlashdata('errors') as $error): ?>
                            <li><?= esc($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="form-group">
                <label class="form-label">Full Name</label>
                <input type="text" name="name" class="form-input" placeholder="Enter your full name" value="<?= old('name') ?>" required>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div class="form-group">
                    <label class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-input" placeholder="you@example.com" value="<?= old('email') ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Phone Number</label>
                    <input type="tel" name="phone" class="form-input" placeholder="9876543210" value="<?= old('phone') ?>" maxlength="10" required>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div class="form-group">
                    <label class="form-label">Password</label>
                    <div style="position: relative;">
                        <input type="password" name="password" id="reg-password" class="form-input" placeholder="Min. 6 characters" required>
                        <button type="button" class="password-toggle" data-target="reg-password" style="position: absolute; right: 14px; top: 50%; transform: translateY(-50%); background: none; border: none; cursor: pointer; color: var(--gray-400);">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Confirm Password</label>
                    <div style="position: relative;">
                        <input type="password" name="pass_confirm" class="form-input" placeholder="Confirm password" required>
                    </div>
                </div>
            </div>

            <div style="margin-bottom: 24px;">
                <label style="display: flex; align-items: flex-start; gap: 8px; font-size: 0.813rem; color: var(--gray-500); cursor: pointer;">
                    <input type="checkbox" required style="accent-color: var(--primary); margin-top: 2px;">
                    I agree to the <a href="#" style="color: var(--primary);">Terms of Service</a> and <a href="#" style="color: var(--primary);">Privacy Policy</a>
                </label>
            </div>

            <button type="submit" class="btn btn-primary btn-block btn-lg">
                <i class="fas fa-user-plus"></i> Create Account
            </button>
        </form>

        <div style="text-align: center; margin-top: 24px;">
            <p style="font-size: 0.875rem; color: var(--gray-500);">
                Already have an account? 
                <a href="<?= base_url('login') ?>" style="color: var(--primary); font-weight: 600; text-decoration: none;">Sign In</a>
            </p>
        </div>
    </div>
</div>
