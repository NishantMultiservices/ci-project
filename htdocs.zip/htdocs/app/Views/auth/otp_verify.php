<div class="auth-page">
    <div class="auth-card animate-fade-up">
        <div style="text-align: center; margin-bottom: 32px;">
            <div style="width: 64px; height: 64px; margin: 0 auto 16px; border-radius: 16px; background: linear-gradient(135deg, #6366f1, #8b5cf6); display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: white;">
                <i class="fas fa-shield-alt"></i>
            </div>
            <h1 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 8px;">OTP Verification</h1>
            <p style="color: var(--gray-500); font-size: 0.875rem;">Enter the OTP sent to your email/phone</p>
        </div>

        <form action="<?= base_url('otp-verify') ?>" method="post">
            <?= csrf_field() ?>
            
            <div class="form-group">
                <label class="form-label">Enter OTP</label>
                <input type="text" name="otp" class="form-input" placeholder="123456" maxlength="6" pattern="[0-9]{6}" required style="text-align: center; font-size: 1.25rem; letter-spacing: 8px;">
            </div>

            <button type="submit" class="btn btn-primary btn-block btn-lg">
                <i class="fas fa-check-circle"></i> Verify OTP
            </button>
        </form>

        <div style="text-align: center; margin-top: 24px;">
            <p style="font-size: 0.875rem; color: var(--gray-500);">
                Didn't receive OTP? 
                <a href="#" style="color: var(--primary); font-weight: 600; text-decoration: none;">Resend OTP</a>
            </p>
        </div>
    </div>
</div>
