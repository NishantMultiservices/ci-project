<section class="section" style="padding-top:120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Career Guidance']]]) ?>
        <div class="section-header">
            <span class="section-label">Guidance</span>
            <h1 class="section-title">Career <span class="gradient-text">Guidance</span></h1>
            <p class="section-desc">Expert advice on career options, preparation, and growth strategies.</p>
        </div>
        <div class="grid-3">
            <a href="<?= base_url('career-guidance?category=career-options') ?>" class="glass-card" style="padding:28px; text-align:center; text-decoration:none; display:block;"><i class="fas fa-compass" style="font-size:2.5rem; color:var(--primary); margin-bottom:12px; display:block;"></i><h3 style="font-size:1rem; margin-bottom:4px;">Career Options</h3><p style="font-size:0.813rem; color:var(--gray-500);">Explore different career paths</p></a>
            <a href="<?= base_url('career-guidance?category=how-to-prepare') ?>" class="glass-card" style="padding:28px; text-align:center; text-decoration:none; display:block;"><i class="fas fa-book" style="font-size:2.5rem; color:var(--success); margin-bottom:12px; display:block;"></i><h3 style="font-size:1rem; margin-bottom:4px;">How to Prepare</h3><p style="font-size:0.813rem; color:var(--gray-500);">Exam preparation strategies</p></a>
            <a href="<?= base_url('career-guidance?category=resume-tips') ?>" class="glass-card" style="padding:28px; text-align:center; text-decoration:none; display:block;"><i class="fas fa-file-alt" style="font-size:2.5rem; color:var(--warning); margin-bottom:12px; display:block;"></i><h3 style="font-size:1rem; margin-bottom:4px;">Resume Tips</h3><p style="font-size:0.813rem; color:var(--gray-500);">Build impressive resumes</p></a>
        </div>
        <?php if (!empty($articles)): ?><div style="margin-top:48px;"><div class="grid-2"><?php foreach ($articles as $a): ?><div class="glass-card" style="padding:24px;"><h3 style="font-size:1.063rem; margin-bottom:8px;"><a href="<?= base_url('career-guidance/' . $a['slug']) ?>" style="color:var(--gray-900); text-decoration:none;"><?= esc($a['title']) ?></a></h3><p style="font-size:0.875rem; color:var(--gray-500); margin-bottom:12px;"><?= esc(truncate_text(strip_tags($a['excerpt'] ?? ''), 120)) ?></p><div style="display:flex; align-items:center; gap:12px; font-size:0.813rem; color:var(--gray-400);"><span><i class="fas fa-user"></i> <?= esc($a['author_name'] ?? 'RojgarSandhi') ?></span><span><i class="fas fa-calendar"></i> <?= format_date($a['published_at'] ?? $a['created_at']) ?></span></div></div><?php endforeach; ?></div></div><?php endif; ?>
    </div>
</section>
