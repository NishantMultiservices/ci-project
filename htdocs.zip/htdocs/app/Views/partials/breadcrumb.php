<?php if (!empty($breadcrumbs)): ?>
<nav class="breadcrumb">
    <a href="<?= base_url() ?>"><i class="fas fa-home"></i> Home</a>
    <?php foreach ($breadcrumbs as $crumb): ?>
        <span><i class="fas fa-chevron-right" style="font-size: 0.625rem;"></i></span>
        <?php if (!empty($crumb['url'])): ?>
            <a href="<?= $crumb['url'] ?>"><?= esc($crumb['name']) ?></a>
        <?php else: ?>
            <span class="current"><?= esc($crumb['name']) ?></span>
        <?php endif; ?>
    <?php endforeach; ?>
</nav>
<?php endif; ?>