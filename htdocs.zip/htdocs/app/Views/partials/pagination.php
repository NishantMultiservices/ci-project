<?php if ($pager && $pager->getPageCount() > 1): ?>
<?php $pager->only(['q', 'type', 'state', 'experience', 'salary', 'qualification', 'department', 'category']); ?>
<?php $links = $pager->links(); ?>
<nav class="pagination">
    <?= $links ?>
</nav>
<?php endif; ?>
