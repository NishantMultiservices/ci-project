<section class="section" style="padding-top: 120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Jobs', 'url' => base_url('jobs')], ['name' => $job['title']]]]) ?>
        
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 32px;">
            <div>
                <div class="glass-card" style="padding: 32px;">
                    <div style="display:flex; align-items:flex-start; gap:20px; margin-bottom:24px; flex-wrap:wrap;">
                        <div class="job-company-logo" style="width:72px; height:72px; font-size:1.5rem;"><?= strtoupper(substr($job['company_name'], 0, 2)) ?></div>
                        <div style="flex:1;">
                            <h1 style="font-size:1.5rem; font-weight:700; margin-bottom:4px;"><?= esc($job['title']) ?></h1>
                            <p style="font-size:1.063rem; color:var(--gray-500);"><?= esc($job['company_name']) ?></p>
                            <div style="display:flex; gap:16px; margin-top:12px; flex-wrap:wrap;">
                                <span style="display:flex; align-items:center; gap:6px; font-size:0.875rem; color:var(--gray-500);"><i class="fas fa-map-marker-alt" style="color:var(--primary);"></i> <?= esc($job['location'] ?? 'Multiple Locations') ?></span>
                                <span style="display:flex; align-items:center; gap:6px; font-size:0.875rem; color:var(--gray-500);"><i class="fas fa-briefcase" style="color:var(--primary);"></i> <?= $job['experience_min'] ? $job['experience_min'].'-'.$job['experience_max'].' yrs' : 'Fresher' ?></span>
                                <span style="display:flex; align-items:center; gap:6px; font-size:0.875rem; color:var(--gray-500);"><i class="fas fa-money-bill-wave" style="color:var(--primary);"></i> <?= format_salary($job['salary_min'], $job['salary_max'], $job['salary_text']) ?></span>
                            </div>
                        </div>
                        <div>
                            <button class="bookmark-btn btn btn-secondary" data-id="<?= $job['id'] ?>" data-type="job" style="padding:12px;">
                                <i class="<?= $bookmarked ? 'fas' : 'far' ?> fa-bookmark"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div style="display:flex; gap:16px; margin-bottom:32px; flex-wrap:wrap;">
                        <span class="job-tag <?= $job['job_type'] ?>" style="padding:6px 16px;"><?= ucfirst($job['job_type']) ?></span>
                        <?php if ($job['department']): ?><span class="job-tag" style="padding:6px 16px;"><?= esc($job['department']) ?></span><?php endif; ?>
                        <?php if ($job['total_vacancies']): ?><span class="job-tag" style="padding:6px 16px; background:rgba(16,185,129,0.1); color:#059669;"><?= $job['total_vacancies'] ?> Vacancies</span><?php endif; ?>
                    </div>
                    
                    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:16px; padding:20px; background:var(--gray-50); border-radius:12px; margin-bottom:24px;">
                        <?php if ($job['last_date_to_apply']): ?><div><span style="font-size:0.75rem; color:var(--gray-500); text-transform:uppercase; font-weight:600;">Last Date</span><p style="font-weight:600; margin-top:4px;"><?= format_date($job['last_date_to_apply']) ?></p></div><?php endif; ?>
                        <?php if ($job['exam_date']): ?><div><span style="font-size:0.75rem; color:var(--gray-500); text-transform:uppercase; font-weight:600;">Exam Date</span><p style="font-weight:600; margin-top:4px;"><?= format_date($job['exam_date']) ?></p></div><?php endif; ?>
                        <div><span style="font-size:0.75rem; color:var(--gray-500); text-transform:uppercase; font-weight:600;">Posted</span><p style="font-weight:600; margin-top:4px;"><?= time_ago($job['created_at']) ?></p></div>
                        <div><span style="font-size:0.75rem; color:var(--gray-500); text-transform:uppercase; font-weight:600;">Views</span><p style="font-weight:600; margin-top:4px;"><?= number_format($job['views_count'] ?? 0) ?></p></div>
                    </div>

                    <?php if (!empty($jobPosts)): ?>
                    <div style="margin-bottom:24px;">
                        <h3 style="font-size:1.125rem; margin-bottom:12px;">Available Positions</h3>
                        <div style="overflow-x:auto;">
                            <table style="width:100%; border-collapse:collapse; font-size:0.875rem;">
                                <thead>
                                    <tr style="background:var(--gray-50);">
                                        <th style="text-align:left; padding:10px 12px; border-bottom:2px solid var(--gray-200); font-weight:600;">Post</th>
                                        <th style="text-align:left; padding:10px 12px; border-bottom:2px solid var(--gray-200); font-weight:600;">Qualification</th>
                                        <th style="text-align:center; padding:10px 12px; border-bottom:2px solid var(--gray-200); font-weight:600;">Vacancies</th>
                                        <th style="text-align:center; padding:10px 12px; border-bottom:2px solid var(--gray-200); font-weight:600;">Experience</th>
                                        <th style="text-align:right; padding:10px 12px; border-bottom:2px solid var(--gray-200); font-weight:600;">Salary</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($jobPosts as $post): ?>
                                    <tr style="border-bottom:1px solid var(--gray-100);">
                                        <td style="padding:10px 12px; font-weight:500;"><?= esc($post['title']) ?></td>
                                        <td style="padding:10px 12px; color:var(--gray-600);"><?= esc($post['qualification'] ?? '-') ?></td>
                                        <td style="padding:10px 12px; text-align:center;"><?= $post['vacancies'] ?? '-' ?></td>
                                        <td style="padding:10px 12px; text-align:center;"><?= $post['experience_min'] ? $post['experience_min'] . '-' . $post['experience_max'] . ' yrs' : '-' ?></td>
                                        <td style="padding:10px 12px; text-align:right; font-weight:500; color:var(--primary);"><?= $post['salary_min'] ? '₹' . number_format($post['salary_min']) . ($post['salary_max'] ? ' - ₹' . number_format($post['salary_max']) : '') : '-' ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <h3 style="font-size:1.125rem; margin-bottom:12px;">Job Description</h3>
                    <div style="color:var(--gray-600); line-height:1.8;"><?= $job['description'] ?? 'No description provided.' ?></div>
                    
                    <?php if ($job['responsibilities']): ?><h3 style="font-size:1.125rem; margin:24px 0 12px;">Responsibilities</h3><div style="color:var(--gray-600); line-height:1.8;"><?= $job['responsibilities'] ?></div><?php endif; ?>
                    <?php if ($job['requirements']): ?><h3 style="font-size:1.125rem; margin:24px 0 12px;">Requirements</h3><div style="color:var(--gray-600); line-height:1.8;"><?= $job['requirements'] ?></div><?php endif; ?>
                    <?php if ($job['benefits']): ?><h3 style="font-size:1.125rem; margin:24px 0 12px;">Benefits</h3><div style="color:var(--gray-600); line-height:1.8;"><?= $job['benefits'] ?></div><?php endif; ?>
                    <?php if ($job['apply_instructions']): ?><h3 style="font-size:1.125rem; margin:24px 0 12px;">How to Apply</h3><div style="color:var(--gray-600); line-height:1.8;"><?= $job['apply_instructions'] ?></div><?php endif; ?>
                </div>
            </div>
            
            <div>
                <div class="glass-card" style="padding:24px; position:sticky; top:100px;">
                    <h3 style="font-size:1.063rem; margin-bottom:16px;">Apply Now</h3>
                    <?php if ($is_logged_in ?? false): ?>
                        <form action="<?= base_url('dashboard/apply') ?>" method="post">
                            <?= csrf_field() ?>
                            <input type="hidden" name="job_id" value="<?= $job['id'] ?>">
                            <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-paper-plane"></i> Apply Now</button>
                        </form>
                    <?php else: ?>
                        <a href="<?= base_url('login') ?>" class="btn btn-primary btn-block"><i class="fas fa-sign-in-alt"></i> Login to Apply</a>
                    <?php endif; ?>
                    
                    <?php if ($job['apply_link']): ?>
                    <a href="<?= $job['apply_link'] ?>" target="_blank" class="btn btn-secondary btn-block" style="margin-top:8px;"><i class="fas fa-external-link-alt"></i> Apply on Official Site</a>
                    <?php endif; ?>
                    
                    <div style="margin-top:20px; padding-top:20px; border-top:1px solid var(--gray-200);">
                        <h4 style="font-size:0.875rem; margin-bottom:12px; text-transform:uppercase; letter-spacing:0.05em; color:var(--gray-500);">Share</h4>
                        <div style="display:flex; gap:8px;">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode(current_url()) ?>" target="_blank" class="btn btn-secondary btn-sm"><i class="fab fa-facebook-f"></i></a>
                            <a href="https://twitter.com/intent/tweet?text=<?= urlencode($job['title'] . ' at ' . $job['company_name']) ?>&url=<?= urlencode(current_url()) ?>" target="_blank" class="btn btn-secondary btn-sm"><i class="fab fa-twitter"></i></a>
                            <a href="https://wa.me/?text=<?= urlencode($job['title'] . ' at ' . $job['company_name'] . ' - ' . current_url()) ?>" target="_blank" class="btn btn-secondary btn-sm"><i class="fab fa-whatsapp"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php if (!empty($related_jobs)): ?>
        <div style="margin-top:48px;">
            <h2 class="section-title" style="font-size:1.5rem; margin-bottom:24px;">Related <span class="gradient-text">Jobs</span></h2>
            <div class="grid-4">
                <?php foreach ($related_jobs as $rj): ?>
                <div class="job-card">
                    <div class="job-card-header">
                        <div class="job-company-logo" style="width:44px; height:44px; font-size:0.813rem;"><?= strtoupper(substr($rj['company_name'], 0, 2)) ?></div>
                        <div style="flex:1;"><h3 class="job-card-title" style="font-size:0.938rem;"><a href="<?= base_url('jobs/' . $rj['id']) ?>"><?= esc($rj['title']) ?></a></h3><div class="job-company"><?= esc($rj['company_name']) ?></div></div>
                    </div>
                    <div class="job-card-footer"><span class="job-salary"><?= format_salary($rj['salary_min'], $rj['salary_max'], $rj['salary_text']) ?></span><a href="<?= base_url('jobs/' . $rj['id']) ?>" class="btn btn-primary btn-sm">View</a></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>
<style>@media(max-width:768px){[style*="grid-template-columns: 2fr 1fr"] {grid-template-columns:1fr!important;}}</style>
