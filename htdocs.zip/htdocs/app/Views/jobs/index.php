<section class="section" style="padding-top: 120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Jobs']]]) ?>
        
        <div class="section-header animate-on-scroll" style="text-align: left; margin: 0 0 32px;">
            <h1 class="section-title">Latest <span class="gradient-text">Job Openings</span></h1>
            <p class="section-desc">Browse thousands of government and private sector jobs.</p>
        </div>
        
        <!-- Filters -->
        <form method="get" action="<?= base_url('jobs') ?>" class="glass-card" style="padding: 24px; margin-bottom: 32px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px;">
                <div>
                    <input type="text" name="q" class="form-input" placeholder="Search jobs..." value="<?= esc($filters['keyword'] ?? '') ?>">
                </div>
                <div>
                    <select name="state" class="form-select">
                        <option value="">All States</option>
                        <?php foreach ($states as $s): ?>
                            <option value="<?= $s ?>" <?= ($filters['state'] ?? '') === $s ? 'selected' : '' ?>><?= $s ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <select name="type" class="form-select">
                        <option value="">Job Type</option>
                        <option value="government" <?= ($filters['job_type'] ?? '') === 'government' ? 'selected' : '' ?>>Government</option>
                        <option value="private" <?= ($filters['job_type'] ?? '') === 'private' ? 'selected' : '' ?>>Private</option>
                        <option value="apprenticeship" <?= ($filters['job_type'] ?? '') === 'apprenticeship' ? 'selected' : '' ?>>Apprenticeship</option>
                    </select>
                </div>
                <div>
                    <select name="experience" class="form-select">
                        <option value="">Experience</option>
                        <option value="0-0" <?= ($filters['experience'] ?? '') === '0-0' ? 'selected' : '' ?>>Fresher</option>
                        <option value="0-1" <?= ($filters['experience'] ?? '') === '0-1' ? 'selected' : '' ?>>0-1 Years</option>
                        <option value="1-3" <?= ($filters['experience'] ?? '') === '1-3' ? 'selected' : '' ?>>1-3 Years</option>
                        <option value="3-5" <?= ($filters['experience'] ?? '') === '3-5' ? 'selected' : '' ?>>3-5 Years</option>
                        <option value="5-10" <?= ($filters['experience'] ?? '') === '5-10' ? 'selected' : '' ?>>5-10 Years</option>
                        <option value="10-20" <?= ($filters['experience'] ?? '') === '10-20' ? 'selected' : '' ?>>10+ Years</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Search</button>
            </div>
        </form>
        
        <!-- Job Cards -->
        <?php if (!empty($jobs)): ?>
        <div class="grid-2">
            <?php foreach ($jobs as $job): ?>
            <div class="job-card">
                <div class="job-card-header">
                    <div class="job-company-logo"><?= strtoupper(substr($job['company_name'], 0, 2)) ?></div>
                    <div style="flex: 1;">
                        <h3 class="job-card-title"><a href="<?= base_url('jobs/' . $job['id']) ?>"><?= esc($job['title']) ?></a></h3>
                        <div class="job-company"><?= esc($job['company_name']) ?> &middot; <?= esc($job['location'] ?? 'Multiple') ?></div>
                    </div>
                </div>
                <div class="job-card-body">
                    <div class="job-meta">
                        <span class="job-meta-item"><i class="fas fa-money-bill-wave"></i> <?= format_salary($job['salary_min'], $job['salary_max'], $job['salary_text']) ?></span>
                        <span class="job-meta-item"><i class="fas fa-calendar-alt"></i> <?= days_remaining($job['last_date_to_apply']) ?></span>
                        <span class="job-meta-item"><i class="fas fa-briefcase"></i> <?= $job['experience_min'] ? $job['experience_min'] . '-' . $job['experience_max'] . ' yrs' : 'Fresher' ?></span>
                    </div>
                    <div class="job-tags">
                        <span class="job-tag <?= $job['job_type'] ?>"><?= ucfirst($job['job_type']) ?></span>
                        <?php if ($job['is_featured']): ?><span class="job-tag" style="background: rgba(245,158,11,0.1); color:#d97706;">Featured</span><?php endif; ?>
                    </div>
                </div>
                <div class="job-card-footer">
                    <span style="font-size:0.813rem; color:var(--gray-500);"><i class="far fa-clock"></i> <?= time_ago($job['created_at']) ?></span>
                    <div style="display:flex; gap:8px;">
                        <button class="bookmark-btn btn btn-secondary btn-sm" data-id="<?= $job['id'] ?>" data-type="job"><i class="far fa-bookmark"></i></button>
                        <a href="<?= base_url('jobs/' . $job['id']) ?>" class="btn btn-primary btn-sm">Apply</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?= view('partials/pagination', ['pager' => $pager ?? null]) ?>
        <?php else: ?>
        <div style="text-align:center; padding:80px 20px;">
            <i class="fas fa-search" style="font-size:3rem; color:var(--gray-300); margin-bottom:16px; display:block;"></i>
            <h3 style="margin-bottom:8px;">No Jobs Found</h3>
            <p style="color:var(--gray-500);">Try adjusting your search filters or browse all jobs.</p>
            <a href="<?= base_url('jobs') ?>" class="btn btn-primary" style="margin-top:16px;">Clear Filters</a>
        </div>
        <?php endif; ?>
    </div>
</section>
