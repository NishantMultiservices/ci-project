<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:24px;">
    <h1 style="font-size:1.5rem; font-weight:700;">Mock Tests</h1>
    <a href="<?= base_url('mock-tests') ?>" class="btn btn-primary btn-sm"><i class="fas fa-external-link-alt"></i> Browse All Tests</a>
</div>

<div class="grid-4" style="margin-bottom:32px;">
    <div class="stat-card-admin"><div class="stat-icon" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);"><i class="fas fa-vial"></i></div><div class="stat-info"><h3><?= $totalTests ?></h3><p>Tests Taken</p></div></div>
    <div class="stat-card-admin"><div class="stat-icon" style="background:linear-gradient(135deg,#10b981,#06b6d4);"><i class="fas fa-check-circle"></i></div><div class="stat-info"><h3><?= $completedTests ?></h3><p>Completed</p></div></div>
    <div class="stat-card-admin"><div class="stat-icon" style="background:linear-gradient(135deg,#f59e0b,#ef4444);"><i class="fas fa-chart-line"></i></div><div class="stat-info"><h3><?= $avgScore ?></h3><p>Avg Score</p></div></div>
    <div class="stat-card-admin"><div class="stat-icon" style="background:linear-gradient(135deg,#3b82f6,#6366f1);"><i class="fas fa-trophy"></i></div><div class="stat-info"><h3><?= $bestScore ?></h3><p>Best Score</p></div></div>
</div>

<?php if (!empty($mockTests)): ?>
<div class="glass-card" style="padding:24px; margin-bottom:24px;">
    <h3 style="font-size:1.063rem; font-weight:600; margin-bottom:16px;">Available Tests</h3>
    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(280px, 1fr)); gap:16px;">
        <?php foreach ($mockTests as $t): ?>
        <div style="padding:16px; border:1px solid var(--gray-200); border-radius:10px;">
            <h4 style="font-weight:600; font-size:0.938rem; margin-bottom:6px;"><?= esc($t['title']) ?></h4>
            <p style="font-size:0.813rem; color:var(--gray-500); margin-bottom:12px;">
                <i class="fas fa-clock"></i> <?= $t['duration_minutes'] ?> min &middot;
                <i class="fas fa-question-circle"></i> <?= $t['total_questions'] ?> Q &middot;
                <i class="fas fa-chart-simple"></i> <?= $t['total_marks'] ?> marks
            </p>
            <a href="<?= base_url('mock-tests/' . esc($t['slug'])) ?>" class="btn btn-primary btn-sm"><i class="fas fa-play"></i> Start Test</a>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<?php if (!empty($attempts)): ?>
<div class="glass-card" style="padding:24px;">
    <h3 style="font-size:1.063rem; font-weight:600; margin-bottom:16px;">Attempt History</h3>
    <div style="overflow-x:auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Test</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Score</th>
                    <th>Correct</th>
                    <th>Incorrect</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($attempts as $a): ?>
                <tr>
                    <td><?= esc($testTitles[$a['mock_test_id']] ?? 'Test #' . $a['mock_test_id']) ?></td>
                    <td style="font-size:0.813rem; white-space:nowrap;"><?= date('d M Y, h:i A', strtotime($a['started_at'] ?? $a['created_at'])) ?></td>
                    <td>
                        <?php if ($a['status'] === 'completed'): ?>
                        <span style="color:#10b981;"><i class="fas fa-check-circle"></i> Completed</span>
                        <?php elseif ($a['status'] === 'in_progress'): ?>
                        <span style="color:#f59e0b;"><i class="fas fa-spinner"></i> In Progress</span>
                        <?php else: ?>
                        <span style="color:var(--gray-500);"><?= ucfirst($a['status']) ?></span>
                        <?php endif; ?>
                    </td>
                    <td><strong><?= $a['score'] ?: 0 ?> / <?= $a['total_marks'] ?: '-' ?></strong></td>
                    <td style="color:#10b981;"><?= $a['correct_count'] ?: 0 ?></td>
                    <td style="color:#ef4444;"><?= $a['incorrect_count'] ?: 0 ?></td>
                    <td>
                        <?php if ($a['status'] === 'completed'): ?>
                        <a href="<?= base_url('dashboard/mock-tests/result/' . $a['id']) ?>" class="btn btn-sm" style="background:var(--primary); color:#fff; border:none; padding:4px 12px; border-radius:6px; font-size:0.75rem; text-decoration:none;"><i class="fas fa-eye"></i> View</a>
                        <?php else: ?>
                        <span style="font-size:0.75rem; color:var(--gray-400);">--</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php else: ?>
<div class="glass-card" style="padding:40px; text-align:center;">
    <div style="font-size:3rem; color:var(--gray-300); margin-bottom:16px;"><i class="fas fa-vial"></i></div>
    <h3 style="font-weight:600; margin-bottom:8px;">No Tests Taken Yet</h3>
    <p style="color:var(--gray-500); font-size:0.875rem; margin-bottom:16px;">Start your first mock test to assess your preparation level.</p>
    <a href="<?= base_url('mock-tests') ?>" class="btn btn-primary"><i class="fas fa-play"></i> Browse Mock Tests</a>
</div>
<?php endif; ?>
