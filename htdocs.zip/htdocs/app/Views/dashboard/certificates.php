<h1 style="font-size:1.5rem; font-weight:700; margin-bottom:24px;">Certificates</h1>
<?php if (!empty($certificates)): ?>
<div class="grid-3">
<?php foreach ($certificates as $c): ?>
<div class="glass-card" style="overflow:hidden;">
    <div style="padding:24px; text-align:center; background:linear-gradient(135deg,rgba(99,102,241,0.04),rgba(139,92,246,0.08));">
        <div style="width:64px; height:64px; border-radius:50%; background:linear-gradient(135deg,#6366f1,#8b5cf6); display:flex; align-items:center; justify-content:center; margin:0 auto 12px; font-size:1.5rem; color:white;"><i class="fas fa-certificate"></i></div>
        <h3 style="font-size:0.938rem; font-weight:700; margin-bottom:4px;"><?= esc($c['course_title']) ?></h3>
        <p style="font-size:0.75rem; color:var(--gray-500);"><?= esc($c['instructor_name'] ?? 'RojgarSandhi') ?></p>
    </div>
    <div style="padding:16px;">
        <div style="display:flex; justify-content:space-between; font-size:0.75rem; color:var(--gray-500); margin-bottom:12px;">
            <span><i class="fas fa-calendar"></i> <?= date('d M Y', strtotime($c['issued_at'])) ?></span>
            <span><i class="fas fa-hashtag"></i> <?= substr($c['certificate_number'], -8) ?></span>
        </div>
        <a href="<?= base_url('certificates/view/' . $c['course_id']) ?>" class="btn btn-primary btn-sm" style="width:100%; text-decoration:none; text-align:center;"><i class="fas fa-eye"></i> View Certificate</a>
    </div>
</div>
<?php endforeach; ?>
</div>
<?php else: ?>
<div style="text-align:center; padding:60px;"><i class="fas fa-certificate" style="font-size:3rem; color:var(--gray-300); margin-bottom:16px; display:block;"></i><p style="color:var(--gray-500);">No certificates yet. Complete courses to earn certificates.</p><a href="<?= base_url('courses') ?>" class="btn btn-primary" style="margin-top:16px;">Browse Courses</a></div>
<?php endif; ?>
