<h1 style="font-size:1.5rem; font-weight:700; margin-bottom:24px;">My Courses</h1>
<?php if (!empty($enrollments)): ?>
<div class="grid-3">
<?php foreach ($enrollments as $e): ?>
<div class="glass-card" style="overflow:hidden;">
    <?php if ($e['thumbnail']): ?>
    <img src="<?= base_url($e['thumbnail']) ?>" alt="<?= esc($e['course_title']) ?>" style="width:100%; height:140px; object-fit:cover;">
    <?php else: ?>
    <div style="width:100%; height:100px; background:linear-gradient(135deg,#6366f1,#8b5cf6); display:flex; align-items:center; justify-content:center; font-size:2rem; color:rgba(255,255,255,0.4);"><i class="fas fa-graduation-cap"></i></div>
    <?php endif; ?>
    <div style="padding:16px;">
        <h3 style="font-size:0.938rem; font-weight:600; margin-bottom:4px;"><?= esc($e['course_title']) ?></h3>
        <p style="font-size:0.75rem; color:var(--gray-500); margin-bottom:12px;"><i class="fas fa-user-tie"></i> <?= esc($e['instructor_name'] ?? 'Expert Instructor') ?></p>
        <div style="display:flex; gap:12px; font-size:0.75rem; color:var(--gray-500); margin-bottom:12px;">
            <?php if ($e['duration']): ?><span><i class="fas fa-clock"></i> <?= esc($e['duration']) ?></span><?php endif; ?>
            <?php if ($e['total_lessons']): ?><span><i class="fas fa-list"></i> <?= $e['total_lessons'] ?> Lessons</span><?php endif; ?>
        </div>
        <div style="display:flex; gap:8px;">
            <span class="badge badge-<?= $e['status'] === 'active' ? 'success' : ($e['status'] === 'completed' ? 'info' : 'secondary') ?>"><?= ucfirst($e['status']) ?></span>
            <span style="font-size:0.75rem; color:var(--gray-500); margin-left:auto;">Enrolled <?= time_ago($e['enrolled_at']) ?></span>
        </div>
        <a href="<?= base_url('courses/learn/' . $e['course_id']) ?>" class="btn btn-primary btn-sm" style="width:100%; margin-top:12px; text-decoration:none; text-align:center;"><i class="fas fa-play-circle"></i> Start Learning</a>
    </div>
</div>
<?php endforeach; ?>
</div>
<?php else: ?>
<div style="text-align:center; padding:60px;">
    <i class="fas fa-book-open" style="font-size:3rem; color:var(--gray-300); margin-bottom:16px; display:block;"></i>
    <p style="color:var(--gray-500); margin-bottom:16px;">You haven't enrolled in any courses yet.</p>
    <a href="<?= base_url('courses') ?>" class="btn btn-primary"><i class="fas fa-graduation-cap"></i> Browse Courses</a>
</div>
<?php endif; ?>