<h1 style="font-size:1.5rem; font-weight:700; margin-bottom:24px;">Settings</h1>
<div class="glass-card" style="padding:32px; max-width:600px;">
    <form action="<?= base_url('dashboard/settings/update') ?>" method="post">
        <?= csrf_field() ?>
        <div class="form-group"><label class="form-label">Email Notifications</label><select name="email_notifications" class="form-select"><option value="1">Enabled</option><option value="0">Disabled</option></select></div>
        <div class="form-group"><label class="form-label">Job Alerts</label><select name="job_alerts" class="form-select"><option value="daily">Daily</option><option value="weekly">Weekly</option><option value="instant">Instant</option></select></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Settings</button>
    </form>
</div>
