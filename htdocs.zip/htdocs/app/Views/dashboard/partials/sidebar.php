<?php // Sidebar is included in the header ?>
