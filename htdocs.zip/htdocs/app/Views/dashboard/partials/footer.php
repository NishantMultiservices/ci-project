            </div>
        </div>
    </div>
    <?= csrf_field() ?>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script>
    var baseUrl = '<?= base_url() ?>';
    </script>
    <script src="<?= base_url('assets/js/app.js?v=' . filemtime(FCPATH . 'assets/js/app.js')) ?>"></script>
    <script>
        // Mobile sidebar toggle
        const sidebarToggle = document.querySelector('.mobile-sidebar-toggle');
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function() {
                document.getElementById('admin-sidebar').classList.toggle('open');
            });
        }
    </script>
</body>
</html>
