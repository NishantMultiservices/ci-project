<!DOCTYPE html>
<html lang="en" data-theme="<?= session('theme') ?? 'light' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Dashboard - RojgarSandhi') ?></title>
    <meta name="robots" content="noindex, nofollow">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Tiro+Devanagari+Marathi:ital@0;1&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css?v=' . filemtime(FCPATH . 'assets/css/style.css')) ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/admin.css?v=' . filemtime(FCPATH . 'assets/css/admin.css')) ?>">
</head>
<body>
    <div class="admin-layout">
        <aside class="admin-sidebar" id="admin-sidebar">
            <div class="sidebar-brand">
                <a href="<?= base_url() ?>" class="logo" style="color:white;">
                    <div class="logo-icon" style="width:36px; height:36px; font-size:1rem;">RS</div>
                    <span style="font-weight:700; font-size:1.125rem;">RojgarSandhi</span>
                </a>
            </div>
            <nav class="sidebar-nav">
                <div class="sidebar-label">Main</div>
                <a href="<?= base_url('dashboard') ?>" class="sidebar-item <?= uri_string() === 'dashboard' ? 'active' : '' ?>"><i class="fas fa-th-large"></i> Dashboard</a>
                <a href="<?= base_url('dashboard/profile') ?>" class="sidebar-item"><i class="fas fa-user"></i> My Profile</a>
                <a href="<?= base_url('dashboard/saved-jobs') ?>" class="sidebar-item"><i class="fas fa-bookmark"></i> Saved Jobs</a>
                <a href="<?= base_url('dashboard/applied-jobs') ?>" class="sidebar-item"><i class="fas fa-paper-plane"></i> Applied Jobs</a>
                <a href="<?= base_url('dashboard/resume') ?>" class="sidebar-item"><i class="fas fa-file-alt"></i> My Resumes</a>
                <a href="<?= base_url('dashboard/my-courses') ?>" class="sidebar-item <?= uri_string() === 'dashboard/my-courses' ? 'active' : '' ?>"><i class="fas fa-book-open"></i> My Courses</a>
                <a href="<?= base_url('dashboard/mock-tests') ?>" class="sidebar-item <?= uri_string() === 'dashboard/mock-tests' ? 'active' : '' ?>"><i class="fas fa-vial"></i> Mock Tests</a>
                <a href="<?= base_url('dashboard/certificates') ?>" class="sidebar-item"><i class="fas fa-certificate"></i> Certificates</a>
                <a href="<?= base_url('dashboard/bookmarks') ?>" class="sidebar-item"><i class="fas fa-heart"></i> Bookmarks</a>
                
                <div class="sidebar-label">Settings</div>
                <a href="<?= base_url('dashboard/notifications') ?>" class="sidebar-item"><i class="fas fa-bell"></i> Notifications</a>
                <a href="<?= base_url('dashboard/settings') ?>" class="sidebar-item"><i class="fas fa-cog"></i> Settings</a>
                
                <div class="sidebar-label" style="margin-top:16px;">Quick Links</div>
                <a href="<?= base_url('courses') ?>" class="sidebar-item"><i class="fas fa-graduation-cap"></i> Courses</a>
                <a href="<?= base_url('jobs') ?>" class="sidebar-item"><i class="fas fa-briefcase"></i> Browse Jobs</a>
                <a href="<?= base_url('resume-builder') ?>" class="sidebar-item"><i class="fas fa-file-alt"></i> Resume Builder</a>
                <a href="<?= base_url('interview-preparation') ?>" class="sidebar-item"><i class="fas fa-people-arrows"></i> Interview Prep</a>
                <a href="<?= base_url('logout') ?>" class="sidebar-item" style="color:#ef4444;"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
        </aside>
        <div class="admin-main">
            <header class="admin-header">
                <button onclick="document.getElementById('admin-sidebar').classList.toggle('open')" style="background:none; border:none; font-size:1.25rem; cursor:pointer; display:none;" class="mobile-sidebar-toggle"><i class="fas fa-bars"></i></button>
                <div style="display:flex; align-items:center; gap:16px; margin-left:auto;">
                    <span style="font-size:0.875rem; color:var(--gray-500);"><?= esc($current_user['name'] ?? 'User') ?></span>
                    <a href="<?= base_url('logout') ?>" class="btn btn-secondary btn-sm"><i class="fas fa-sign-out-alt"></i></a>
                </div>
            </header>
            <div class="admin-content">
