<div style="margin-bottom:16px;">
    <a href="<?= base_url('dashboard/mock-tests') ?>" style="color:var(--primary); text-decoration:none; font-size:0.875rem;"><i class="fas fa-arrow-left"></i> Back to Mock Tests</a>
</div>

<?php $passed = $attempt['score'] >= $attempt['passing_marks']; ?>
<div class="glass-card" style="padding:32px; text-align:center; margin-bottom:24px;">
    <div style="font-size:3.5rem; margin-bottom:12px; color: <?= $passed ? '#10b981' : '#ef4444' ?>;">
        <i class="fas fa-<?= $passed ? 'trophy' : 'times-circle' ?>"></i>
    </div>
    <h2 style="font-size:1.5rem; font-weight:700; margin-bottom:6px;"><?= $passed ? 'Congratulations!' : 'Better Luck Next Time!' ?></h2>
    <p style="color:var(--gray-500); margin-bottom:20px;"><?= esc($attempt['title']) ?></p>
    <div style="display:flex; justify-content:center; gap:32px; flex-wrap:wrap; margin-bottom:20px;">
        <div><span style="display:block; font-size:2rem; font-weight:800; color:var(--primary);"><?= $attempt['score'] ?></span><span style="font-size:0.813rem; color:var(--gray-500);">Score (out of <?= $attempt['total_marks'] ?>)</span></div>
        <div><span style="display:block; font-size:2rem; font-weight:800; color:#10b981;"><?= $attempt['correct_count'] ?></span><span style="font-size:0.813rem; color:var(--gray-500);">Correct</span></div>
        <div><span style="display:block; font-size:2rem; font-weight:800; color:#ef4444;"><?= $attempt['incorrect_count'] ?></span><span style="font-size:0.813rem; color:var(--gray-500);">Incorrect</span></div>
        <div><span style="display:block; font-size:2rem; font-weight:800; color:var(--gray-400);"><?= $attempt['unanswered_count'] ?></span><span style="font-size:0.813rem; color:var(--gray-500);">Unanswered</span></div>
    </div>
    <?php $pct = $attempt['total_marks'] > 0 ? round(($attempt['score'] / $attempt['total_marks']) * 100) : 0; ?>
    <div style="max-width:360px; margin:0 auto 20px;">
        <div style="background:var(--gray-200); border-radius:16px; height:10px; overflow:hidden;">
            <div style="height:100%; border-radius:16px; background:<?= $passed ? 'linear-gradient(90deg,#10b981,#059669)' : 'linear-gradient(90deg,#ef4444,#dc2626)' ?>; width:<?= $pct ?>%;"></div>
        </div>
        <span style="font-size:0.813rem; color:var(--gray-500); margin-top:4px; display:block;"><?= $pct ?>% Score (Passing: <?= $attempt['passing_marks'] ?> marks)</span>
    </div>
    <a href="<?= base_url('dashboard/mock-tests') ?>" class="btn btn-outline btn-sm"><i class="fas fa-arrow-left"></i> Back to Tests</a>
</div>

<?php if (!empty($answers)): ?>
<h3 style="font-size:1.125rem; font-weight:600; margin-bottom:16px;">Detailed Review</h3>
<?php $idx = 0; ?>
<?php foreach ($answers as $a): $idx++; ?>
<div class="glass-card" style="padding:16px; margin-bottom:10px; border-left:4px solid <?= $a['is_correct'] ? '#10b981' : ($a['selected_answer'] ? '#ef4444' : 'var(--gray-300)') ?>;">
    <div style="display:flex; gap:10px;">
        <span style="width:26px; height:26px; border-radius:50%; background:var(--gray-100); display:flex; align-items:center; justify-content:center; font-size:0.75rem; font-weight:600; flex-shrink:0;"><?= $idx ?></span>
        <div style="flex:1;">
            <p style="font-weight:500; margin-bottom:10px; font-size:0.875rem;"><?= esc($a['question']) ?></p>
            <?php $options = is_string($a['options']) ? json_decode($a['options'], true) : $a['options']; ?>
            <?php foreach (($options ?? []) as $key => $value): ?>
            <?php if (empty($value)) continue; ?>
            <div style="padding:6px 10px; margin-bottom:4px; border-radius:6px; font-size:0.813rem; border:2px solid var(--gray-200); <?= $key === $a['correct_answer'] ? 'border-color:#10b981; background:rgba(16,185,129,0.05);' : ($key === $a['selected_answer'] && $key !== $a['correct_answer'] ? 'border-color:#ef4444; background:rgba(239,68,68,0.05);' : '') ?>">
                <?= esc($value) ?>
                <?php if ($key === $a['correct_answer']): ?><i class="fas fa-check-circle" style="color:#10b981; margin-left:6px;"></i><?php endif; ?>
                <?php if ($key === $a['selected_answer'] && $key !== $a['correct_answer']): ?><i class="fas fa-times-circle" style="color:#ef4444; margin-left:6px;"></i><?php endif; ?>
            </div>
            <?php endforeach; ?>
            <div style="margin-top:6px; font-size:0.75rem; color:var(--gray-500);">
                <?php if ($a['is_correct']): ?><span style="color:#10b981;"><i class="fas fa-check"></i> Correct (+<?= $a['marks_obtained'] ?> marks)</span>
                <?php elseif ($a['selected_answer']): ?><span style="color:#ef4444;"><i class="fas fa-times"></i> Incorrect (<?= $a['marks_obtained'] >= 0 ? '+' : '' ?><?= $a['marks_obtained'] ?> marks)</span>
                <?php else: ?><span style="color:var(--gray-400);"><i class="fas fa-minus"></i> Not Answered (0 marks)</span><?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>
<?php endif; ?>
