<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:24px;">
    <h1 style="font-size:1.5rem; font-weight:700;">My Bookmarks</h1>
    <span style="font-size:0.813rem; color:var(--gray-500);"><?= count($bookmarks) ?> saved</span>
</div>

<?php if (!empty($bookmarks)): ?>
<div class="grid-2">
<?php foreach ($bookmarks as $b):
    $item = [];
    if ($b['type'] === 'job') {
        $item = $jobs[$b['item_id']] ?? [];
        $icon = 'briefcase';
        $color1 = '#3b82f6'; $color2 = '#2563eb';
        $badge = '<span style="font-size:0.688rem; font-weight:600; padding:2px 10px; border-radius:20px; background:rgba(59,130,246,0.12); color:#3b82f6; text-transform:uppercase; letter-spacing:0.5px;">Job</span>';
        $detail1 = $item['company_name'] ?? '';
        $detail2 = $item['location'] ?? '';
        $detailIcon1 = 'building';
        $detailIcon2 = 'map-marker-alt';
        $link = base_url('jobs/' . $b['item_id']);
    } elseif ($b['type'] === 'course') {
        $item = $courses[$b['item_id']] ?? [];
        $icon = 'graduation-cap';
        $color1 = '#8b5cf6'; $color2 = '#7c3aed';
        $badge = '<span style="font-size:0.688rem; font-weight:600; padding:2px 10px; border-radius:20px; background:rgba(139,92,246,0.12); color:#8b5cf6; text-transform:uppercase; letter-spacing:0.5px;">Course</span>';
        $detail1 = $item['instructor_name'] ?? '';
        $detail2 = $item['duration'] ?? '';
        $detailIcon1 = 'user-tie';
        $detailIcon2 = 'clock';
        $link = base_url('courses/' . $b['item_id']);
    } else { continue; }
    $title = $item['title'] ?? (ucfirst($b['type']) . ' #' . $b['item_id']);
?>
<div class="glass-card" style="padding:20px; display:flex; flex-direction:column; gap:12px; transition:transform 0.2s, box-shadow 0.2s;">
    <div style="display:flex; align-items:flex-start; gap:14px;">
        <div style="width:48px; height:48px; border-radius:12px; background:linear-gradient(135deg,<?= $color1 ?>,<?= $color2 ?>); display:flex; align-items:center; justify-content:center; color:white; flex-shrink:0; font-size:1.125rem;"><i class="fas fa-<?= $icon ?>"></i></div>
        <div style="flex:1; min-width:0;">
            <div style="display:flex; align-items:center; gap:8px; margin-bottom:4px;"><?= $badge ?><span style="font-size:0.75rem; color:var(--gray-400);"><?= time_ago($b['created_at']) ?></span></div>
            <a href="<?= $link ?>" style="font-weight:600; font-size:0.938rem; color:var(--text); text-decoration:none; display:block; line-height:1.35; transition:color 0.15s;" onmouseover="this.style.color='<?= $color1 ?>'" onmouseout="this.style.color=''"><?= esc($title) ?></a>
        </div>
    </div>
    <div style="display:flex; gap:16px; flex-wrap:wrap; font-size:0.813rem; color:var(--gray-500);">
        <?php if ($detail1): ?><span style="display:flex; align-items:center; gap:5px;"><i class="fas fa-<?= $detailIcon1 ?>" style="width:14px; color:var(--gray-400);"></i> <?= esc($detail1) ?></span><?php endif; ?>
        <?php if ($detail2): ?><span style="display:flex; align-items:center; gap:5px;"><i class="fas fa-<?= $detailIcon2 ?>" style="width:14px; color:var(--gray-400);"></i> <?= esc($detail2) ?></span><?php endif; ?>
    </div>
    <div style="display:flex; gap:8px; margin-top:4px;">
        <a href="<?= $link ?>" class="btn btn-sm" style="flex:1; padding:8px; text-align:center; border-radius:8px; background:<?= $color1 ?>; color:white; text-decoration:none; font-size:0.813rem; font-weight:500; transition:opacity 0.15s;" onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'"><i class="fas fa-eye"></i> View</a>
        <button class="bookmark-btn btn btn-sm" data-id="<?= $b['item_id'] ?>" data-type="<?= $b['type'] ?>" style="flex:0 0 auto; padding:8px 14px; border-radius:8px; border:1px solid var(--gray-200); background:transparent; color:var(--gray-500); cursor:pointer; font-size:0.813rem; transition:all 0.15s;" onmouseover="this.style.borderColor='#ef4444';this.style.color='#ef4444'" onmouseout="this.style.borderColor='';this.style.color=''"><i class="fas fa-trash-alt" style="font-size:0.75rem;"></i> Remove</button>
    </div>
</div>
<?php endforeach; ?>
</div>
<?php else: ?>
<div style="text-align:center; padding:60px;">
    <i class="fas fa-heart" style="font-size:3rem; color:var(--gray-300); margin-bottom:16px; display:block;"></i>
    <p style="color:var(--gray-500); margin-bottom:8px;">No bookmarks yet.</p>
    <p style="font-size:0.875rem; color:var(--gray-400); margin-bottom:20px;">Save jobs and courses you're interested in to find them quickly.</p>
    <div style="display:flex; gap:12px; justify-content:center; flex-wrap:wrap;">
        <a href="<?= base_url('jobs') ?>" class="btn btn-primary"><i class="fas fa-briefcase"></i> Browse Jobs</a>
        <a href="<?= base_url('courses') ?>" class="btn btn-secondary"><i class="fas fa-graduation-cap"></i> Browse Courses</a>
    </div>
</div>
<?php endif; ?>
