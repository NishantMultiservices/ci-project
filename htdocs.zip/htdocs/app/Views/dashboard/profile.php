<h1 style="font-size:1.5rem; font-weight:700; margin-bottom:24px;">My Profile</h1>

<form action="<?= base_url('dashboard/profile/update') ?>" method="post" id="profileForm">
    <?= csrf_field() ?>

    <div class="glass-card" style="padding:24px; margin-bottom:20px;">
        <h2 style="font-size:1.125rem; font-weight:600; margin-bottom:16px;">Personal Information</h2>
        <div class="grid-2">
            <div class="form-group">
                <label class="form-label">Full Name</label>
                <input type="text" name="name" class="form-input" value="<?= esc($profile['name'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" class="form-input" value="<?= esc($profile['email'] ?? '') ?>" disabled>
                <span style="font-size:0.75rem; color:var(--gray-500);">Email cannot be changed.</span>
            </div>
            <div class="form-group">
                <label class="form-label">Phone</label>
                <input type="tel" name="phone" class="form-input" value="<?= esc($profile['phone'] ?? '') ?>">
            </div>
        </div>
    </div>

    <div class="glass-card" style="padding:24px; margin-bottom:20px;">
        <h2 style="font-size:1.125rem; font-weight:600; margin-bottom:16px;">Change Password <span style="font-size:0.75rem; color:var(--gray-500); font-weight:400;">(leave blank to keep current)</span></h2>
        <div class="grid-2">
            <div class="form-group">
                <label class="form-label">Current Password</label>
                <input type="password" name="current_password" class="form-input" placeholder="Enter current password">
            </div>
            <div class="form-group">
                <label class="form-label">New Password</label>
                <input type="password" name="new_password" class="form-input" placeholder="Enter new password">
            </div>
        </div>
    </div>

    <div class="glass-card" style="padding:24px; margin-bottom:20px;">
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:16px;">
            <h2 style="font-size:1.125rem; font-weight:600;">Education</h2>
            <button type="button" onclick="addEducation()" class="btn btn-sm" style="background:var(--primary); color:#fff; border:none; padding:6px 14px; border-radius:8px; cursor:pointer; font-size:0.813rem;"><i class="fas fa-plus"></i> Add Education</button>
        </div>
        <div id="education-container">
            <?php if (!empty($educations)): ?>
            <?php foreach ($educations as $i => $e): ?>
            <div class="edu-row" style="padding:16px; margin-bottom:12px; border:1px solid var(--gray-200); border-radius:10px; background:var(--gray-50);">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                    <strong style="font-size:0.875rem;">Education #<?= $i + 1 ?></strong>
                    <button type="button" onclick="this.closest('.edu-row').remove()" style="background:none; border:none; color:#ef4444; cursor:pointer; font-size:0.813rem;"><i class="fas fa-trash-alt"></i> Remove</button>
                </div>
                <div class="grid-2">
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Degree</label><input type="text" name="educations[<?= $i ?>][degree]" class="form-input" value="<?= esc($e['degree'] ?? '') ?>" placeholder="e.g. B.Tech, MBA"></div>
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Institution</label><input type="text" name="educations[<?= $i ?>][institution]" class="form-input" value="<?= esc($e['institution'] ?? '') ?>" placeholder="College / School name"></div>
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Board / University</label><input type="text" name="educations[<?= $i ?>][board]" class="form-input" value="<?= esc($e['board'] ?? '') ?>" placeholder="e.g. CBSE, RTU"></div>
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Year From</label><input type="number" name="educations[<?= $i ?>][year_from]" class="form-input" value="<?= esc($e['year_from'] ?? '') ?>" placeholder="2020" min="1900" max="2099"></div>
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Year To</label><input type="number" name="educations[<?= $i ?>][year_to]" class="form-input" value="<?= esc($e['year_to'] ?? '') ?>" placeholder="2024" min="1900" max="2099"></div>
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Percentage / CGPA</label><input type="number" step="0.01" name="educations[<?= $i ?>][percentage]" class="form-input" value="<?= esc($e['percentage'] ?? '') ?>" placeholder="85.5"></div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <?php if (empty($educations)): ?>
        <p style="text-align:center; color:var(--gray-500); font-size:0.875rem; padding:20px 0;" id="edu-empty">No education added yet.</p>
        <?php endif; ?>
    </div>

    <div class="glass-card" style="padding:24px; margin-bottom:20px;">
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:16px;">
            <h2 style="font-size:1.125rem; font-weight:600;">Experience</h2>
            <button type="button" onclick="addExperience()" class="btn btn-sm" style="background:var(--primary); color:#fff; border:none; padding:6px 14px; border-radius:8px; cursor:pointer; font-size:0.813rem;"><i class="fas fa-plus"></i> Add Experience</button>
        </div>
        <div id="experience-container">
            <?php if (!empty($experiences)): ?>
            <?php foreach ($experiences as $i => $e): ?>
            <div class="exp-row" style="padding:16px; margin-bottom:12px; border:1px solid var(--gray-200); border-radius:10px; background:var(--gray-50);">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                    <strong style="font-size:0.875rem;">Experience #<?= $i + 1 ?></strong>
                    <button type="button" onclick="this.closest('.exp-row').remove()" style="background:none; border:none; color:#ef4444; cursor:pointer; font-size:0.813rem;"><i class="fas fa-trash-alt"></i> Remove</button>
                </div>
                <div class="grid-2">
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Company</label><input type="text" name="experiences[<?= $i ?>][company]" class="form-input" value="<?= esc($e['company'] ?? '') ?>" placeholder="Company name"></div>
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Role / Designation</label><input type="text" name="experiences[<?= $i ?>][role]" class="form-input" value="<?= esc($e['role'] ?? '') ?>" placeholder="e.g. Software Engineer"></div>
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Location</label><input type="text" name="experiences[<?= $i ?>][location]" class="form-input" value="<?= esc($e['location'] ?? '') ?>" placeholder="City, State"></div>
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">From Date</label><input type="date" name="experiences[<?= $i ?>][from_date]" class="form-input" value="<?= esc($e['from_date'] ?? '') ?>"></div>
                    <div class="form-group"><label class="form-label" style="font-size:0.75rem;">To Date</label><input type="date" name="experiences[<?= $i ?>][to_date]" class="form-input" value="<?= esc($e['to_date'] ?? '') ?>" id="to_date_<?= $i ?>"></div>
                    <div class="form-group" style="display:flex; align-items:flex-end; padding-bottom:8px;">
                        <label style="display:flex; align-items:center; gap:8px; font-size:0.813rem; cursor:pointer;">
                            <input type="checkbox" name="experiences[<?= $i ?>][is_current]" value="1" onchange="toggleToDate(this, 'to_date_<?= $i ?>')" <?= !empty($e['is_current']) ? 'checked' : '' ?>>
                            Currently working here
                        </label>
                    </div>
                </div>
                <div class="form-group" style="margin-top:4px;">
                    <label class="form-label" style="font-size:0.75rem;">Description</label>
                    <textarea name="experiences[<?= $i ?>][description]" class="form-textarea" rows="2" placeholder="Brief description of your role and responsibilities"><?= esc($e['description'] ?? '') ?></textarea>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <?php if (empty($experiences)): ?>
        <p style="text-align:center; color:var(--gray-500); font-size:0.875rem; padding:20px 0;" id="exp-empty">No experience added yet.</p>
        <?php endif; ?>
    </div>

    <div style="text-align:center;">
        <button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-save"></i> Save All Changes</button>
    </div>
</form>

<script>
var eduIdx = <?= count($educations) ?>;
var expIdx = <?= count($experiences) ?>;

function addEducation() {
    var container = document.getElementById('education-container');
    var i = eduIdx++;
    var div = document.createElement('div');
    div.className = 'edu-row';
    div.style.cssText = 'padding:16px; margin-bottom:12px; border:1px solid var(--gray-200); border-radius:10px; background:var(--gray-50);';
    div.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
            <strong style="font-size:0.875rem;">Education #${i + 1}</strong>
            <button type="button" onclick="this.closest('.edu-row').remove()" style="background:none; border:none; color:#ef4444; cursor:pointer; font-size:0.813rem;"><i class="fas fa-trash-alt"></i> Remove</button>
        </div>
        <div class="grid-2">
            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Degree</label><input type="text" name="educations[${i}][degree]" class="form-input" placeholder="e.g. B.Tech, MBA"></div>
            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Institution</label><input type="text" name="educations[${i}][institution]" class="form-input" placeholder="College / School name"></div>
            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Board / University</label><input type="text" name="educations[${i}][board]" class="form-input" placeholder="e.g. CBSE, RTU"></div>
            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Year From</label><input type="number" name="educations[${i}][year_from]" class="form-input" placeholder="2020" min="1900" max="2099"></div>
            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Year To</label><input type="number" name="educations[${i}][year_to]" class="form-input" placeholder="2024" min="1900" max="2099"></div>
            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Percentage / CGPA</label><input type="number" step="0.01" name="educations[${i}][percentage]" class="form-input" placeholder="85.5"></div>
        </div>
    `;
    container.appendChild(div);
    document.getElementById('edu-empty')?.remove();
}

function addExperience() {
    var container = document.getElementById('experience-container');
    var i = expIdx++;
    var div = document.createElement('div');
    div.className = 'exp-row';
    div.style.cssText = 'padding:16px; margin-bottom:12px; border:1px solid var(--gray-200); border-radius:10px; background:var(--gray-50);';
    div.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
            <strong style="font-size:0.875rem;">Experience #${i + 1}</strong>
            <button type="button" onclick="this.closest('.exp-row').remove()" style="background:none; border:none; color:#ef4444; cursor:pointer; font-size:0.813rem;"><i class="fas fa-trash-alt"></i> Remove</button>
        </div>
        <div class="grid-2">
            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Company</label><input type="text" name="experiences[${i}][company]" class="form-input" placeholder="Company name"></div>
            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Role / Designation</label><input type="text" name="experiences[${i}][role]" class="form-input" placeholder="e.g. Software Engineer"></div>
            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">Location</label><input type="text" name="experiences[${i}][location]" class="form-input" placeholder="City, State"></div>
            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">From Date</label><input type="date" name="experiences[${i}][from_date]" class="form-input"></div>
            <div class="form-group"><label class="form-label" style="font-size:0.75rem;">To Date</label><input type="date" name="experiences[${i}][to_date]" class="form-input" id="to_date_${i}"></div>
            <div class="form-group" style="display:flex; align-items:flex-end; padding-bottom:8px;">
                <label style="display:flex; align-items:center; gap:8px; font-size:0.813rem; cursor:pointer;">
                    <input type="checkbox" name="experiences[${i}][is_current]" value="1" onchange="toggleToDate(this, 'to_date_${i}')">
                    Currently working here
                </label>
            </div>
        </div>
        <div class="form-group" style="margin-top:4px;">
            <label class="form-label" style="font-size:0.75rem;">Description</label>
            <textarea name="experiences[${i}][description]" class="form-textarea" rows="2" placeholder="Brief description of your role and responsibilities"></textarea>
        </div>
    `;
    container.appendChild(div);
    document.getElementById('exp-empty')?.remove();
}

function toggleToDate(checkbox, toDateId) {
    var input = document.getElementById(toDateId);
    if (checkbox.checked) {
        input.value = '';
        input.disabled = true;
    } else {
        input.disabled = false;
    }
}
</script>
