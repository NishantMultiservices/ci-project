<section class="section" style="padding-top:120px;">
    <div class="container" style="max-width:800px;">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Blog', 'url' => base_url('blog')], ['name' => $blog['title']]]]) ?>
        <article>
            <div style="margin-bottom:32px;">
                <div style="font-size:0.813rem; color:var(--primary); font-weight:600; margin-bottom:12px;"><?= date('d M Y', strtotime($blog['published_at'] ?? $blog['created_at'])) ?> &middot; By <?= esc($blog['author_name'] ?? 'RojgarSandhi Team') ?></div>
                <h1 style="font-size:2rem; font-weight:800; line-height:1.2; margin-bottom:16px;"><?= esc($blog['title']) ?></h1>
                <?php if ($blog['excerpt']): ?><p style="font-size:1.125rem; color:var(--gray-500); line-height:1.7;"><?= esc($blog['excerpt']) ?></p><?php endif; ?>
            </div>
            <div style="height:300px; background:linear-gradient(135deg,#6366f1,#8b5cf6); border-radius:16px; display:flex; align-items:center; justify-content:center; color:rgba(255,255,255,0.2); font-size:4rem; margin-bottom:32px;"><i class="fas fa-newspaper"></i></div>
            <div style="font-size:1.063rem; color:var(--gray-600); line-height:1.9;"><?= $blog['content'] ?></div>
            <?php if ($blog['tags']): ?><div style="margin-top:32px; display:flex; gap:8px; flex-wrap:wrap;"><?php foreach (explode(',', $blog['tags']) as $tag): ?><span class="job-tag">#<?= trim(esc($tag)) ?></span><?php endforeach; ?></div><?php endif; ?>
        </article>
        <?php if (!empty($related_blogs)): ?>
        <div style="margin-top:48px; padding-top:32px; border-top:1px solid var(--gray-200);">
            <h3 style="margin-bottom:20px;">Related Articles</h3>
            <div class="grid-3"><?php foreach ($related_blogs as $rb): ?><div class="glass-card" style="padding:20px;"><h4 style="font-size:0.938rem; margin-bottom:8px;"><a href="<?= base_url('blog/' . $rb['slug']) ?>" style="color:var(--gray-900); text-decoration:none;"><?= esc($rb['title']) ?></a></h4><p style="font-size:0.813rem; color:var(--gray-500);"><?= date('d M Y', strtotime($rb['published_at'] ?? $rb['created_at'])) ?></p></div><?php endforeach; ?></div>
        </div>
        <?php endif; ?>
    </div>
</section>
