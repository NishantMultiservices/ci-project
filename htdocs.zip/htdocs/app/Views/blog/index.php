<section class="section" style="padding-top:120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Blog']]]) ?>
        <div class="section-header">
            <span class="section-label">Blog</span>
            <h1 class="section-title">Latest <span class="gradient-text">Articles</span></h1>
            <p class="section-desc">Career tips, exam strategies, industry insights, and more.</p>
        </div>
        <div class="grid-3">
            <?php foreach ($blogs as $blog): ?>
            <div class="glass-card" style="overflow:hidden;">
                <div style="height:200px; background:linear-gradient(135deg,#6366f1,#8b5cf6); display:flex; align-items:center; justify-content:center; color:rgba(255,255,255,0.3); font-size:3rem;"><i class="fas fa-newspaper"></i></div>
                <div style="padding:24px;">
                    <div style="font-size:0.75rem; color:var(--primary); font-weight:600; margin-bottom:8px;"><?= date('d M Y', strtotime($blog['published_at'] ?? $blog['created_at'])) ?></div>
                    <h3 style="font-size:1.063rem; font-weight:700; margin-bottom:8px;"><a href="<?= base_url('blog/' . $blog['slug']) ?>" style="color:var(--gray-900); text-decoration:none;"><?= esc($blog['title']) ?></a></h3>
                    <p style="font-size:0.875rem; color:var(--gray-500); margin-bottom:16px; line-height:1.6;"><?= esc(truncate_text(strip_tags($blog['excerpt'] ?? ''), 120)) ?></p>
                    <a href="<?= base_url('blog/' . $blog['slug']) ?>" class="btn btn-secondary btn-sm">Read More <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
