<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redirecting to Payment...</title>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family:'Inter',sans-serif; background:#f8fafc; display:flex; align-items:center; justify-content:center; min-height:100vh; }
        .loader { text-align:center; }
        .spinner { width:48px; height:48px; border:4px solid #e2e8f0; border-top-color:#6366f1; border-radius:50%; animation:spin 0.8s linear infinite; margin:0 auto 16px; }
        @keyframes spin { to { transform:rotate(360deg); } }
        p { color:#64748b; font-size:0.9rem; }
    </style>
</head>
<body>
    <div class="loader">
        <div class="spinner"></div>
        <p>Redirecting to payment gateway...</p>
    </div>
    <?php if (isset($redirectUrl)): ?>
    <form id="redirect-form" action="<?= esc($redirectUrl) ?>" method="GET"></form>
    <script>document.getElementById('redirect-form').submit();</script>
    <?php endif; ?>
</body>
</html>
