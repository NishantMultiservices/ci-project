<section class="section" style="padding-top:120px;">
    <div class="container">
        <div class="glass-card" style="max-width:480px; margin:0 auto; padding:48px 32px; text-align:center;">
            <div style="width:72px; height:72px; border-radius:50%; background:rgba(239,68,68,0.1); display:flex; align-items:center; justify-content:center; margin:0 auto 16px;">
                <i class="fas fa-times-circle" style="font-size:2rem; color:#ef4444;"></i>
            </div>
            <h2 style="font-size:1.25rem; font-weight:700; margin-bottom:8px;">Payment Failed</h2>
            <p style="color:var(--gray-500); font-size:0.875rem; margin-bottom:24px;"><?= session('error') ?? 'Your payment could not be processed. Please try again.' ?></p>
            <a href="javascript:history.back()" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Try Again</a>
        </div>
    </div>
</section>
