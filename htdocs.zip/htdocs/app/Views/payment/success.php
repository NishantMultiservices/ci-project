<section class="section" style="padding-top:120px;">
    <div class="container">
        <div class="glass-card" style="max-width:480px; margin:0 auto; padding:48px 32px; text-align:center;">
            <div style="width:72px; height:72px; border-radius:50%; background:rgba(16,185,129,0.1); display:flex; align-items:center; justify-content:center; margin:0 auto 16px;">
                <i class="fas fa-check-circle" style="font-size:2rem; color:var(--success);"></i>
            </div>
            <h2 style="font-size:1.25rem; font-weight:700; margin-bottom:8px;">Payment Successful!</h2>
            <p style="color:var(--gray-500); font-size:0.875rem; margin-bottom:24px;">Your payment has been processed successfully. You now have access to your content.</p>
            <a href="<?= session('payment_redirect') ?? base_url('dashboard/my-courses') ?>" class="btn btn-primary"><i class="fas fa-arrow-right"></i> Continue</a>
        </div>
    </div>
</section>
