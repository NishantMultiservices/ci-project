<!-- Hero Section -->
<section class="hero-section">
    <div class="hero-bg"></div>
    
    <!-- Floating Particles -->
    <div class="hero-particles">
        <div class="particle" style="width: 300px; height: 300px; top: -100px; right: -100px; animation-delay: 0s;"></div>
        <div class="particle" style="width: 200px; height: 200px; bottom: 100px; left: -50px; animation-delay: 2s; background: var(--gradient-2);"></div>
        <div class="particle" style="width: 150px; height: 150px; top: 200px; right: 200px; animation-delay: 4s; background: var(--gradient-4);"></div>
        <div class="particle" style="width: 100px; height: 100px; bottom: 300px; right: 100px; animation-delay: 1s; background: var(--gradient-3);"></div>
    </div>
    
    <!-- Floating Elements -->
    <div style="position:absolute; top:12%; left:2%; font-size:1.4rem; color:rgba(99,102,241,0.18); animation:float 5s ease-in-out infinite; z-index:0; background:rgba(255,255,255,0.55); backdrop-filter:blur(8px); padding:10px 14px; border-radius:12px; border:1px solid rgba(99,102,241,0.1);"><i class="fas fa-briefcase"></i> <span style="font-size:0.7rem;font-weight:600;">50K+ Jobs</span></div>
    <div style="position:absolute; top:68%; right:4%; font-size:1.4rem; color:rgba(6,182,212,0.18); animation:float 7s ease-in-out infinite; z-index:0; background:rgba(255,255,255,0.55); backdrop-filter:blur(8px); padding:10px 14px; border-radius:12px; border:1px solid rgba(6,182,212,0.1);"><i class="fas fa-graduation-cap"></i> <span style="font-size:0.7rem;font-weight:600;">1000+ Courses</span></div>
    <div style="position:absolute; bottom:28%; left:4%; font-size:1.4rem; color:rgba(139,92,246,0.18); animation:float 6s ease-in-out infinite reverse; z-index:0; background:rgba(255,255,255,0.55); backdrop-filter:blur(8px); padding:10px 14px; border-radius:12px; border:1px solid rgba(139,92,246,0.1);"><i class="fas fa-chart-line"></i> <span style="font-size:0.7rem;font-weight:600;">Career Growth</span></div>
    <div style="position:absolute; top:38%; right:2%; font-size:1.2rem; color:rgba(16,185,129,0.18); animation:float 4s ease-in-out infinite; z-index:0; background:rgba(255,255,255,0.55); backdrop-filter:blur(8px); padding:9px 12px; border-radius:12px; border:1px solid rgba(16,185,129,0.1);"><i class="fas fa-ticket-alt"></i> <span style="font-size:0.7rem;font-weight:600;">Hall Tickets</span></div>
    <div style="position:absolute; top:6%; right:18%; font-size:1.2rem; color:rgba(245,158,11,0.18); animation:float 8s ease-in-out infinite reverse; z-index:0; background:rgba(255,255,255,0.55); backdrop-filter:blur(8px); padding:9px 12px; border-radius:12px; border:1px solid rgba(245,158,11,0.1);"><i class="fas fa-key"></i> <span style="font-size:0.7rem;font-weight:600;">Answer Keys</span></div>
    <div style="position:absolute; bottom:8%; right:14%; font-size:1.2rem; color:rgba(239,68,68,0.18); animation:float 5s ease-in-out infinite; z-index:0; background:rgba(255,255,255,0.55); backdrop-filter:blur(8px); padding:9px 12px; border-radius:12px; border:1px solid rgba(239,68,68,0.1);"><i class="fas fa-poll"></i> <span style="font-size:0.7rem;font-weight:600;">Results</span></div>
    <div style="position:absolute; top:52%; left:1%; font-size:1.1rem; color:rgba(99,102,241,0.18); animation:float 6s ease-in-out infinite; z-index:0; background:rgba(255,255,255,0.55); backdrop-filter:blur(8px); padding:9px 12px; border-radius:12px; border:1px solid rgba(99,102,241,0.1);"><i class="fas fa-vial"></i> <span style="font-size:0.7rem;font-weight:600;">Mock Tests</span></div>
    <div style="position:absolute; bottom:42%; left:14%; font-size:1.1rem; color:rgba(16,185,129,0.18); animation:float 7s ease-in-out infinite reverse; z-index:0; background:rgba(255,255,255,0.55); backdrop-filter:blur(8px); padding:9px 12px; border-radius:12px; border:1px solid rgba(16,185,129,0.1);"><i class="fas fa-user-graduate"></i> <span style="font-size:0.7rem;font-weight:600;">Internships</span></div>
    <div style="position:absolute; top:5%; right:36%; font-size:1rem; color:rgba(245,158,11,0.18); animation:float 5s ease-in-out infinite; z-index:0; background:rgba(255,255,255,0.55); backdrop-filter:blur(8px); padding:8px 11px; border-radius:10px; border:1px solid rgba(245,158,11,0.1);"><i class="fas fa-tools"></i> <span style="font-size:0.65rem;font-weight:600;">Apprenticeships</span></div>
    <div style="position:absolute; bottom:18%; left:22%; font-size:1.1rem; color:rgba(6,182,212,0.18); animation:float 4s ease-in-out infinite reverse; z-index:0; background:rgba(255,255,255,0.55); backdrop-filter:blur(8px); padding:9px 12px; border-radius:12px; border:1px solid rgba(6,182,212,0.1);"><i class="fas fa-dollar-sign"></i> <span style="font-size:0.7rem;font-weight:600;">Scholarships</span></div>
    <div style="position:absolute; top:22%; left:12%; font-size:1rem; color:rgba(139,92,246,0.18); animation:float 7s ease-in-out infinite; z-index:0; background:rgba(255,255,255,0.55); backdrop-filter:blur(8px); padding:8px 11px; border-radius:10px; border:1px solid rgba(139,92,246,0.1);"><i class="fas fa-file-alt"></i> <span style="font-size:0.65rem;font-weight:600;">Resume Builder</span></div>
    <div style="position:absolute; top:78%; right:18%; font-size:1rem; color:rgba(236,72,153,0.16); animation:float 6s ease-in-out infinite; z-index:0; background:rgba(255,255,255,0.5); backdrop-filter:blur(8px); padding:8px 11px; border-radius:10px; border:1px solid rgba(236,72,153,0.1);"><i class="fas fa-bolt"></i> <span style="font-size:0.65rem;font-weight:600;">Fast Updates</span></div>
    <div style="position:absolute; top:45%; left:22%; font-size:1rem; color:rgba(99,102,241,0.16); animation:float 5s ease-in-out infinite reverse; z-index:0; background:rgba(255,255,255,0.5); backdrop-filter:blur(8px); padding:8px 11px; border-radius:10px; border:1px solid rgba(99,102,241,0.1);"><i class="fas fa-bell"></i> <span style="font-size:0.65rem;font-weight:600;">Job Alerts</span></div>
    <div style="position:absolute; top:18%; right:6%; font-size:0.95rem; color:rgba(16,185,129,0.16); animation:float 8s ease-in-out infinite; z-index:0; background:rgba(255,255,255,0.5); backdrop-filter:blur(8px); padding:7px 10px; border-radius:10px; border:1px solid rgba(16,185,129,0.1);"><i class="fas fa-pen-fancy"></i> <span style="font-size:0.6rem;font-weight:600;">Exam Tips</span></div>
    <div style="position:absolute; bottom:55%; left:6%; font-size:0.95rem; color:rgba(245,158,11,0.16); animation:float 4s ease-in-out infinite reverse; z-index:0; background:rgba(255,255,255,0.5); backdrop-filter:blur(8px); padding:7px 10px; border-radius:10px; border:1px solid rgba(245,158,11,0.1);"><i class="fas fa-star"></i> <span style="font-size:0.6rem;font-weight:600;">Top Rated</span></div>
    <div style="position:absolute; top:78%; left:28%; font-size:0.95rem; color:rgba(6,182,212,0.16); animation:float 7s ease-in-out infinite; z-index:0; background:rgba(255,255,255,0.5); backdrop-filter:blur(8px); padding:7px 10px; border-radius:10px; border:1px solid rgba(6,182,212,0.1);"><i class="fas fa-handshake"></i> <span style="font-size:0.6rem;font-weight:600;">Placements</span></div>
    <div style="position:absolute; top:60%; right:28%; font-size:0.95rem; color:rgba(139,92,246,0.16); animation:float 5s ease-in-out infinite reverse; z-index:0; background:rgba(255,255,255,0.5); backdrop-filter:blur(8px); padding:7px 10px; border-radius:10px; border:1px solid rgba(139,92,246,0.1);"><i class="fas fa-video"></i> <span style="font-size:0.6rem;font-weight:600;">Live Classes</span></div>
    <div style="position:absolute; bottom:35%; right:32%; font-size:0.95rem; color:rgba(239,68,68,0.16); animation:float 6s ease-in-out infinite; z-index:0; background:rgba(255,255,255,0.5); backdrop-filter:blur(8px); padding:7px 10px; border-radius:10px; border:1px solid rgba(239,68,68,0.1);"><i class="fas fa-file-pdf"></i> <span style="font-size:0.6rem;font-weight:600;">Free PDFs</span></div>
    <div style="position:absolute; top:32%; right:40%; font-size:0.9rem; color:rgba(99,102,241,0.14); animation:float 4s ease-in-out infinite; z-index:0; background:rgba(255,255,255,0.45); backdrop-filter:blur(8px); padding:6px 9px; border-radius:9px; border:1px solid rgba(99,102,241,0.08);"><i class="fas fa-clock"></i> <span style="font-size:0.6rem;font-weight:600;">Deadlines</span></div>
    <div style="position:absolute; bottom:68%; left:26%; font-size:0.9rem; color:rgba(16,185,129,0.14); animation:float 8s ease-in-out infinite reverse; z-index:0; background:rgba(255,255,255,0.45); backdrop-filter:blur(8px); padding:6px 9px; border-radius:9px; border:1px solid rgba(16,185,129,0.08);"><i class="fas fa-people-arrows"></i> <span style="font-size:0.6rem;font-weight:600;">Interview Prep</span></div>
    <div style="position:absolute; top:58%; left:34%; font-size:0.9rem; color:rgba(245,158,11,0.14); animation:float 5s ease-in-out infinite; z-index:0; background:rgba(255,255,255,0.45); backdrop-filter:blur(8px); padding:6px 9px; border-radius:9px; border:1px solid rgba(245,158,11,0.08);"><i class="fas fa-certificate"></i> <span style="font-size:0.6rem;font-weight:600;">Certificates</span></div>
    
    <div class="container">
        <div class="hero-content" style="display: grid; grid-template-columns: 1fr 1fr; gap: 60px; align-items: center;">
            <div class="animate-slide-left">
                <div class="hero-badge">
                    <i class="fas fa-rocket"></i>
                    India's Premier Career Platform
                </div>
                
                <h1 class="hero-title">
                    Your Gateway to <span class="gradient-text">Jobs, Skills</span> & Career Success
                </h1>
                
                <p class="hero-subtitle">
                    Discover thousands of government jobs, private sector opportunities, internships, apprenticeships, and skill development courses. Your dream career starts here.
                </p>
                
                <div class="hero-actions">
                    <a href="<?= base_url('jobs') ?>" class="btn btn-primary btn-lg">
                        <i class="fas fa-search"></i> Explore Jobs
                    </a>
                    <a href="<?= base_url('courses') ?>" class="btn btn-secondary btn-lg">
                        <i class="fas fa-play-circle"></i> Start Learning
                    </a>
                </div>
                
                <div class="hero-stats">
                    <div class="hero-stat animate-on-scroll">
                        <h3 class="stat-counter" data-target="50000">0</h3>
                        <p>Jobs Available</p>
                    </div>
                    <div class="hero-stat animate-on-scroll">
                        <h3 class="stat-counter" data-target="10000">0</h3>
                        <p>Active Students</p>
                    </div>
                    <div class="hero-stat animate-on-scroll">
                        <h3 class="stat-counter" data-target="1000">0</h3>
                        <p>Expert Courses</p>
                    </div>
                    <div class="hero-stat animate-on-scroll">
                        <h3 class="stat-counter" data-target="500">0</h3>
                        <p>Partner Companies</p>
                    </div>
                </div>
            </div>
            
            <!-- Hero Illustration -->
            <div class="animate-slide-right" style="position: relative;">
                <div class="glass-card" style="padding: 40px; text-align: center;">
                    <div style="font-size: 6rem; margin-bottom: 20px; opacity: 0.3;">
                        <i class="fas fa-user-tie"></i>
                    </div>
                    <div class="glass-card" style="position: absolute; top: 10%; right: -10%; padding: 16px 24px; animation: float 4s ease-in-out infinite;">
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <div style="width: 40px; height: 40px; border-radius: 10px; background: var(--gradient-2); display: flex; align-items: center; justify-content: center; color: white;">
                                <i class="fas fa-check"></i>
                            </div>
                            <div>
                                <div style="font-weight: 700; font-size: 0.875rem;">10,000+</div>
                                <div style="font-size: 0.75rem; color: var(--gray-500);">Placed Students</div>
                            </div>
                        </div>
                    </div>
                    <div class="glass-card" style="position: absolute; bottom: 15%; left: -10%; padding: 16px 24px; animation: float 5s ease-in-out infinite reverse;">
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <div style="width: 40px; height: 40px; border-radius: 10px; background: var(--gradient-3); display: flex; align-items: center; justify-content: center; color: white;">
                                <i class="fas fa-star"></i>
                            </div>
                            <div>
                                <div style="font-weight: 700; font-size: 0.875rem;">4.8 Rating</div>
                                <div style="font-size: 0.75rem; color: var(--gray-500);">User Reviews</div>
                            </div>
                        </div>
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-top: 24px;">
                        <div class="glass" style="padding: 20px 12px; border-radius: 12px; text-align: center;">
                            <i class="fas fa-landmark" style="font-size: 1.5rem; color: var(--primary); margin-bottom: 8px; display: block;"></i>
                            <span style="font-size: 0.75rem; font-weight: 600;">Govt Jobs</span>
                        </div>
                        <div class="glass" style="padding: 20px 12px; border-radius: 12px; text-align: center;">
                            <i class="fas fa-building" style="font-size: 1.5rem; color: var(--accent); margin-bottom: 8px; display: block;"></i>
                            <span style="font-size: 0.75rem; font-weight: 600;">Private Jobs</span>
                        </div>
                        <div class="glass" style="padding: 20px 12px; border-radius: 12px; text-align: center;">
                            <i class="fas fa-laptop-code" style="font-size: 1.5rem; color: var(--secondary); margin-bottom: 8px; display: block;"></i>
                            <span style="font-size: 0.75rem; font-weight: 600;">Internships</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- Quick Categories -->
<section class="section">
    <div class="container">
        <div class="section-header animate-on-scroll">
            <span class="section-label">Categories</span>
            <h2 class="section-title">Explore by <span class="gradient-text">Category</span></h2>
            <p class="section-desc">Browse thousands of opportunities across different sectors and industries.</p>
        </div>
        
        <div class="grid-6">
            <a href="<?= base_url('government-jobs') ?>" class="cat-card animate-on-scroll">
                <div class="cat-icon"><i class="fas fa-landmark"></i></div>
                <h3>Government</h3>
                <p>UPSC, SSC, Banking</p>
            </a>
            <a href="<?= base_url('private-jobs') ?>" class="cat-card animate-on-scroll">
                <div class="cat-icon" style="background: var(--gradient-2);"><i class="fas fa-building"></i></div>
                <h3>Private Jobs</h3>
                <p>IT, Finance, Marketing</p>
            </a>
            <a href="<?= base_url('internships') ?>" class="cat-card animate-on-scroll">
                <div class="cat-icon" style="background: var(--gradient-4);"><i class="fas fa-laptop-code"></i></div>
                <h3>Internships</h3>
                <p>Paid, Remote, Campus</p>
            </a>
            <a href="<?= base_url('apprenticeships') ?>" class="cat-card animate-on-scroll">
                <div class="cat-icon" style="background: var(--gradient-3);"><i class="fas fa-tools"></i></div>
                <h3>Apprenticeships</h3>
                <p>NAPS, NATS, Graduate</p>
            </a>
            <a href="<?= base_url('courses') ?>" class="cat-card animate-on-scroll">
                <div class="cat-icon" style="background: linear-gradient(135deg, #ec4899, #8b5cf6);"><i class="fas fa-graduation-cap"></i></div>
                <h3>Courses</h3>
                <p>Skill Development</p>
            </a>
            <a href="<?= base_url('scholarships') ?>" class="cat-card animate-on-scroll">
                <div class="cat-icon" style="background: linear-gradient(135deg, #f59e0b, #ef4444);"><i class="fas fa-award"></i></div>
                <h3>Scholarships</h3>
                <p>Government & Private</p>
            </a>
        </div>
    </div>
</section>

<!-- Government Jobs (Featured) -->
<section class="section" style="background: linear-gradient(135deg, rgba(99, 102, 241, 0.03) 0%, rgba(139, 92, 246, 0.05) 100%);">
    <div class="container">
        <div class="section-header animate-on-scroll">
            <span class="section-label">Government Jobs</span>
            <h2 class="section-title">Latest <span class="gradient-text">Government Jobs</span></h2>
            <p class="section-desc">Top Sarkari Naukri openings from central and state governments.</p>
        </div>
        
        <?php if (!empty($featured_jobs)): ?>
        <div class="grid-3">
            <?php foreach ($featured_jobs as $job): ?>
            <div class="job-card animate-on-scroll">
                <div class="job-card-header">
                    <div class="job-company-logo" style="background: rgba(16, 185, 129, 0.1); color: #059669;">
                        <?= strtoupper(substr($job['company_name'], 0, 2)) ?>
                    </div>
                    <div style="flex: 1;">
                        <h3 class="job-card-title">
                            <a href="<?= base_url('jobs/' . $job['id']) ?>"><?= esc($job['title']) ?></a>
                        </h3>
                        <div class="job-company">
                            <i class="fas fa-building" style="font-size: 0.75rem;"></i>
                            <?= esc($job['company_name']) ?>
                            <span style="margin: 0 8px;">|</span>
                            <i class="fas fa-map-marker-alt" style="font-size: 0.75rem;"></i>
                            <?= esc($job['location'] ?? 'Multiple Locations') ?>
                        </div>
                    </div>
                </div>
                <div class="job-card-body">
                    <div class="job-meta">
                        <span class="job-meta-item">
                            <i class="fas fa-money-bill-wave"></i>
                            <?= format_salary($job['salary_min'], $job['salary_max'], $job['salary_text']) ?>
                        </span>
                        <span class="job-meta-item">
                            <i class="fas fa-calendar-alt"></i>
                            <?= days_remaining($job['last_date_to_apply']) ?>
                        </span>
                    </div>
                    <div class="job-tags">
                        <span class="job-tag govt">Government</span>
                        <?php if ($job['total_vacancies']): ?><span class="job-tag"><?= $job['total_vacancies'] ?> Vacancies</span><?php endif; ?>
                    </div>
                </div>
                <div class="job-card-footer">
                    <a href="<?= base_url('jobs/' . $job['id']) ?>" class="btn btn-primary btn-sm">View Details</a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div style="text-align: center; padding: 60px; color: var(--gray-500);">
            <i class="fas fa-landmark" style="font-size: 3rem; margin-bottom: 16px; display: block; opacity: 0.3;"></i>
            <p>No government jobs at the moment. Check back soon!</p>
        </div>
        <?php endif; ?>
        
        <div style="text-align: center; margin-top: 32px;">
            <a href="<?= base_url('government-jobs') ?>" class="btn btn-primary btn-lg">
                <i class="fas fa-arrow-right"></i> View All Government Jobs
            </a>
        </div>
    </div>
</section>


<!-- Hall Ticket, Answer Key, Results -->
<section class="section">
    <div class="container">
        <div class="section-header animate-on-scroll">
            <span class="section-label">Quick Links</span>
            <h2 class="section-title">Exam <span class="gradient-text">Resources</span></h2>
            <p class="section-desc">Stay updated with the latest admit cards, answer keys, and exam results.</p>
        </div>
        <div class="grid-3">
            <div class="glass-card animate-on-scroll" style="padding:0;overflow:hidden;">
                <div style="background:linear-gradient(135deg,#6366f1,#8b5cf6);padding:20px 24px;display:flex;align-items:center;gap:14px;">
                    <div style="width:44px;height:44px;border-radius:12px;background:rgba(255,255,255,0.2);display:flex;align-items:center;justify-content:center;font-size:1.25rem;color:white;flex-shrink:0;"><i class="fas fa-ticket-alt"></i></div>
                    <div><h3 style="color:white;font-size:1.063rem;font-weight:700;">Hall Tickets</h3><p style="color:rgba(255,255,255,0.7);font-size:0.813rem;">Download admit cards</p></div>
                </div>
                <div style="padding:12px 16px;">
                    <?php if (!empty($admit_cards)): ?>
                    <ul style="list-style:none;padding:0;margin:0;">
                        <?php foreach ($admit_cards as $a): ?>
                        <li style="border-bottom:1px solid var(--gray-100);padding:10px 0;"><a href="<?= base_url('admit-cards/' . $a['id']) ?>" style="text-decoration:none;color:var(--gray-700);font-size:0.875rem;font-weight:500;display:flex;justify-content:space-between;align-items:center;"><span><?= esc($a['title']) ?></span><span style="font-size:0.75rem;color:var(--gray-400);"><?= $a['exam_date'] ? format_date($a['exam_date']) : '' ?></span></a></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php else: ?>
                    <p style="color:var(--gray-400);font-size:0.875rem;padding:20px 0;text-align:center;">No admit cards available</p>
                    <?php endif; ?>
                    <a href="<?= base_url('admit-cards') ?>" style="display:block;text-align:center;padding:12px;color:var(--primary);font-size:0.813rem;font-weight:600;text-decoration:none;">View All <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="glass-card animate-on-scroll" style="padding:0;overflow:hidden;">
                <div style="background:linear-gradient(135deg,#f59e0b,#ef4444);padding:20px 24px;display:flex;align-items:center;gap:14px;">
                    <div style="width:44px;height:44px;border-radius:12px;background:rgba(255,255,255,0.2);display:flex;align-items:center;justify-content:center;font-size:1.25rem;color:white;flex-shrink:0;"><i class="fas fa-key"></i></div>
                    <div><h3 style="color:white;font-size:1.063rem;font-weight:700;">Answer Keys</h3><p style="color:rgba(255,255,255,0.7);font-size:0.813rem;">Check answer keys</p></div>
                </div>
                <div style="padding:12px 16px;">
                    <?php if (!empty($answer_keys)): ?>
                    <ul style="list-style:none;padding:0;margin:0;">
                        <?php foreach ($answer_keys as $a): ?>
                        <li style="border-bottom:1px solid var(--gray-100);padding:10px 0;"><a href="<?= base_url('answer-keys/' . $a['id']) ?>" style="text-decoration:none;color:var(--gray-700);font-size:0.875rem;font-weight:500;display:flex;justify-content:space-between;align-items:center;"><span><?= esc($a['title']) ?></span><span style="font-size:0.75rem;color:var(--gray-400);"><?= $a['release_date'] ? format_date($a['release_date']) : '' ?></span></a></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php else: ?>
                    <p style="color:var(--gray-400);font-size:0.875rem;padding:20px 0;text-align:center;">No answer keys available</p>
                    <?php endif; ?>
                    <a href="<?= base_url('answer-keys') ?>" style="display:block;text-align:center;padding:12px;color:var(--primary);font-size:0.813rem;font-weight:600;text-decoration:none;">View All <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="glass-card animate-on-scroll" style="padding:0;overflow:hidden;">
                <div style="background:linear-gradient(135deg,#10b981,#06b6d4);padding:20px 24px;display:flex;align-items:center;gap:14px;">
                    <div style="width:44px;height:44px;border-radius:12px;background:rgba(255,255,255,0.2);display:flex;align-items:center;justify-content:center;font-size:1.25rem;color:white;flex-shrink:0;"><i class="fas fa-poll"></i></div>
                    <div><h3 style="color:white;font-size:1.063rem;font-weight:700;">Results</h3><p style="color:rgba(255,255,255,0.7);font-size:0.813rem;">Latest exam results</p></div>
                </div>
                <div style="padding:12px 16px;">
                    <?php if (!empty($latest_results)): ?>
                    <ul style="list-style:none;padding:0;margin:0;">
                        <?php foreach ($latest_results as $r): ?>
                        <li style="border-bottom:1px solid var(--gray-100);padding:10px 0;"><a href="<?= base_url('results/' . $r['id']) ?>" style="text-decoration:none;color:var(--gray-700);font-size:0.875rem;font-weight:500;display:flex;justify-content:space-between;align-items:center;"><span><?= esc($r['title']) ?></span><span style="font-size:0.75rem;color:var(--gray-400);"><?= $r['result_date'] ? format_date($r['result_date']) : '' ?></span></a></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php else: ?>
                    <p style="color:var(--gray-400);font-size:0.875rem;padding:20px 0;text-align:center;">No results available</p>
                    <?php endif; ?>
                    <a href="<?= base_url('results') ?>" style="display:block;text-align:center;padding:12px;color:var(--primary);font-size:0.813rem;font-weight:600;text-decoration:none;">View All <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Category Grid -->
<section class="section" style="background: linear-gradient(135deg, rgba(99, 102, 241, 0.03) 0%, rgba(139, 92, 246, 0.05) 100%);">
    <div class="container">
        <div class="section-header animate-on-scroll">
            <span class="section-label">Exam Categories</span>
            <h2 class="section-title">Popular <span class="gradient-text">Exam Categories</span></h2>
            <p class="section-desc">Prepare for India's top competitive exams and government job recruitment.</p>
        </div>
        
        <div class="grid-4">
            <a href="<?= base_url('jobs/category/upsc') ?>" class="cat-card animate-on-scroll" style="border-left: 4px solid #6366f1;">
                <div class="cat-icon" style="background: linear-gradient(135deg, #6366f1, #818cf8); width: 50px; height: 50px; font-size: 1.25rem;"><i class="fas fa-landmark"></i></div>
                <h3>UPSC</h3>
                <p>IAS, IPS, IFS & More</p>
            </a>
            <a href="<?= base_url('jobs/category/ssc') ?>" class="cat-card animate-on-scroll" style="border-left: 4px solid #10b981;">
                <div class="cat-icon" style="background: linear-gradient(135deg, #10b981, #34d399); width: 50px; height: 50px; font-size: 1.25rem;"><i class="fas fa-file-alt"></i></div>
                <h3>SSC</h3>
                <p>CGL, CHSL, GD & More</p>
            </a>
            <a href="<?= base_url('jobs/category/banking') ?>" class="cat-card animate-on-scroll" style="border-left: 4px solid #f59e0b;">
                <div class="cat-icon" style="background: linear-gradient(135deg, #f59e0b, #fbbf24); width: 50px; height: 50px; font-size: 1.25rem;"><i class="fas fa-university"></i></div>
                <h3>Banking</h3>
                <p>IBPS, SBI, RBI & More</p>
            </a>
            <a href="<?= base_url('jobs/category/railway') ?>" class="cat-card animate-on-scroll" style="border-left: 4px solid #ef4444;">
                <div class="cat-icon" style="background: linear-gradient(135deg, #ef4444, #f87171); width: 50px; height: 50px; font-size: 1.25rem;"><i class="fas fa-train"></i></div>
                <h3>Railway</h3>
                <p>RRB NTPC, ALP & More</p>
            </a>
            <a href="<?= base_url('jobs/category/police') ?>" class="cat-card animate-on-scroll" style="border-left: 4px solid #3b82f6;">
                <div class="cat-icon" style="background: linear-gradient(135deg, #3b82f6, #60a5fa); width: 50px; height: 50px; font-size: 1.25rem;"><i class="fas fa-shield-alt"></i></div>
                <h3>Police</h3>
                <p>Constable, SI & More</p>
            </a>
            <a href="<?= base_url('jobs/category/defence') ?>" class="cat-card animate-on-scroll" style="border-left: 4px solid #059669;">
                <div class="cat-icon" style="background: linear-gradient(135deg, #059669, #10b981); width: 50px; height: 50px; font-size: 1.25rem;"><i class="fas fa-crosshairs"></i></div>
                <h3>Defence</h3>
                <p>Army, Navy, Air Force</p>
            </a>
            <a href="<?= base_url('jobs/category/state-government') ?>" class="cat-card animate-on-scroll" style="border-left: 4px solid #8b5cf6;">
                <div class="cat-icon" style="background: linear-gradient(135deg, #8b5cf6, #a78bfa); width: 50px; height: 50px; font-size: 1.25rem;"><i class="fas fa-map-pin"></i></div>
                <h3>State Govt</h3>
                <p>State PSC & More</p>
            </a>
            <a href="<?= base_url('jobs/category/all-jobs') ?>" class="cat-card animate-on-scroll" style="border-left: 4px solid #06b6d4;">
                <div class="cat-icon" style="background: linear-gradient(135deg, #06b6d4, #22d3ee); width: 50px; height: 50px; font-size: 1.25rem;"><i class="fas fa-th-large"></i></div>
                <h3>All Jobs</h3>
                <p>Browse All Categories</p>
            </a>
        </div>
    </div>
</section>

<!-- Courses Section -->
<section class="section">
    <div class="container">
        <div class="section-header animate-on-scroll">
            <span class="section-label">Skill Development</span>
            <h2 class="section-title">Popular <span class="gradient-text">Courses</span></h2>
            <p class="section-desc">Upskill yourself with industry-relevant courses designed for career growth.</p>
        </div>
        
        <div class="grid-4">
            <?php
            $course_list = [
                ['title' => 'Programming', 'icon' => 'fa-code', 'gradient' => '6366f1, 8b5cf6'],
                ['title' => 'AI & Machine Learning', 'icon' => 'fa-robot', 'gradient' => 'ec4899, 8b5cf6'],
                ['title' => 'Data Science', 'icon' => 'fa-chart-bar', 'gradient' => '10b981, 06b6d4'],
                ['title' => 'Cyber Security', 'icon' => 'fa-shield-halved', 'gradient' => 'ef4444, f59e0b'],
                ['title' => 'Web Development', 'icon' => 'fa-globe', 'gradient' => '3b82f6, 6366f1'],
                ['title' => 'Digital Marketing', 'icon' => 'fa-chart-line', 'gradient' => 'f59e0b, ef4444'],
                ['title' => 'Cloud Computing', 'icon' => 'fa-cloud', 'gradient' => '06b6d4, 3b82f6'],
                ['title' => 'Excel & Analytics', 'icon' => 'fa-table', 'gradient' => '10b981, 34d399'],
            ];
            ?>
            <?php foreach ($course_list as $course): ?>
            <div class="course-card animate-on-scroll">
                <div class="course-thumb" style="background: linear-gradient(135deg, #<?= str_replace(', ', ', #', $course['gradient']) ?>);">
                    <i class="fas <?= $course['icon'] ?>"></i>
                    <span class="course-badge free">Free</span>
                </div>
                <div class="course-body">
                    <h3><?= $course['title'] ?></h3>
                    <div class="course-instructor"><i class="fas fa-user-tie"></i> Expert Instructors</div>
                    <div class="course-meta">
                        <span class="course-rating"><i class="fas fa-star"></i> 4.8</span>
                        <span class="course-students"><i class="fas fa-users"></i> 2.5K+</span>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div style="text-align: center; margin-top: 32px;">
            <a href="<?= base_url('courses') ?>" class="btn btn-primary btn-lg">
                <i class="fas fa-graduation-cap"></i> Explore All Courses
            </a>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="section" style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%); color: white;">
    <div class="container">
        <div class="grid-4" style="text-align: center;">
            <div class="stat-card animate-on-scroll">
                <div style="font-size: 2.5rem; margin-bottom: 8px; color: #818cf8;"><i class="fas fa-briefcase"></i></div>
                <div class="stat-number stat-counter" data-target="50000" style="background: linear-gradient(135deg, #818cf8, #a5b4fc); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">0</div>
                <div class="stat-label" style="color: #94a3b8;">Jobs Available</div>
            </div>
            <div class="stat-card animate-on-scroll">
                <div style="font-size: 2.5rem; margin-bottom: 8px; color: #34d399;"><i class="fas fa-users"></i></div>
                <div class="stat-number stat-counter" data-target="10000" style="background: linear-gradient(135deg, #34d399, #6ee7b7); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">0</div>
                <div class="stat-label" style="color: #94a3b8;">Active Students</div>
            </div>
            <div class="stat-card animate-on-scroll">
                <div style="font-size: 2.5rem; margin-bottom: 8px; color: #fbbf24;"><i class="fas fa-book-open"></i></div>
                <div class="stat-number stat-counter" data-target="1000" style="background: linear-gradient(135deg, #fbbf24, #fde68a); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">0</div>
                <div class="stat-label" style="color: #94a3b8;">Expert Courses</div>
            </div>
            <div class="stat-card animate-on-scroll">
                <div style="font-size: 2.5rem; margin-bottom: 8px; color: #f87171;"><i class="fas fa-building"></i></div>
                <div class="stat-number stat-counter" data-target="500" style="background: linear-gradient(135deg, #f87171, #fca5a5); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">0</div>
                <div class="stat-label" style="color: #94a3b8;">Partner Companies</div>
            </div>
        </div>
    </div>
</section>

<!-- Private Jobs Section -->
<section class="section">
    <div class="container">
        <div class="section-header animate-on-scroll">
            <span class="section-label" style="background: rgba(59, 130, 246, 0.1); color: #2563eb;">Corporate</span>
            <h2 class="section-title">Top <span class="gradient-text">Private Jobs</span></h2>
            <p class="section-desc">Exciting opportunities from India's leading companies and global tech giants.</p>
        </div>
        
        <div class="grid-4" style="margin-bottom: 40px;">
            <?php
            $companies = ['TCS', 'Infosys', 'Wipro', 'Accenture', 'Capgemini', 'Amazon', 'Google', 'Microsoft'];
            ?>
            <?php foreach ($companies as $company): ?>
            <a href="<?= base_url('search?q=' . $company) ?>" class="cat-card animate-on-scroll" style="padding: 20px;">
                <div class="job-company-logo" style="margin: 0 auto 12px; width: 48px; height: 48px; font-size: 1rem;">
                    <?= substr($company, 0, 2) ?>
                </div>
                <h3 style="font-size: 0.938rem;"><?= $company ?></h3>
                <p style="font-size: 0.75rem;">View Openings</p>
            </a>
            <?php endforeach; ?>
        </div>
        
        <?php if (!empty($private_jobs)): ?>
        <div class="grid-3">
            <?php foreach ($private_jobs as $job): ?>
            <div class="job-card animate-on-scroll">
                <div class="job-card-header">
                    <div class="job-company-logo" style="background: rgba(59, 130, 246, 0.1); color: #2563eb;">
                        <?= strtoupper(substr($job['company_name'], 0, 2)) ?>
                    </div>
                    <div style="flex: 1;">
                        <h3 class="job-card-title">
                            <a href="<?= base_url('jobs/' . $job['id']) ?>"><?= esc($job['title']) ?></a>
                        </h3>
                        <div class="job-company"><?= esc($job['company_name']) ?></div>
                    </div>
                </div>
                <div class="job-card-body">
                    <div class="job-meta">
                        <span class="job-meta-item"><i class="fas fa-money-bill-wave"></i> <?= format_salary($job['salary_min'], $job['salary_max'], $job['salary_text']) ?></span>
                        <span class="job-meta-item"><i class="fas fa-map-marker-alt"></i> <?= esc($job['location'] ?? 'Multiple') ?></span>
                    </div>
                    <div class="job-tags">
                        <span class="job-tag private">Private</span>
                        <?php if ($job['is_featured']): ?><span class="job-tag" style="background: rgba(245, 158, 11, 0.1); color: #d97706;">Featured</span><?php endif; ?>
                    </div>
                </div>
                <div class="job-card-footer">
                    <a href="<?= base_url('jobs/' . $job['id']) ?>" class="btn btn-primary btn-sm">Apply</a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Internships & Apprenticeships -->
<section class="section" style="background: linear-gradient(135deg, rgba(99, 102, 241, 0.03) 0%, rgba(139, 92, 246, 0.05) 100%);">
    <div class="container">
        <div class="section-header animate-on-scroll">
            <span class="section-label">Growth</span>
            <h2 class="section-title">Internships & <span class="gradient-text">Apprenticeships</span></h2>
            <p class="section-desc">Kickstart your career with hands-on experience through internships and apprenticeships.</p>
        </div>
        
        <?php if (!empty($internships)): ?>
        <div class="grid-3">
            <?php foreach ($internships as $internship): ?>
            <div class="course-card animate-on-scroll">
                <div class="course-thumb" style="background: linear-gradient(135deg, #06b6d4, #3b82f6); height: 120px;">
                    <div style="text-align: center;">
                        <i class="fas fa-laptop-code" style="font-size: 2rem;"></i>
                        <div style="font-size: 0.875rem; margin-top: 8px; font-weight: 600;"><?= esc($internship['company_name']) ?></div>
                    </div>
                    <span class="course-badge free" style="background: rgba(16, 185, 129, 0.9);">
                        <?= ucfirst($internship['type']) ?>
                    </span>
                </div>
                <div class="course-body">
                    <h3><?= esc($internship['title']) ?></h3>
                    <div class="course-instructor">
                        <i class="fas fa-map-marker-alt"></i> <?= esc($internship['location'] ?? 'Remote') ?>
                        <span style="margin: 0 8px;">|</span>
                        <i class="fas fa-clock"></i> <?= esc($internship['duration'] ?? '3 months') ?>
                    </div>
                    <div class="course-meta">
                        <span style="font-weight: 600; color: var(--success);">
                            <?= format_salary($internship['stipend_min'], $internship['stipend_max'], $internship['stipend_text']) ?>
                        </span>
                        <a href="<?= base_url('internships/' . $internship['id']) ?>" class="btn btn-primary btn-sm">Apply</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div style="text-align: center; padding: 60px; color: var(--gray-500);">
            <i class="fas fa-laptop-code" style="font-size: 3rem; margin-bottom: 16px; display: block; opacity: 0.3;"></i>
            <p>No internships available at the moment.</p>
        </div>
        <?php endif; ?>
        
        <div style="text-align: center; margin-top: 32px; display: flex; gap: 16px; justify-content: center; flex-wrap: wrap;">
            <a href="<?= base_url('internships') ?>" class="btn btn-primary btn-lg">
                <i class="fas fa-laptop-code"></i> View All Internships
            </a>
            <a href="<?= base_url('apprenticeships') ?>" class="btn btn-secondary btn-lg">
                <i class="fas fa-tools"></i> View Apprenticeships
            </a>
        </div>
    </div>
</section>

<!-- Scholarships Section -->
<section class="section">
    <div class="container">
        <div class="section-header animate-on-scroll">
            <span class="section-label">Funding</span>
            <h2 class="section-title">Scholarships & <span class="gradient-text">Financial Aid</span></h2>
            <p class="section-desc">Discover scholarships and financial aid opportunities for your education.</p>
        </div>
        
        <div class="grid-2" style="margin-bottom: 40px;">
            <div class="glass-card animate-on-scroll" style="padding: 32px; display: flex; align-items: center; gap: 24px;">
                <div style="width: 64px; height: 64px; border-radius: 16px; background: linear-gradient(135deg, #6366f1, #8b5cf6); display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: white; flex-shrink: 0;">
                    <i class="fas fa-graduation-cap"></i>
                </div>
                <div>
                    <h3 style="font-size: 1.125rem; margin-bottom: 4px;">Government Scholarships</h3>
                    <p style="font-size: 0.875rem; color: var(--gray-500);">Central and state government scholarship programs for meritorious students.</p>
                    <a href="<?= base_url('scholarships?type=government') ?>" class="btn btn-primary btn-sm" style="margin-top: 12px;">Explore</a>
                </div>
            </div>
            <div class="glass-card animate-on-scroll" style="padding: 32px; display: flex; align-items: center; gap: 24px;">
                <div style="width: 64px; height: 64px; border-radius: 16px; background: linear-gradient(135deg, #10b981, #06b6d4); display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: white; flex-shrink: 0;">
                    <i class="fas fa-building"></i>
                </div>
                <div>
                    <h3 style="font-size: 1.125rem; margin-bottom: 4px;">Private Scholarships</h3>
                    <p style="font-size: 0.875rem; color: var(--gray-500);">Corporate and private organization scholarships for various fields.</p>
                    <a href="<?= base_url('scholarships?type=private') ?>" class="btn btn-primary btn-sm" style="margin-top: 12px;">Explore</a>
                </div>
            </div>
        </div>
        
        <?php if (!empty($scholarships)): ?>
        <div class="grid-4">
            <?php foreach ($scholarships as $scholarship): ?>
            <div class="job-card animate-on-scroll">
                <div class="job-card-header">
                    <div class="job-company-logo" style="background: rgba(245, 158, 11, 0.1); color: #d97706;">
                        <i class="fas fa-award"></i>
                    </div>
                    <div>
                        <h3 class="job-card-title" style="font-size: 0.938rem;"><?= esc($scholarship['name']) ?></h3>
                        <div class="job-company"><?= esc($scholarship['provider_name']) ?></div>
                    </div>
                </div>
                <div class="job-card-footer">
                    <span style="font-weight: 600; color: var(--success);"><?= esc($scholarship['amount_text'] ?? '₹ ' . number_format($scholarship['amount'] ?? 0)) ?></span>
                    <a href="<?= base_url('scholarships/' . $scholarship['id']) ?>" class="btn btn-primary btn-sm">Details</a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Resume Builder & Interview Prep -->
<section class="section" style="background: linear-gradient(135deg, rgba(99, 102, 241, 0.03) 0%, rgba(139, 92, 246, 0.05) 100%);">
    <div class="container">
        <div class="section-header animate-on-scroll">
            <span class="section-label">Career Tools</span>
            <h2 class="section-title">Build Your <span class="gradient-text">Career</span></h2>
            <p class="section-desc">Powerful tools and resources to help you succeed in your job search.</p>
        </div>
        
        <div class="grid-3">
            <div class="glass-card animate-on-scroll" style="padding: 36px 28px; text-align: center;">
                <div style="width: 72px; height: 72px; margin: 0 auto 20px; border-radius: 20px; background: linear-gradient(135deg, #6366f1, #8b5cf6); display: flex; align-items: center; justify-content: center; font-size: 1.75rem; color: white;">
                    <i class="fas fa-file-alt"></i>
                </div>
                <h3 style="font-size: 1.125rem; margin-bottom: 8px;">Resume Builder</h3>
                <p style="font-size: 0.875rem; color: var(--gray-500); margin-bottom: 20px; line-height: 1.6;">Create professional, ATS-friendly resumes with multiple templates. Download as PDF.</p>
                <a href="<?= base_url('resume-builder') ?>" class="btn btn-primary">
                    <i class="fas fa-file-alt"></i> Build Resume
                </a>
            </div>
            
            <div class="glass-card animate-on-scroll" style="padding: 36px 28px; text-align: center;">
                <div style="width: 72px; height: 72px; margin: 0 auto 20px; border-radius: 20px; background: linear-gradient(135deg, #10b981, #06b6d4); display: flex; align-items: center; justify-content: center; font-size: 1.75rem; color: white;">
                    <i class="fas fa-people-arrows"></i>
                </div>
                <h3 style="font-size: 1.125rem; margin-bottom: 8px;">Interview Preparation</h3>
                <p style="font-size: 0.875rem; color: var(--gray-500); margin-bottom: 20px; line-height: 1.6;">HR questions, technical questions, mock tests, and aptitude practice.</p>
                <a href="<?= base_url('interview-preparation') ?>" class="btn btn-primary" style="background: linear-gradient(135deg, #10b981, #06b6d4);">
                    <i class="fas fa-people-arrows"></i> Start Preparing
                </a>
            </div>
            
            <div class="glass-card animate-on-scroll" style="padding: 36px 28px; text-align: center;">
                <div style="width: 72px; height: 72px; margin: 0 auto 20px; border-radius: 20px; background: linear-gradient(135deg, #f59e0b, #ef4444); display: flex; align-items: center; justify-content: center; font-size: 1.75rem; color: white;">
                    <i class="fas fa-compass"></i>
                </div>
                <h3 style="font-size: 1.125rem; margin-bottom: 8px;">Career Guidance</h3>
                <p style="font-size: 0.875rem; color: var(--gray-500); margin-bottom: 20px; line-height: 1.6;">Expert articles on career options, how to prepare, resume tips, and study plans.</p>
                <a href="<?= base_url('career-guidance') ?>" class="btn btn-primary" style="background: linear-gradient(135deg, #f59e0b, #ef4444);">
                    <i class="fas fa-compass"></i> Get Guidance
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials -->
<section class="section">
    <div class="container">
        <div class="section-header animate-on-scroll">
            <span class="section-label">Testimonials</span>
            <h2 class="section-title">What Our <span class="gradient-text">Users Say</span></h2>
            <p class="section-desc">Hear from thousands of successful students and job seekers who trusted RojgarSandhi.</p>
        </div>
        
        <?php if (!empty($testimonials)): ?>
        <div id="testimonial-carousel">
            <?php foreach ($testimonials as $index => $testimonial): ?>
            <div class="testimonial-slide" style="<?= $index > 0 ? 'display: none;' : '' ?>">
                <div style="max-width: 700px; margin: 0 auto;">
                    <div class="testimonial-card animate-on-scroll" style="text-align: center;">
                        <div style="color: var(--warning); margin-bottom: 16px;">
                            <?php for ($i = 0; $i < ($testimonial['rating'] ?? 5); $i++): ?>
                                <i class="fas fa-star"></i>
                            <?php endfor; ?>
                        </div>
                        <div class="testimonial-content">
                            "<?= esc($testimonial['content']) ?>"
                        </div>
                        <div class="testimonial-author" style="justify-content: center;">
                            <div class="testimonial-avatar">
                                <?= strtoupper(substr($testimonial['name'], 0, 1)) ?>
                            </div>
                            <div style="text-align: left;">
                                <h4><?= esc($testimonial['name']) ?></h4>
                                <p><?= esc($testimonial['designation'] ?? '') ?><?= !empty($testimonial['company']) ? ' at ' . esc($testimonial['company']) : '' ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div style="text-align: center; padding: 60px;">
            <div class="testimonial-card" style="max-width: 600px; margin: 0 auto; text-align: center;">
                <div style="color: var(--warning); margin-bottom: 16px;">
                    <i class="fas fa-star"></i> <i class="fas fa-star"></i> <i class="fas fa-star"></i> <i class="fas fa-star"></i> <i class="fas fa-star"></i>
                </div>
                <div class="testimonial-content">
                    "RojgarSandhi helped me find my dream job at a top company. The platform is incredibly easy to use and the job alerts are very timely. Highly recommended for every job seeker!"
                </div>
                <div class="testimonial-author" style="justify-content: center;">
                    <div class="testimonial-avatar">R</div>
                    <div style="text-align: left;">
                        <h4>Rahul Sharma</h4>
                        <p>Software Engineer at TCS</p>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Latest Blog -->
<section class="section" style="background: linear-gradient(135deg, rgba(99, 102, 241, 0.03) 0%, rgba(139, 92, 246, 0.05) 100%);">
    <div class="container">
        <div class="section-header animate-on-scroll">
            <span class="section-label">Blog</span>
            <h2 class="section-title">Latest <span class="gradient-text">Articles</span></h2>
            <p class="section-desc">Stay informed with the latest career tips, exam strategies, and industry insights.</p>
        </div>
        
        <?php if (!empty($blogs)): ?>
        <div class="grid-3">
            <?php foreach ($blogs as $blog): ?>
            <div class="glass-card animate-on-scroll" style="overflow: hidden;">
                <div style="height: 200px; background: linear-gradient(135deg, #6366f1, #8b5cf6); display: flex; align-items: center; justify-content: center; color: rgba(255,255,255,0.3); font-size: 3rem;">
                    <i class="fas fa-newspaper"></i>
                </div>
                <div style="padding: 24px;">
                    <div style="font-size: 0.75rem; color: var(--primary); font-weight: 600; margin-bottom: 8px;">
                        <?= date('d M Y', strtotime($blog['published_at'] ?? $blog['created_at'])) ?>
                    </div>
                    <h3 style="font-size: 1.063rem; font-weight: 700; margin-bottom: 8px;">
                        <a href="<?= base_url('blog/' . $blog['slug']) ?>" style="color: var(--gray-900); text-decoration: none;"><?= esc($blog['title']) ?></a>
                    </h3>
                    <p style="font-size: 0.875rem; color: var(--gray-500); margin-bottom: 16px; line-height: 1.6;">
                        <?= esc(truncate_text(strip_tags($blog['excerpt'] ?? ''), 120)) ?>
                    </p>
                    <a href="<?= base_url('blog/' . $blog['slug']) ?>" class="btn btn-secondary btn-sm">Read More <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        
        <div style="text-align: center; margin-top: 32px;">
            <a href="<?= base_url('blog') ?>" class="btn btn-outline btn-lg">
                <i class="fas fa-blog"></i> View All Articles
            </a>
        </div>
    </div>
</section>

<!-- Additional Styles for Home Page -->
<style>
    .hero-section {
        position: relative;
    }
    @media (max-width: 768px) {
        .hero-content {
            grid-template-columns: 1fr !important;
        }
        .hero-content > div:last-child {
            display: none;
        }
        .hero-stats {
            flex-wrap: wrap;
        }
    }
</style>
