<section class="section" style="padding-top:120px;">
    <div class="container">
        <?= view('partials/breadcrumb', ['breadcrumbs' => [['name' => 'Notifications']]]) ?>
        <div class="section-header" style="text-align:left; margin:0 0 32px;">
            <h1 class="section-title">Notifications</h1>
        </div>
        <?php if (!empty($notifications)): ?><div class="glass-card"><?php foreach ($notifications as $n): ?><div style="padding:16px 20px; border-bottom:1px solid var(--gray-100); display:flex; align-items:flex-start; gap:12px;"><div style="width:40px; height:40px; border-radius:10px; background:rgba(99,102,241,0.1); display:flex; align-items:center; justify-content:center; color:var(--primary); flex-shrink:0;"><i class="fas fa-<?= $n['type'] === 'job' ? 'briefcase' : ($n['type'] === 'result' ? 'poll' : 'bell') ?>"></i></div><div style="flex:1;"><h4 style="font-size:0.938rem; font-weight:600;"><?= esc($n['title']) ?></h4><p style="font-size:0.813rem; color:var(--gray-500);"><?= esc($n['message']) ?></p></div><span style="font-size:0.75rem; color:var(--gray-400); white-space:nowrap;"><?= time_ago($n['created_at']) ?></span></div><?php endforeach; ?></div><?php else: ?><div style="text-align:center; padding:60px;"><i class="fas fa-bell" style="font-size:3rem; color:var(--gray-300); margin-bottom:16px; display:block;"></i><p style="color:var(--gray-500);">No notifications yet.</p></div><?php endif; ?>
    </div>
</section>
