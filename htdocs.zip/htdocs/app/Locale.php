<?php

if (!class_exists('Locale', false)) {
    class Locale
    {
        public static function getDefault(): string
        {
            return 'en';
        }

        public static function setDefault(string $locale): bool
        {
            return true;
        }

        public static function getPrimaryLanguage(string $locale): ?string
        {
            return substr($locale, 0, 2) ?: null;
        }

        public static function getRegion(string $locale): ?string
        {
            $parts = explode('_', $locale);

            return $parts[1] ?? null;
        }

        public static function accepts(string $locale, string $langtag): bool
        {
            return str_starts_with($langtag, $locale);
        }

        public static function canonicalize(string $locale): ?string
        {
            return $locale;
        }

        public static function composeLocale(array $subtags): ?string
        {
            return implode('_', $subtags);
        }

        public static function filterMatches(string $langtag, string $locale, bool $canonicalize = false): ?bool
        {
            return true;
        }

        public static function getAllVariants(string $locale): ?array
        {
            return [];
        }

        public static function getDisplayLanguage(string $locale, ?string $displayLocale = null): string
        {
            return $locale;
        }

        public static function getDisplayName(string $locale, ?string $displayLocale = null): string
        {
            return $locale;
        }

        public static function getDisplayRegion(string $locale, ?string $displayLocale = null): string
        {
            return $locale;
        }

        public static function getDisplayScript(string $locale, ?string $displayLocale = null): string
        {
            return $locale;
        }

        public static function getDisplayVariant(string $locale, ?string $displayLocale = null): string
        {
            return $locale;
        }

        public static function getKeywords(string $locale): ?array
        {
            return [];
        }

        public static function hasKeyword(string $locale, string $keyword): bool
        {
            return false;
        }

        public static function isValidLocale(string $locale): bool
        {
            return (bool) preg_match('/^[a-zA-Z_]+$/', $locale);
        }

        public static function lookup(array $langtag, string $locale, bool $canonicalize = false, ?string $defaultLocale = null): ?string
        {
            return $locale;
        }

        public static function parseLocale(string $locale): ?array
        {
            $parts = explode('_', $locale);

            return [
                'language' => $parts[0] ?? '',
                'region'   => $parts[1] ?? '',
            ];
        }
    }
}
