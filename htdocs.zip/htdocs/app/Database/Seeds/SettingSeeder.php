<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class SettingSeeder extends Seeder
{
    public function run()
    {
        $settings = [
            ['key_name' => 'site_name', 'key_value' => 'RojgarSandhi', 'group_name' => 'general'],
            ['key_name' => 'site_tagline', 'key_value' => 'Your Gateway to Jobs, Skills & Career Success', 'group_name' => 'general'],
            ['key_name' => 'site_email', 'key_value' => 'info@rojgarsandhi.in', 'group_name' => 'general'],
            ['key_name' => 'site_phone', 'key_value' => '+91-1800-123-4567', 'group_name' => 'general'],
            ['key_name' => 'site_address', 'key_value' => 'New Delhi, India', 'group_name' => 'general'],
            ['key_name' => 'meta_title', 'key_value' => 'RojgarSandhi - Your Gateway to Jobs, Skills & Career Success', 'group_name' => 'seo'],
            ['key_name' => 'meta_description', 'key_value' => 'India\'s premier career platform connecting millions of job seekers with government jobs, private jobs, internships, and skill development courses.', 'group_name' => 'seo'],
            ['key_name' => 'meta_keywords', 'key_value' => 'jobs, government jobs, private jobs, internships, courses, India jobs, Sarkari Naukri', 'group_name' => 'seo'],
            ['key_name' => 'total_jobs_count', 'key_value' => '50000', 'group_name' => 'stats'],
            ['key_name' => 'total_students_count', 'key_value' => '10000', 'group_name' => 'stats'],
            ['key_name' => 'total_courses_count', 'key_value' => '1000', 'group_name' => 'stats'],
            ['key_name' => 'total_companies_count', 'key_value' => '500', 'group_name' => 'stats'],
            ['key_name' => 'facebook_url', 'key_value' => 'https://facebook.com/rojgarsandhi', 'group_name' => 'social'],
            ['key_name' => 'twitter_url', 'key_value' => 'https://twitter.com/rojgarsandhi', 'group_name' => 'social'],
            ['key_name' => 'instagram_url', 'key_value' => 'https://instagram.com/rojgarsandhi', 'group_name' => 'social'],
            ['key_name' => 'linkedin_url', 'key_value' => 'https://linkedin.com/company/rojgarsandhi', 'group_name' => 'social'],
            ['key_name' => 'youtube_url', 'key_value' => 'https://youtube.com/@rojgarsandhi', 'group_name' => 'social'],
            ['key_name' => 'telegram_url', 'key_value' => 'https://t.me/rojgarsandhi', 'group_name' => 'social'],
            ['key_name' => 'whatsapp_number', 'key_value' => '+91-1800-123-4567', 'group_name' => 'social'],
        ];

        foreach ($settings as $s) {
            $this->db->table('settings')->insert($s);
        }
    }
}
