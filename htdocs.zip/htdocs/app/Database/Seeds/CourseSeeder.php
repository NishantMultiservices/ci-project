<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class CourseSeeder extends Seeder
{
    public function run()
    {
        $courses = [
            ['title' => 'Python Programming Masterclass', 'slug' => 'python-programming-masterclass', 'category_id' => 11, 'short_description' => 'Learn Python from scratch to advanced with hands-on projects.', 'price' => 0, 'is_free' => 1, 'duration' => '8 weeks', 'level' => 'beginner', 'instructor_name' => 'Dr. Rajesh Kumar', 'total_lessons' => 40, 'total_hours' => 30, 'rating' => 4.8, 'total_enrolled' => 15230, 'is_featured' => 1, 'is_active' => 1, 'created_at' => '2026-06-01 10:00:00'],
            ['title' => 'Machine Learning & AI', 'slug' => 'machine-learning-ai', 'category_id' => 12, 'short_description' => 'Master ML algorithms and build AI applications.', 'price' => 2999, 'is_free' => 0, 'duration' => '12 weeks', 'level' => 'intermediate', 'instructor_name' => 'Prof. Ananya Gupta', 'total_lessons' => 60, 'total_hours' => 45, 'rating' => 4.9, 'total_enrolled' => 8750, 'is_featured' => 1, 'is_active' => 1, 'created_at' => '2026-06-02 10:00:00'],
            ['title' => 'Data Science Bootcamp', 'slug' => 'data-science-bootcamp', 'category_id' => 13, 'short_description' => 'Complete data science course with real-world projects.', 'price' => 4999, 'is_free' => 0, 'duration' => '16 weeks', 'level' => 'intermediate', 'instructor_name' => 'Dr. Amit Singh', 'total_lessons' => 80, 'total_hours' => 60, 'rating' => 4.7, 'total_enrolled' => 6200, 'is_featured' => 1, 'is_active' => 1, 'created_at' => '2026-06-03 10:00:00'],
            ['title' => 'Cyber Security Fundamentals', 'slug' => 'cyber-security-fundamentals', 'category_id' => 14, 'short_description' => 'Learn ethical hacking and cybersecurity basics.', 'price' => 0, 'is_free' => 1, 'duration' => '6 weeks', 'level' => 'beginner', 'instructor_name' => 'Mr. Vikram Reddy', 'total_lessons' => 30, 'total_hours' => 20, 'rating' => 4.6, 'total_enrolled' => 12500, 'is_featured' => 1, 'is_active' => 1, 'created_at' => '2026-06-04 10:00:00'],
            ['title' => 'Full Stack Web Development', 'slug' => 'full-stack-web-development', 'category_id' => 15, 'short_description' => 'Build modern web apps with React, Node.js, and MongoDB.', 'price' => 3999, 'is_free' => 0, 'duration' => '14 weeks', 'level' => 'intermediate', 'instructor_name' => 'Ms. Priya Sharma', 'total_lessons' => 70, 'total_hours' => 50, 'rating' => 4.8, 'total_enrolled' => 9800, 'is_featured' => 1, 'is_active' => 1, 'created_at' => '2026-06-05 10:00:00'],
            ['title' => 'Digital Marketing Pro', 'slug' => 'digital-marketing-pro', 'category_id' => 16, 'short_description' => 'Master SEO, SEM, social media, and content marketing.', 'price' => 1999, 'is_free' => 0, 'duration' => '8 weeks', 'level' => 'all', 'instructor_name' => 'Mr. Arun Nair', 'total_lessons' => 45, 'total_hours' => 35, 'rating' => 4.5, 'total_enrolled' => 7400, 'is_active' => 1, 'created_at' => '2026-06-06 10:00:00'],
            ['title' => 'Cloud Computing with AWS', 'slug' => 'cloud-computing-aws', 'category_id' => 17, 'short_description' => 'Learn AWS services and cloud architecture.', 'price' => 0, 'is_free' => 1, 'duration' => '10 weeks', 'level' => 'intermediate', 'instructor_name' => 'Mr. Suresh Patel', 'total_lessons' => 50, 'total_hours' => 40, 'rating' => 4.7, 'total_enrolled' => 11000, 'is_featured' => 1, 'is_active' => 1, 'created_at' => '2026-06-07 10:00:00'],
            ['title' => 'Excel for Business Analytics', 'slug' => 'excel-for-business-analytics', 'category_id' => 11, 'short_description' => 'Master Excel for data analysis and business intelligence.', 'price' => 0, 'is_free' => 1, 'duration' => '4 weeks', 'level' => 'beginner', 'instructor_name' => 'Ms. Neha Kapoor', 'total_lessons' => 20, 'total_hours' => 15, 'rating' => 4.4, 'total_enrolled' => 18500, 'is_active' => 1, 'created_at' => '2026-06-08 10:00:00'],
        ];

        foreach ($courses as $course) {
            $this->db->table('courses')->insert($course);
        }
    }
}
