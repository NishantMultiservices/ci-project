<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        $users = [
            ['name' => 'Admin', 'email' => 'admin@rojgarsandhi.in', 'phone' => '9999999999', 'password' => password_hash('admin@123', PASSWORD_DEFAULT), 'role' => 'admin', 'is_active' => 1, 'email_verified_at' => date('Y-m-d H:i:s')],
            ['name' => 'Rahul Sharma', 'email' => 'rahul@example.com', 'phone' => '9876543210', 'password' => password_hash('user@123', PASSWORD_DEFAULT), 'role' => 'user', 'is_active' => 1, 'email_verified_at' => date('Y-m-d H:i:s')],
            ['name' => 'Priya Patel', 'email' => 'priya@example.com', 'phone' => '9876543211', 'password' => password_hash('user@123', PASSWORD_DEFAULT), 'role' => 'user', 'is_active' => 1, 'email_verified_at' => date('Y-m-d H:i:s')],
            ['name' => 'Amit Kumar', 'email' => 'amit@example.com', 'phone' => '9876543212', 'password' => password_hash('user@123', PASSWORD_DEFAULT), 'role' => 'user', 'is_active' => 1, 'email_verified_at' => date('Y-m-d H:i:s')],
            ['name' => 'Sneha Gupta', 'email' => 'sneha@example.com', 'phone' => '9876543213', 'password' => password_hash('user@123', PASSWORD_DEFAULT), 'role' => 'user', 'is_active' => 1, 'email_verified_at' => null],
            ['name' => 'Vikram Singh', 'email' => 'vikram@example.com', 'phone' => '9876543214', 'password' => password_hash('user@123', PASSWORD_DEFAULT), 'role' => 'user', 'is_active' => 1, 'email_verified_at' => date('Y-m-d H:i:s')],
        ];
        
        foreach ($users as $user) {
            $this->db->table('users')->insert($user);
        }
    }
}
