<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class CategorySeeder extends Seeder
{
    public function run()
    {
        $categories = [
            ['name' => 'All Jobs', 'slug' => 'all-jobs', 'type' => 'job', 'description' => 'All job categories', 'icon' => 'briefcase', 'sort_order' => 1],
            ['name' => 'Government Jobs', 'slug' => 'government-jobs', 'type' => 'job', 'description' => 'Government sector jobs', 'icon' => 'landmark', 'sort_order' => 2],
            ['name' => 'Private Jobs', 'slug' => 'private-jobs', 'type' => 'job', 'description' => 'Private sector jobs', 'icon' => 'building', 'sort_order' => 3],
            ['name' => 'UPSC', 'slug' => 'upsc', 'type' => 'job', 'description' => 'UPSC exam jobs', 'icon' => 'landmark', 'sort_order' => 4],
            ['name' => 'SSC', 'slug' => 'ssc', 'type' => 'job', 'description' => 'SSC exam jobs', 'icon' => 'file-text', 'sort_order' => 5],
            ['name' => 'Banking', 'slug' => 'banking', 'type' => 'job', 'description' => 'Banking jobs', 'icon' => 'university', 'sort_order' => 6],
            ['name' => 'Railway', 'slug' => 'railway', 'type' => 'job', 'description' => 'Railway jobs', 'icon' => 'train', 'sort_order' => 7],
            ['name' => 'Police', 'slug' => 'police', 'type' => 'job', 'description' => 'Police jobs', 'icon' => 'shield', 'sort_order' => 8],
            ['name' => 'Defence', 'slug' => 'defence', 'type' => 'job', 'description' => 'Defence jobs', 'icon' => 'crosshair', 'sort_order' => 9],
            ['name' => 'State Government', 'slug' => 'state-government', 'type' => 'job', 'description' => 'State government jobs', 'icon' => 'map-pin', 'sort_order' => 10],
            ['name' => 'Programming', 'slug' => 'programming', 'type' => 'course', 'description' => 'Programming courses', 'icon' => 'code', 'sort_order' => 1],
            ['name' => 'AI & Machine Learning', 'slug' => 'ai-machine-learning', 'type' => 'course', 'description' => 'AI and ML courses', 'icon' => 'cpu', 'sort_order' => 2],
            ['name' => 'Data Science', 'slug' => 'data-science', 'type' => 'course', 'description' => 'Data Science courses', 'icon' => 'bar-chart', 'sort_order' => 3],
            ['name' => 'Cyber Security', 'slug' => 'cyber-security', 'type' => 'course', 'description' => 'Cyber Security courses', 'icon' => 'lock', 'sort_order' => 4],
            ['name' => 'Web Development', 'slug' => 'web-development', 'type' => 'course', 'description' => 'Web Development courses', 'icon' => 'globe', 'sort_order' => 5],
            ['name' => 'Digital Marketing', 'slug' => 'digital-marketing', 'type' => 'course', 'description' => 'Digital Marketing courses', 'icon' => 'trending-up', 'sort_order' => 6],
            ['name' => 'Cloud Computing', 'slug' => 'cloud-computing', 'type' => 'course', 'description' => 'Cloud Computing courses', 'icon' => 'cloud', 'sort_order' => 7],
            ['name' => 'Career Tips', 'slug' => 'career-tips', 'type' => 'blog', 'description' => 'Career advice articles', 'icon' => 'compass', 'sort_order' => 1],
            ['name' => 'Exam Prep', 'slug' => 'exam-prep', 'type' => 'blog', 'description' => 'Exam preparation tips', 'icon' => 'book', 'sort_order' => 2],
        ];

        foreach ($categories as $cat) {
            $this->db->table('categories')->insert($cat);
        }
    }
}
