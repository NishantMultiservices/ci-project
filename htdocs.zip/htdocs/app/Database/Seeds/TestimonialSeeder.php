<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class TestimonialSeeder extends Seeder
{
    public function run()
    {
        $testimonials = [
            ['name' => 'Rahul Sharma', 'designation' => 'Software Engineer', 'company' => 'TCS', 'content' => 'RojgarSandhi helped me find my dream job at TCS. The platform is incredibly easy to use and the job alerts are very timely. Highly recommended for every job seeker!', 'rating' => 5, 'is_approved' => 1, 'sort_order' => 1],
            ['name' => 'Sneha Gupta', 'designation' => 'Bank PO', 'company' => 'State Bank of India', 'content' => 'I cleared my SBI PO exam with the help of resources available on RojgarSandhi. The interview preparation section was particularly helpful.', 'rating' => 5, 'is_approved' => 1, 'sort_order' => 2],
            ['name' => 'Amit Kumar', 'designation' => 'Data Scientist', 'company' => 'Amazon', 'content' => 'The skill development courses on RojgarSandhi helped me transition from a fresher to a data scientist. The quality of content is excellent.', 'rating' => 5, 'is_approved' => 1, 'sort_order' => 3],
            ['name' => 'Priya Patel', 'designation' => 'HR Manager', 'company' => 'Infosys', 'content' => 'As a recruiter, RojgarSandhi provides access to quality candidates. The platform has streamlined our hiring process significantly.', 'rating' => 4, 'is_approved' => 1, 'sort_order' => 4],
            ['name' => 'Vikram Singh', 'designation' => 'IPS Officer', 'company' => 'Government of India', 'content' => 'RojgarSandhi provided me with timely updates about UPSC notifications and preparation resources. Truly a one-stop platform for government job aspirants.', 'rating' => 5, 'is_approved' => 1, 'sort_order' => 5],
        ];

        foreach ($testimonials as $t) {
            $this->db->table('testimonials')->insert($t);
        }
    }
}
