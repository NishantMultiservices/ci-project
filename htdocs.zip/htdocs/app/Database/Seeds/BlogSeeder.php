<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class BlogSeeder extends Seeder
{
    public function run()
    {
        $blogs = [
            ['title' => 'Top 10 Government Jobs After Graduation in 2026', 'slug' => 'top-10-government-jobs-after-graduation', 'category_id' => 19, 'excerpt' => 'Discover the best government job opportunities available for graduates in 2026 with salaries, eligibility, and application details.', 'content' => '<p>Are you a fresh graduate looking for a stable and rewarding career? Government jobs in India offer excellent job security, attractive salaries, and numerous benefits. Here are the top 10 government jobs you can apply for after graduation in 2026.</p><h2>1. UPSC Civil Services (IAS/IPS/IFS)</h2><p>The most prestigious government job in India. Entry through UPSC Civil Services Examination.</p><h2>2. SSC CGL</h2><p>Staff Selection Commission Combined Graduate Level examination for Group B and Group C posts.</p><h2>3. Banking PO</h2><p>Probationary Officer positions in public sector banks through IBPS PO/SBI PO exams.</p><h2>4. Railway Jobs</h2><p>Indian Railways offers numerous positions for graduates through RRB examinations.</p><h2>5. State PSC Exams</h2><p>State Public Service Commissions conduct exams for state administrative services.</p>', 'author_name' => 'RojgarSandhi Team', 'tags' => 'government jobs, career, graduation, sarkari naukri', 'is_published' => 1, 'is_featured' => 1, 'published_at' => '2026-06-15 10:00:00', 'views_count' => 1234, 'created_at' => '2026-06-15 10:00:00'],
            ['title' => 'How to Prepare for SSC CGL 2026: Complete Guide', 'slug' => 'how-to-prepare-ssc-cgl-2026', 'category_id' => 19, 'excerpt' => 'A comprehensive preparation strategy for SSC CGL 2026 examination including study plan, books, and tips.', 'content' => '<p>SSC CGL is one of the most sought-after competitive exams in India. With proper planning and dedication, you can crack this exam. Here\'s a complete preparation guide.</p><h2>Exam Pattern</h2><p>The exam consists of Tier 1, Tier 2, Tier 3, and Tier 4 stages.</p><h2>Study Plan</h2><p>Dedicate 4-6 hours daily with equal focus on all sections.</p>', 'author_name' => 'Vikram Singh', 'tags' => 'SSC, CGL, preparation, exam tips', 'is_published' => 1, 'is_featured' => 1, 'published_at' => '2026-06-10 10:00:00', 'views_count' => 980, 'created_at' => '2026-06-10 10:00:00'],
            ['title' => '5 Essential Resume Tips for Freshers in 2026', 'slug' => 'resume-tips-freshers-2026', 'category_id' => 18, 'excerpt' => 'Learn how to create a standout resume that gets noticed by recruiters and ATS systems.', 'content' => '<p>As a fresher, your resume is your first impression on potential employers. Here are 5 essential tips to make it stand out.</p><h2>1. Keep It One Page</h2><p>Recruiters spend an average of 6 seconds scanning a resume. Keep it concise.</p><h2>2. Highlight Projects</h2><p>Showcase academic projects, internships, and freelance work.</p>', 'author_name' => 'Priya Patel', 'tags' => 'resume, freshers, career tips', 'is_published' => 1, 'published_at' => '2026-06-05 10:00:00', 'views_count' => 1567, 'created_at' => '2026-06-05 10:00:00'],
        ];

        foreach ($blogs as $blog) {
            $this->db->table('blogs')->insert($blog);
        }
    }
}
