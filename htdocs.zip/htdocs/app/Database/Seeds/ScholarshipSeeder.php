<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class ScholarshipSeeder extends Seeder
{
    public function run()
    {
        $scholarships = [
            ['name' => 'National Scholarship Portal (NSP)', 'slug' => 'national-scholarship-portal', 'type' => 'government', 'provider_name' => 'Ministry of Education', 'description' => 'Central sector scholarship scheme for meritorious students from economically weaker sections.', 'eligibility' => 'Family income less than ₹8 lakh per annum, minimum 60% marks in previous exam', 'amount' => 25000, 'amount_text' => 'Up to ₹25,000/year', 'last_date_to_apply' => '2026-10-31', 'is_featured' => 1, 'is_active' => 1],
            ['name' => 'Post Matric Scholarship (SC/ST)', 'slug' => 'post-matric-sc-st-scholarship', 'type' => 'government', 'provider_name' => 'Ministry of Social Justice', 'description' => 'Post-matric scholarship for SC/ST students pursuing higher education.', 'eligibility' => 'SC/ST category students, family income less than ₹2.5 lakh per annum', 'amount' => 150000, 'amount_text' => 'Full tuition fee + maintenance allowance', 'last_date_to_apply' => '2026-11-15', 'is_active' => 1],
            ['name' => 'Minority Scholarship (Maulana Azad)', 'slug' => 'maulana-azad-minority-scholarship', 'type' => 'minority', 'provider_name' => 'Ministry of Minority Affairs', 'description' => 'Merit-cum-means scholarship for minority community students.', 'eligibility' => 'Minority community (Muslim/Christian/Sikh/Buddhist/Jain/Parsi), family income less than ₹1 lakh/year', 'amount' => 20000, 'amount_text' => 'Up to ₹20,000/year', 'last_date_to_apply' => '2026-09-30', 'is_active' => 1],
            ['name' => 'Kishore Vaigyanik Protsahan Yojana (KVPY)', 'slug' => 'kvpy-scholarship', 'type' => 'government', 'provider_name' => 'Department of Science & Technology', 'description' => 'National fellowship program in basic sciences, initiated by the Department of Science and Technology.', 'eligibility' => 'Students enrolled in undergraduate science programs (B.Sc/B.S./B.Stat/B.Math/Int. M.Sc/M.S.)', 'amount' => 5000, 'amount_text' => '₹5,000/month + annual contingency grant', 'last_date_to_apply' => '2026-10-15', 'is_featured' => 1, 'is_active' => 1],
            ['name' => 'Reliance Foundation Scholarship', 'slug' => 'reliance-foundation-scholarship', 'type' => 'private', 'provider_name' => 'Reliance Foundation', 'description' => 'Premier scholarship program for meritorious students from economically weaker families.', 'eligibility' => 'Top 100 rankers in state/national board exams, family income less than ₹15 lakh/year', 'amount' => 200000, 'amount_text' => 'Up to ₹2,00,000/year', 'last_date_to_apply' => '2026-08-15', 'is_featured' => 1, 'is_active' => 1],
            ['name' => 'INSPIRE Scholarship', 'slug' => 'inspire-scholarship', 'type' => 'government', 'provider_name' => 'Department of Science & Technology', 'description' => 'Innovation in Science Pursuit for Inspired Research (INSPIRE) scholarship.', 'eligibility' => 'Top 1% in Class 12 board exams, pursuing B.Sc./B.S. in natural sciences', 'amount' => 80000, 'amount_text' => '₹80,000/year for three years', 'last_date_to_apply' => '2026-10-31', 'is_active' => 1],
        ];

        foreach ($scholarships as $s) {
            $this->db->table('scholarships')->insert($s);
        }
    }
}
