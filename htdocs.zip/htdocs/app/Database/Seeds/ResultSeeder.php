<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class ResultSeeder extends Seeder
{
    public function run()
    {
        $results = [
            ['title' => 'UPSC Civil Services Final Results 2025', 'slug' => 'upsc-civil-services-result-2025', 'exam_name' => 'UPSC Civil Services Examination', 'description' => 'The Union Public Service Commission has declared the final results for the Civil Services Examination 2025.', 'result_date' => '2026-05-20', 'result_link' => 'https://upsc.gov.in', 'total_appeared' => 1200000, 'total_qualified' => 987, 'cutoff_marks' => 958.20, 'is_active' => 1],
            ['title' => 'SSC CGL Tier 1 Result 2025', 'slug' => 'ssc-cgl-tier1-result-2025', 'exam_name' => 'SSC Combined Graduate Level Exam', 'description' => 'SSC has released the Tier 1 results for CGL 2025 examination.', 'result_date' => '2026-05-15', 'result_link' => 'https://ssc.gov.in', 'total_appeared' => 3500000, 'total_qualified' => 125000, 'cutoff_marks' => 145.50, 'is_active' => 1],
            ['title' => 'IBPS PO Prelims Result 2025', 'slug' => 'ibps-po-prelims-result-2025', 'exam_name' => 'IBPS PO Preliminary Examination', 'description' => 'IBPS has announced the preliminary examination results for Probationary Officer recruitment.', 'result_date' => '2026-04-30', 'result_link' => 'https://ibps.in', 'total_appeared' => 850000, 'total_qualified' => 85000, 'cutoff_marks' => 65.75, 'is_active' => 1],
            ['title' => 'RRB ALP Result 2025', 'slug' => 'rrb-alp-result-2025', 'exam_name' => 'RRB Assistant Loco Pilot Exam', 'description' => 'Railway Recruitment Board has released the results for Assistant Loco Pilot examination.', 'result_date' => '2026-04-20', 'result_link' => 'https://rrb.gov.in', 'total_appeared' => 2800000, 'total_qualified' => 56000, 'cutoff_marks' => 78.50, 'is_active' => 1],
        ];

        foreach ($results as $r) {
            $this->db->table('results')->insert($r);
        }
    }
}
