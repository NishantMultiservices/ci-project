<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class InternshipSeeder extends Seeder
{
    public function run()
    {
        $internships = [
            ['title' => 'Software Development Intern', 'slug' => 'software-development-intern-google', 'company_name' => 'Google', 'type' => 'paid', 'location' => 'Bangalore', 'state' => 'Karnataka', 'stipend_min' => 50000, 'stipend_max' => 100000, 'duration' => '6 months', 'qualification_required' => 'B.Tech/M.Tech CS', 'description' => 'Work on real Google products with mentorship from industry experts.', 'last_date_to_apply' => '2026-08-31', 'is_featured' => 1, 'is_active' => 1, 'created_at' => '2026-06-15 10:00:00'],
            ['title' => 'Data Analytics Intern', 'slug' => 'data-analytics-intern-microsoft', 'company_name' => 'Microsoft', 'type' => 'paid', 'location' => 'Hyderabad', 'state' => 'Telangana', 'stipend_min' => 45000, 'stipend_max' => 80000, 'duration' => '3 months', 'qualification_required' => 'B.Tech/MBA', 'description' => 'Analyze large datasets and derive actionable insights for business teams.', 'last_date_to_apply' => '2026-07-31', 'is_featured' => 1, 'is_active' => 1, 'created_at' => '2026-06-14 10:00:00'],
            ['title' => 'Digital Marketing Intern', 'slug' => 'digital-marketing-intern-amazon', 'company_name' => 'Amazon', 'type' => 'paid', 'location' => 'Remote', 'state' => 'All India', 'stipend_min' => 25000, 'stipend_max' => 40000, 'duration' => '4 months', 'qualification_required' => 'Any Graduate', 'description' => 'Learn digital marketing strategies and work on live campaigns.', 'last_date_to_apply' => '2026-08-15', 'is_active' => 1, 'created_at' => '2026-06-13 10:00:00'],
            ['title' => 'UI/UX Design Intern', 'slug' => 'ui-ux-design-intern-tcs', 'company_name' => 'TCS', 'type' => 'paid', 'location' => 'Mumbai', 'state' => 'Maharashtra', 'stipend_min' => 30000, 'stipend_max' => 50000, 'duration' => '3 months', 'qualification_required' => 'B.Des/M.Des', 'description' => 'Design user interfaces for enterprise applications.', 'last_date_to_apply' => '2026-07-30', 'is_active' => 1, 'created_at' => '2026-06-12 10:00:00'],
            ['title' => 'Summer Research Intern', 'slug' => 'summer-research-intern-iit', 'company_name' => 'IIT Bombay', 'type' => 'campus', 'location' => 'Mumbai', 'state' => 'Maharashtra', 'stipend_min' => 20000, 'stipend_max' => 35000, 'duration' => '2 months', 'qualification_required' => 'B.Tech 3rd Year', 'description' => 'Summer research program for engineering students.', 'last_date_to_apply' => '2026-07-15', 'is_active' => 1, 'created_at' => '2026-06-11 10:00:00'],
            ['title' => 'Content Writing Intern', 'slug' => 'content-writing-intern-remote', 'company_name' => 'YouthIndia Study', 'type' => 'remote', 'location' => 'Remote', 'state' => 'All India', 'stipend_min' => 8000, 'stipend_max' => 15000, 'duration' => '3 months', 'qualification_required' => 'Any Graduate', 'description' => 'Create engaging content for educational platforms.', 'last_date_to_apply' => '2026-08-20', 'is_active' => 1, 'created_at' => '2026-06-10 10:00:00'],
        ];

        foreach ($internships as $item) {
            $this->db->table('internships')->insert($item);
        }
    }
}
