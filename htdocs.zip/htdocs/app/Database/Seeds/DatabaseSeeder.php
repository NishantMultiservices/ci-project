<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        // Disable foreign key checks for truncation
        $this->db->query('SET FOREIGN_KEY_CHECKS=0');
        
        // Clear tables first (child tables first to avoid FK issues)
        $tables = [
            'bookmarks', 'applications', 'notifications', 'page_views',
            'course_lessons', 'contact_messages', 'newsletter_subscribers',
            'settings', 'testimonials', 'resumes', 'interview_topics',
            'career_guidance', 'answer_keys', 'admit_cards', 'results',
            'apprenticeships', 'internships', 'courses', 'scholarships',
            'blogs', 'jobs', 'categories', 'user_profiles', 'users',
        ];
        foreach ($tables as $table) {
            $this->db->table($table)->truncate();
        }
        
        $this->db->query('SET FOREIGN_KEY_CHECKS=1');
        
        // Seed data
        $this->call('App\Database\Seeds\UserSeeder');
        $this->call('App\Database\Seeds\CategorySeeder');
        $this->call('App\Database\Seeds\JobSeeder');
        $this->call('App\Database\Seeds\InternshipSeeder');
        $this->call('App\Database\Seeds\CourseSeeder');
        $this->call('App\Database\Seeds\ScholarshipSeeder');
        $this->call('App\Database\Seeds\BlogSeeder');
        $this->call('App\Database\Seeds\TestimonialSeeder');
        $this->call('App\Database\Seeds\SettingSeeder');
        $this->call('App\Database\Seeds\ResultSeeder');
    }
}
