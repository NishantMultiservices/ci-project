<?php

namespace Config;

class Mimes
{
    public static $mimes = [
        'image/jpeg' => ['jpg', 'jpeg'],
        'image/png'  => ['png'],
        'image/gif'  => ['gif'],
        'image/webp' => ['webp'],
        'image/svg+xml' => ['svg'],
        'application/pdf' => ['pdf'],
        'application/msword' => ['doc'],
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => ['docx'],
        'text/plain' => ['txt'],
        'text/html' => ['html', 'htm'],
        'application/json' => ['json'],
        'application/xml' => ['xml'],
        'text/css' => ['css'],
        'text/javascript' => ['js'],
        'font/woff' => ['woff'],
        'font/woff2' => ['woff2'],
    ];
}
