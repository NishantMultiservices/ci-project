<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Validation extends BaseConfig
{
    public $ruleSets = [
        \CodeIgniter\Validation\Rules::class,
        \CodeIgniter\Validation\FormatRules::class,
        \CodeIgniter\Validation\FileRules::class,
        \CodeIgniter\Validation\CreditCardRules::class,
    ];

    public $templates = [
        'list'    => 'CodeIgniter\Validation\Views\list',
        'single'  => 'CodeIgniter\Validation\Views\single',
    ];

    public $login = [
        'email'    => 'required|valid_email',
        'password' => 'required|min_length[6]',
    ];

    public $register = [
        'name'         => 'required|min_length[3]|max_length[100]',
        'email'        => 'required|valid_email|is_unique[users.email]',
        'phone'        => 'required|numeric|exact_length[10]',
        'password'     => 'required|min_length[6]',
        'pass_confirm' => 'required|matches[password]',
    ];

    public $contact = [
        'name'    => 'required|min_length[3]',
        'email'   => 'required|valid_email',
        'subject' => 'required|min_length[3]',
        'message' => 'required|min_length[10]',
    ];
}
