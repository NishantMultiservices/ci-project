<?php

namespace Config;

use CodeIgniter\Config\AutoloadConfig;

class Autoload extends AutoloadConfig
{
    public $psr4 = [
        APP_NAMESPACE => APPPATH,
        'Config'      => APPPATH . 'Config',
    ];

    public $classmap = [];

    public $files = [
        APPPATH . 'Helpers/auth_helper.php',
        APPPATH . 'Helpers/seo_helper.php',
        APPPATH . 'Helpers/common_helper.php',
    ];

    public $helpers = [];
}
