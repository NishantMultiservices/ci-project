<?php

namespace Config;

use CodeIgniter\Config\BaseService;

class Services extends BaseService
{
    public static function seo()
    {
        return new \App\Libraries\SEO();
    }

    public static function pwa()
    {
        return new \App\Libraries\PWA();
    }

    public static function settings(bool $getShared = true): array
    {
        if ($getShared) {
            $cached = cache('site_settings');
            if ($cached !== null) {
                return $cached;
            }
        }

        $model = model('App\Models\SettingModel');
        $all = $model->findAll();
        $settings = [];
        foreach ($all as $row) {
            $settings[$row['key_name']] = $row['key_value'];
        }

        if ($getShared) {
            cache()->save('site_settings', $settings, 3600);
        }

        return $settings;
    }
}
