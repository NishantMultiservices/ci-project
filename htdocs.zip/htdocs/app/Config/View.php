<?php

namespace Config;

use CodeIgniter\Config\View as BaseView;

class View extends BaseView
{
    public $filters = [];
    public $plugins = [];
    public $includeView = [];
    public $viewsPath = APPPATH . 'Views';
}
