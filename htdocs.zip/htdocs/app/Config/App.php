<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class App extends BaseConfig
{
    public string $baseURL = 'https://job.nishantmultiservices.com/';
    public string $indexPage = '';
    public array $allowedHostnames = [];
    public $uriProtocol = 'REQUEST_URI';
    public $defaultLocale = 'en';
    public $negotiateLocale = true;
    public $supportedLocales = ['en'];
    public $appTimezone = 'Asia/Kolkata';
    public $charset = 'UTF-8';
    public $forceGlobalSecureRequests = true;
    public $sessionDriver = 'CodeIgniter\Session\Handlers\FileHandler';
    public $sessionCookieName = 'rojgar_session';
    public $sessionExpiration = 7200;
    public $sessionSavePath = WRITEPATH . 'session';
    public $sessionMatchIP = false;
    public $sessionTimeToUpdate = 300;
    public $sessionRegenerateDestroy = false;
    public $cookiePrefix = '';
    public $cookieDomain = '';
    public $cookiePath = '/';
    public $cookieSecure = true;
    public $cookieHTTPOnly = true;
    public $cookieSameSite = 'Lax';
    public array $proxyIPs = [];
    public $CSRFTokenName = 'csrf_token';
    public $CSRFHeaderName = 'X-CSRF-TOKEN';
    public $CSRFCookieName = 'csrf_cookie';
    public $CSRFExpire = 7200;
    public $CSRFRegenerate = true;
    public $CSRFExcludeURIs = [];
    public $CSRFRedirect = false;
    public $CSRFSameSite = 'Lax';
    public $CSPEnabled = false;
    public string $permittedURIChars = 'a-z 0-9~%.:_\-';
}
