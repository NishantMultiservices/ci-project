<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class PhonePay extends BaseConfig
{
    public string $merchantId = '';
    public string $saltKey = '';
    public string $saltIndex = '1';

    public string $clientId = '';
    public string $clientSecret = '';
    public int $clientVersion = 1;

    public bool $sandbox = true;
    public bool $simulate = true;

    public function __construct()
    {
        parent::__construct();
    }

    public function isV2(): bool
    {
        return !empty($this->clientId) && !empty($this->clientSecret);
    }

    public function getAuthUrl(): string
    {
        if ($this->sandbox) {
            return 'https://api-preprod.phonepe.com/apis/pg-sandbox/v1/oauth/token';
        }
        return 'https://api.phonepe.com/apis/identity-manager/v1/oauth/token';
    }

    public function getPayUrl(): string
    {
        if ($this->sandbox) {
            return 'https://api-preprod.phonepe.com/apis/pg-sandbox/checkout/v2/pay';
        }
        return 'https://api.phonepe.com/apis/pg/checkout/v2/pay';
    }

    public function getBaseUrl(): string
    {
        if ($this->sandbox) {
            return 'https://api-preprod.phonepe.com/apis/pg-sandbox';
        }
        return 'https://api.phonepe.com/apis/hermes';
    }

    public function getStatusUrl(string $merchantOrderId): string
    {
        if ($this->sandbox) {
            return "https://api-preprod.phonepe.com/apis/pg-sandbox/checkout/v2/order/{$merchantOrderId}/status";
        }
        return "https://api.phonepe.com/apis/pg/checkout/v2/order/{$merchantOrderId}/status";
    }

    public function getAuthToken(): ?string
    {
        if (!$this->isV2()) {
            return null;
        }

        $ch = curl_init($this->getAuthUrl());
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query([
                'client_id' => $this->clientId,
                'client_version' => $this->clientVersion,
                'client_secret' => $this->clientSecret,
                'grant_type' => 'client_credentials',
            ]),
            CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200 || $response === false) {
            log_message('error', 'PhonePe V2 auth failed (HTTP ' . $httpCode . '): ' . ($response ?: 'no response'));
            return null;
        }

        $data = json_decode($response, true);
        return $data['access_token'] ?? null;
    }
}
