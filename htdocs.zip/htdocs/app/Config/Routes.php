<?php

namespace Config;

use CodeIgniter\Config\Services;

$routes = Services::routes();

$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);

// Frontend Routes
$routes->get('/', 'Home::index');
$routes->get('/home', 'Home::index');
$routes->get('/about', 'About::index');
$routes->get('/contact', 'Contact::index');
$routes->post('/contact/send', 'Contact::send');

// Auth Routes
$routes->get('/login', 'Auth::login');
$routes->post('/login', 'Auth::attemptLogin');
$routes->get('/register', 'Auth::register');
$routes->post('/register', 'Auth::attemptRegister');
$routes->get('/forgot-password', 'Auth::forgotPassword');
$routes->post('/forgot-password', 'Auth::sendResetLink');
$routes->get('/reset-password/(:any)', 'Auth::resetPassword/$1');
$routes->post('/reset-password', 'Auth::processResetPassword');
$routes->get('/otp-verify', 'Auth::otpVerify');
$routes->post('/otp-verify', 'Auth::verifyOtp');
$routes->get('/auth/google', 'Auth::googleLogin');
$routes->get('/auth/google/callback', 'Auth::googleCallback');
$routes->get('/logout', 'Auth::logout');

// Job Routes
$routes->get('/jobs', 'Jobs::index');
$routes->get('/jobs/(:num)', 'Jobs::detail/$1');
$routes->get('/government-jobs', 'Jobs::government');
$routes->get('/private-jobs', 'Jobs::private');
$routes->get('/jobs/category/(:any)', 'Jobs::category/$1');

// Internship Routes
$routes->get('/internships', 'Internships::index');
$routes->get('/internships/(:num)', 'Internships::detail/$1');

// Course Routes
$routes->get('/courses', 'Courses::index');
$routes->get('/courses/(:num)', 'Courses::detail/$1');
$routes->post('/courses/enroll/(:num)', 'Courses::enroll/$1');
$routes->post('/courses/unenroll/(:num)', 'Courses::unenroll/$1');
$routes->get('/courses/learn/(:num)', 'Courses::learn/$1');
$routes->post('/courses/complete/(:num)', 'Courses::complete/$1');
$routes->post('/courses/lesson/complete', 'Courses::markLesson');
$routes->post('/courses/quiz/submit', 'Courses::submitQuiz');
$routes->get('/certificates/view/(:num)', 'Certificates::view/$1');

// Payment Routes
$routes->post('/payment/initiate', 'Payment::initiate');
$routes->post('/payment/callback', 'Payment::callback', ['filter' => '']);
$routes->get('/payment/status/(:any)', 'Payment::status/$1');
$routes->get('/payment/success', 'Payment::success');
$routes->get('/payment/failure', 'Payment::failure');

// Scholarship Routes
$routes->get('/scholarships', 'Scholarships::index');
$routes->get('/scholarships/(:num)', 'Scholarships::detail/$1');

// Results
$routes->get('/results', 'Results::index');
$routes->get('/results/(:num)', 'Results::detail/$1');

// Admit Cards
$routes->get('/admit-cards', 'AdmitCards::index');
$routes->get('/admit-cards/(:num)', 'AdmitCards::detail/$1');

// Answer Keys
$routes->get('/answer-keys', 'AnswerKeys::index');
$routes->get('/answer-keys/(:num)', 'AnswerKeys::detail/$1');

// Apprenticeships
$routes->get('/apprenticeships', 'Apprenticeships::index');
$routes->get('/apprenticeships/(:num)', 'Apprenticeships::detail/$1');

// Blog
$routes->get('/blog', 'Blog::index');
$routes->get('/blog/(:any)', 'Blog::detail/$1');

// Mock Tests
$routes->get('/mock-tests', 'MockTests::index');
$routes->get('/mock-tests/result/(:num)', 'MockTests::result/$1');
$routes->get('/mock-tests/(:any)/attempt', 'MockTests::attempt/$1');
$routes->post('/mock-tests/submit', 'MockTests::submit');
$routes->get('/mock-tests/(:any)', 'MockTests::detail/$1');

// Career Guidance
$routes->get('/career-guidance', 'CareerGuidance::index');
$routes->get('/career-guidance/(:any)', 'CareerGuidance::article/$1');

// Resume Builder
$routes->get('/resume-builder', 'ResumeBuilder::index');
$routes->post('/resume-builder/save', 'ResumeBuilder::save');
$routes->get('/resume-builder/preview/(:num)', 'ResumeBuilder::preview/$1');
$routes->get('/resume-builder/download/(:num)', 'ResumeBuilder::download/$1');

// Interview Preparation
$routes->get('/interview-preparation', 'InterviewPrep::index');
$routes->get('/interview-preparation/(:any)', 'InterviewPrep::topic/$1');

// Search
$routes->get('/search', 'Search::index');
$routes->get('/search/suggestions', 'Search::suggestions');

// Notifications
$routes->get('/notifications', 'Notifications::index');
$routes->get('/notifications/mark-read/(:num)', 'Notifications::markRead/$1');

// User Dashboard Routes
$routes->group('dashboard', ['filter' => 'auth'], function ($routes) {
    $routes->get('/', 'Dashboard::index');
    $routes->get('profile', 'Dashboard::profile');
    $routes->post('profile/update', 'Dashboard::updateProfile');
    $routes->get('saved-jobs', 'Dashboard::savedJobs');
    $routes->get('applied-jobs', 'Dashboard::appliedJobs');
    $routes->get('resume', 'Dashboard::resume');
    $routes->get('certificates', 'Dashboard::certificates');
    $routes->get('my-courses', 'Dashboard::enrolledCourses');
    $routes->get('mock-tests', 'Dashboard::mockTests');
    $routes->get('mock-tests/result/(:num)', 'Dashboard::mockTestResult/$1');
    $routes->get('bookmarks', 'Dashboard::bookmarks');
    $routes->get('notifications', 'Dashboard::notifications');
    $routes->get('settings', 'Dashboard::settings');
    $routes->post('settings/update', 'Dashboard::updateSettings');
    $routes->post('bookmark/toggle', 'Dashboard::toggleBookmark');
    $routes->post('apply', 'Dashboard::applyJob');
});

// Admin Routes
$routes->group('admin', ['filter' => 'admin'], function ($routes) {
    $routes->get('/', 'Admin\Dashboard::index');
    $routes->get('jobs', 'Admin\Jobs::index');
    $routes->get('jobs/create', 'Admin\Jobs::create');
    $routes->post('jobs/store', 'Admin\Jobs::store');
    $routes->get('jobs/edit/(:num)', 'Admin\Jobs::edit/$1');
    $routes->post('jobs/update/(:num)', 'Admin\Jobs::update/$1');
    $routes->delete('jobs/delete/(:num)', 'Admin\Jobs::delete/$1');
    
    $routes->get('users', 'Admin\Users::index');
    $routes->get('users/(:num)', 'Admin\Users::detail/$1');
    $routes->post('users/reset-password/(:num)', 'Admin\Users::resetPassword/$1');
    $routes->delete('users/delete/(:num)', 'Admin\Users::delete/$1');
    
    $routes->get('courses', 'Admin\Courses::index');
    $routes->get('courses/create', 'Admin\Courses::create');
    $routes->post('courses/store', 'Admin\Courses::store');
    $routes->get('courses/edit/(:num)', 'Admin\Courses::edit/$1');
    $routes->post('courses/update/(:num)', 'Admin\Courses::update/$1');
    $routes->delete('courses/delete/(:num)', 'Admin\Courses::delete/$1');
    
    $routes->get('scholarships', 'Admin\Scholarships::index');
    $routes->get('scholarships/create', 'Admin\Scholarships::create');
    $routes->post('scholarships/store', 'Admin\Scholarships::store');
    $routes->get('scholarships/edit/(:num)', 'Admin\Scholarships::edit/$1');
    $routes->post('scholarships/update/(:num)', 'Admin\Scholarships::update/$1');
    $routes->delete('scholarships/delete/(:num)', 'Admin\Scholarships::delete/$1');
    
    $routes->get('blogs', 'Admin\Blogs::index');
    $routes->get('blogs/create', 'Admin\Blogs::create');
    $routes->post('blogs/store', 'Admin\Blogs::store');
    $routes->get('blogs/edit/(:num)', 'Admin\Blogs::edit/$1');
    $routes->post('blogs/update/(:num)', 'Admin\Blogs::update/$1');
    $routes->delete('blogs/delete/(:num)', 'Admin\Blogs::delete/$1');
    
    $routes->get('internships', 'Admin\Internships::index');
    $routes->get('internships/create', 'Admin\Internships::create');
    $routes->post('internships/store', 'Admin\Internships::store');
    $routes->get('internships/edit/(:num)', 'Admin\Internships::edit/$1');
    $routes->post('internships/update/(:num)', 'Admin\Internships::update/$1');
    $routes->delete('internships/delete/(:num)', 'Admin\Internships::delete/$1');
    
    $routes->get('apprenticeships', 'Admin\Apprenticeships::index');
    $routes->get('apprenticeships/create', 'Admin\Apprenticeships::create');
    $routes->post('apprenticeships/store', 'Admin\Apprenticeships::store');
    $routes->get('apprenticeships/edit/(:num)', 'Admin\Apprenticeships::edit/$1');
    $routes->post('apprenticeships/update/(:num)', 'Admin\Apprenticeships::update/$1');
    $routes->delete('apprenticeships/delete/(:num)', 'Admin\Apprenticeships::delete/$1');
    
    $routes->get('results', 'Admin\Results::index');
    $routes->get('results/create', 'Admin\Results::create');
    $routes->post('results/store', 'Admin\Results::store');
    $routes->get('results/edit/(:num)', 'Admin\Results::edit/$1');
    $routes->post('results/update/(:num)', 'Admin\Results::update/$1');
    $routes->delete('results/delete/(:num)', 'Admin\Results::delete/$1');
    
    $routes->get('admit-cards', 'Admin\AdmitCards::index');
    $routes->get('admit-cards/create', 'Admin\AdmitCards::create');
    $routes->post('admit-cards/store', 'Admin\AdmitCards::store');
    $routes->get('admit-cards/edit/(:num)', 'Admin\AdmitCards::edit/$1');
    $routes->post('admit-cards/update/(:num)', 'Admin\AdmitCards::update/$1');
    $routes->delete('admit-cards/delete/(:num)', 'Admin\AdmitCards::delete/$1');
    
    $routes->get('course-lessons/(:num)', 'Admin\CourseLessons::index/$1');
    $routes->get('course-lessons/(:num)/create', 'Admin\CourseLessons::create/$1');
    $routes->post('course-lessons/(:num)/store', 'Admin\CourseLessons::store/$1');
    $routes->get('course-lessons/(:num)/edit/(:num)', 'Admin\CourseLessons::edit/$1/$2');
    $routes->post('course-lessons/(:num)/update/(:num)', 'Admin\CourseLessons::update/$1/$2');
    $routes->delete('course-lessons/(:num)/delete/(:num)', 'Admin\CourseLessons::delete/$1/$2');
    $routes->post('course-lessons/reorder/(:num)', 'Admin\CourseLessons::reorder/$1');
    
    $routes->get('mock-tests', 'Admin\MockTests::index');
    $routes->get('mock-tests/create', 'Admin\MockTests::create');
    $routes->post('mock-tests/store', 'Admin\MockTests::store');
    $routes->get('mock-tests/edit/(:num)', 'Admin\MockTests::edit/$1');
    $routes->post('mock-tests/update/(:num)', 'Admin\MockTests::update/$1');
    $routes->delete('mock-tests/delete/(:num)', 'Admin\MockTests::delete/$1');
    $routes->get('mock-tests/questions/(:num)', 'Admin\MockTests::questions/$1');
    $routes->post('mock-tests/questions/store/(:num)', 'Admin\MockTests::storeQuestions/$1');
    
    $routes->get('testimonials', 'Admin\Testimonials::index');
    $routes->post('testimonials/store', 'Admin\Testimonials::store');
    $routes->get('testimonials/edit/(:num)', 'Admin\Testimonials::edit/$1');
    $routes->post('testimonials/update/(:num)', 'Admin\Testimonials::update/$1');
    $routes->delete('testimonials/delete/(:num)', 'Admin\Testimonials::delete/$1');
    
    $routes->get('categories', 'Admin\Categories::index');
    $routes->post('categories/store', 'Admin\Categories::store');
    $routes->get('categories/edit/(:num)', 'Admin\Categories::edit/$1');
    $routes->post('categories/update/(:num)', 'Admin\Categories::update/$1');
    $routes->delete('categories/delete/(:num)', 'Admin\Categories::delete/$1');
    
    $routes->get('lesson-quiz/(:num)', 'Admin\LessonQuiz::index/$1');
    $routes->get('lesson-quiz/(:num)/create', 'Admin\LessonQuiz::create/$1');
    $routes->post('lesson-quiz/(:num)/store', 'Admin\LessonQuiz::store/$1');
    $routes->get('lesson-quiz/(:num)/edit/(:num)', 'Admin\LessonQuiz::edit/$1/$2');
    $routes->post('lesson-quiz/(:num)/update/(:num)', 'Admin\LessonQuiz::update/$1/$2');
    $routes->delete('lesson-quiz/(:num)/delete/(:num)', 'Admin\LessonQuiz::delete/$1/$2');
    
    $routes->get('payments', 'Admin\Payments::index');
    
    $routes->get('applications', 'Admin\Applications::index');
    $routes->delete('applications/delete/(:num)', 'Admin\Applications::delete/$1');
    
    $routes->get('contact-messages', 'Admin\ContactMessages::index');
    $routes->delete('contact-messages/delete/(:num)', 'Admin\ContactMessages::delete/$1');
    
    $routes->get('settings', 'Admin\Settings::index');
    $routes->post('settings/update', 'Admin\Settings::update');
    
    $routes->get('analytics', 'Admin\Dashboard::analytics');
});

// API Routes
$routes->group('api', function ($routes) {
    $routes->get('jobs/latest', 'Api\Jobs::latest');
    $routes->get('jobs/search', 'Api\Jobs::search');
    $routes->get('jobs/(:num)', 'Api\Jobs::detail/$1');
    $routes->get('categories', 'Api\Categories::index');
});
