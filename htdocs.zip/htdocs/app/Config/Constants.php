<?php

defined('APP_NAMESPACE') || define('APP_NAMESPACE', 'App');

defined('COMPOSER_PATH') || define('COMPOSER_PATH', ROOTPATH . 'vendor/autoload.php');

defined('TIMESTAMP') || define('TIMESTAMP', time());

defined('ENVIRONMENT') || define('ENVIRONMENT', 'production');

defined('FCPATH') || define('FCPATH', __DIR__ . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR);
