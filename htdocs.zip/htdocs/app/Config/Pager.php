<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Pager extends BaseConfig
{
    public $templates = [
        'default_full'   => 'CodeIgniter\Pager\Views\default_full',
        'default_simple' => 'CodeIgniter\Pager\Views\default_simple',
        'default'        => 'CodeIgniter\Pager\Views\default_full',
        'front'          => 'App\Views\partials\pagination',
    ];
    public $perPage = 12;
}
