<?php
$servername = "sql312.infinityfree.com";
$username = "if0_39763745";
$password = "GamerKing2212";
$dbname = "if0_39763745_nmjobs";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

echo "PHP is working";
?>
<br/>

<?php

echo "<pre>";

echo "vendor/autoload.php: ";
var_dump(file_exists(__DIR__ . "/vendor/autoload.php"));

echo "Boot.php: ";
var_dump(file_exists(__DIR__ . "/vendor/codeigniter4/framework/system/Boot.php"));

echo "PHP Version: " . PHP_VERSION;