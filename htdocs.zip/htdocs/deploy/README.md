# RojgarSandhi — InfinityFree Deployment

## Server Credentials (Pre-Configured)

| Setting | Value |
|---|---|
| Database host | `sql312.infinityfree.com` |
| Database name | `if0_39763745_nmjobs` |
| Database user | `if0_39763745` |
| Database password | `Gamer2212` |
| Base URL | `https://job.nishantmultiservices.com/` |

These are already set in `app/Config/Database.php` and `app/Config/App.php`. You do NOT need to edit them unless the credentials change.

## Deploy Steps

### 1. Upload files to `htdocs/`
InfinityFree's document root is the **`htdocs/`** folder inside your account. There is no "Set Document Root" option — `htdocs/` IS the root.

Using FTP or the File Manager:
- Upload the **entire contents of the zip** into `htdocs/`
- You should see these files directly inside `htdocs/`:
  - `index.php`
  - `.htaccess`
  - `app/`
  - `public/`
  - `vendor/`
  - `writable/`
- **Do NOT** create a subfolder inside `htdocs/` — files go directly in it

### 2. Import the Database
1. Go to InfinityFree control panel → **MySQL Databases**
2. Find the database `if0_39763745_nmjobs` (create it if needed)
3. Click the **phpMyAdmin** icon next to it
4. First import: **`deploy/schema.sql`** (creates 38 tables)
5. Second import: **`deploy/seed.sql`** (inserts settings + categories)

### 3. Set Permissions
Using FTP, set these directories to **755** (writable by server):

```
writable/cache/
writable/logs/
writable/session/
writable/uploads/
```

### 4. Enable SSL
1. In InfinityFree → **SSL Certificates**
2. Issue a free SSL certificate for `job.nishantmultiservices.com`
3. Wait a few minutes for it to activate
4. The site already has HTTPS redirect enabled in `.htaccess`

### 5. Visit the site
Go to **`https://job.nishantmultiservices.com/`**

If it still shows a 404, try:
- Clear your browser cache
- Wait 5-10 minutes for DNS/SSL to propagate
- Check that files were actually uploaded (check via FTP)
- In InfinityFree → **PHP Settings** → make sure PHP 8.2 is selected

## Security

The `app/`, `vendor/`, and `writable/` folders each have a `.htaccess` file with `Deny from all` to block direct web access.

## Admin Panel
- URL: `https://job.nishantmultiservices.com/admin`
- Use an admin account to log in
- Site settings: `https://job.nishantmultiservices.com/admin/settings`

## Notes
- **Payment**: Simulation mode is ON. Real PhonePe payments won't work until V2 API credentials are added.
- **Debug toolbar**: Disabled (production mode).
- **Encryption key**: Pre-generated and set in `app/Config/Encryption.php`.
