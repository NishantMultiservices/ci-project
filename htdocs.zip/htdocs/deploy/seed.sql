-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: rojgar_sandhi
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` (`id`, `key_name`, `key_value`, `group_name`, `created_at`, `updated_at`) VALUES (1,'site_name','RojgarSandhi','general','2026-07-02 00:50:11','2026-07-02 00:50:11'),(2,'site_tagline','Your Gateway to Jobs, Skills & Career Success','general','2026-07-02 00:50:11','2026-07-02 00:50:11'),(3,'site_email','info@rojgarsandhi.in','general','2026-07-02 00:50:11','2026-07-02 00:50:11'),(4,'site_phone','+91-1800-123-4567','general','2026-07-02 00:50:11','2026-07-02 00:50:11'),(5,'site_address','New Delhi, India','general','2026-07-02 00:50:11','2026-07-02 00:50:11'),(6,'meta_title','RojgarSandhi - Your Gateway to Jobs, Skills & Career Success','seo','2026-07-02 00:50:11','2026-07-02 00:50:11'),(7,'meta_description','India\'s premier career platform connecting millions of job seekers with government jobs, private jobs, internships, and skill development courses.','seo','2026-07-02 00:50:11','2026-07-02 00:50:11'),(8,'meta_keywords','jobs, government jobs, private jobs, internships, courses, India jobs, Sarkari Naukri','seo','2026-07-02 00:50:11','2026-07-02 00:50:11'),(9,'total_jobs_count','50000','stats','2026-07-02 00:50:11','2026-07-02 00:50:11'),(10,'total_students_count','10000','stats','2026-07-02 00:50:11','2026-07-02 00:50:11'),(11,'total_courses_count','1000','stats','2026-07-02 00:50:11','2026-07-02 00:50:11'),(12,'total_companies_count','500','stats','2026-07-02 00:50:11','2026-07-02 00:50:11'),(13,'facebook_url','https://facebook.com/rojgarsandhi','social','2026-07-02 00:50:11','2026-07-02 00:50:11'),(14,'twitter_url','https://twitter.com/rojgarsandhi','social','2026-07-02 00:50:11','2026-07-02 00:50:11'),(15,'instagram_url','https://instagram.com/rojgarsandhi','social','2026-07-02 00:50:11','2026-07-02 00:50:11'),(16,'linkedin_url','https://linkedin.com/company/rojgarsandhi','social','2026-07-02 00:50:11','2026-07-02 00:50:11'),(17,'youtube_url','https://youtube.com/@rojgarsandhi','social','2026-07-02 00:50:11','2026-07-02 00:50:11'),(18,'telegram_url','https://t.me/rojgarsandhi','social','2026-07-02 00:50:11','2026-07-02 00:50:11'),(19,'whatsapp_number','+91-1800-123-4567','social','2026-07-02 00:50:11','2026-07-02 00:50:11');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name`, `slug`, `type`, `description`, `icon`, `parent_id`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES (1,'All Jobs','all-jobs','job','All job categories','briefcase',NULL,1,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(2,'Government Jobs','government-jobs','job','Government sector jobs','landmark',NULL,2,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(3,'Private Jobs','private-jobs','job','Private sector jobs','building',NULL,3,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(4,'UPSC','upsc','job','UPSC exam jobs','landmark',NULL,4,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(5,'SSC','ssc','job','SSC exam jobs','file-text',NULL,5,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(6,'Banking','banking','job','Banking jobs','university',NULL,6,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(7,'Railway','railway','job','Railway jobs','train',NULL,7,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(8,'Police','police','job','Police jobs','shield',NULL,8,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(9,'Defence','defence','job','Defence jobs','crosshair',NULL,9,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(10,'State Government','state-government','job','State government jobs','map-pin',NULL,10,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(11,'Programming','programming','course','Programming courses','code',NULL,1,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(12,'AI & Machine Learning','ai-machine-learning','course','AI and ML courses','cpu',NULL,2,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(13,'Data Science','data-science','course','Data Science courses','bar-chart',NULL,3,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(14,'Cyber Security','cyber-security','course','Cyber Security courses','lock',NULL,4,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(15,'Web Development','web-development','course','Web Development courses','globe',NULL,5,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(16,'Digital Marketing','digital-marketing','course','Digital Marketing courses','trending-up',NULL,6,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(17,'Cloud Computing','cloud-computing','course','Cloud Computing courses','cloud',NULL,7,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(18,'Career Tips','career-tips','blog','Career advice articles','compass',NULL,1,1,'2026-07-02 00:50:11','2026-07-02 00:50:11'),(19,'Exam Prep','exam-prep','blog','Exam preparation tips','book',NULL,2,1,'2026-07-02 00:50:11','2026-07-02 00:50:11');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password`, `google_id`, `avatar`, `role`, `is_active`, `email_verified_at`, `phone_verified_at`, `otp`, `otp_expires_at`, `remember_token`, `reset_token`, `reset_token_expires_at`, `last_login_at`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'Admin','admin@rojgarsandhi.in','9999999999','$2y$10$8ioF4Hhl.zygusaDbPcvt.FwtBkw8edd1YJ53AKjTQTvy52E2jxUS',NULL,NULL,'admin',1,'2026-07-02 00:50:10',NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-04 15:48:28','2026-07-02 00:50:11','2026-07-04 15:48:28',NULL),(2,'Rahul Sharma','rahul@example.com','9876543210','$2y$10$J40DEVoslKKxRsldgWbk0.PkU43TbDHWzuglD.xpNQw13JVNSmJH.',NULL,NULL,'user',1,'2026-07-02 00:50:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-02 00:50:11','2026-07-02 00:50:11',NULL),(3,'Priya Patel','priya@example.com','9876543211','$2y$10$zCJ.sYqLFcj933Y2JyxOKeN3a8zfRmnsE1uww2mkmwH3dxB9nd8m.',NULL,NULL,'user',1,'2026-07-02 00:50:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-02 00:50:11','2026-07-02 00:50:11',NULL),(4,'Amit Kumar','amit@example.com','9876543212','$2y$10$gn5vczkqueYoH2v5AWdO0.H1Ct53kOux/pvomj3bM0VXpnJIdNj2a',NULL,NULL,'user',1,'2026-07-02 00:50:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-02 00:50:11','2026-07-02 00:50:11',NULL),(5,'Sneha Gupta','sneha@example.com','9876543213','$2y$10$8TyYLjl056fS566GzVC1s.wXn5EWPB8kheRwxS2Y0MtRiSCf96Zym',NULL,NULL,'user',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-04 12:59:22','2026-07-02 00:50:11','2026-07-04 12:59:22',NULL),(6,'Vikram Singh','vikram@example.com','9876543214','$2y$10$5xZ3VCVwIfFvY8cTQHDhs.9IkKnTT3ubftchEEbznc8lkk4OJiMQu',NULL,NULL,'user',1,'2026-07-02 00:50:11',NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-04 17:48:38','2026-07-02 00:50:11','2026-07-04 17:48:38',NULL),(7,'Test User','test@test.com',NULL,'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'user',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-04 13:20:51','2026-07-03 01:27:40','2026-07-04 13:45:43','2026-07-04 13:45:43');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-04 18:24:33
